#!/usr/bin/env python3
"""
run_deepseek_seeds.py
-------------------
Runs the full (non-ablation) DeepSeek harness --
run_infer_benchmarks_deepseek_r1.py -- once per seed, sequentially, for
whichever seeds are given.

IMPORTANT: unlike the Opus/Kimi runners, run_infer_benchmarks_deepseek_r1.py
has no --test-dir flag -- it always reads from/writes to smeagolTest/
(the same shared test-dir Haiku uses). Before each seed's run, smeagolTest/
is fully reset to an exact copy of smeagolInfer/ (rsync -a --delete), so
every seed starts from the same pristine templated state -- no invariant
solved on a previous seed leaks into the next one. Don't run this at the
same time as run_haiku_seeds.py (or anything else pointed at smeagolTest/)
-- they'd stomp on each other's working copy.

Equivalent to running, one after another, for each seed in --seeds:

    rsync -a --delete smeagolInfer/ smeagolTest/
    python3 run_infer_benchmarks_deepseek_r1.py --seed <seed> --out-dir deepseek_seed<seed>

Run this from anywhere; it locates the cn/ directory relative to itself.

Usage:
    python3 run_deepseek_seeds.py --seeds 66 67 68
    python3 run_deepseek_seeds.py --seeds 66 67 68 --only addOne.c
    python3 run_deepseek_seeds.py --seeds 66 67 68 --max-rounds 10 --timeout 120
"""

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPT = "run_infer_benchmarks_deepseek_r1.py"
TEST_DIR = "smeagolTest"
OUT_DIR_PREFIX = "deepseek_seed"


def reset_test_dir() -> None:
    dst_dir = ROOT / TEST_DIR
    dst_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["rsync", "-a", "--delete", str(ROOT / "smeagolInfer") + "/", str(dst_dir) + "/"],
        check=True,
    )


def run_one(seed, extra_args: list[str]) -> int:
    out_dir = f"{OUT_DIR_PREFIX}{seed}"
    print(f"=== deepseek (seed {seed}) -> {out_dir} ===")
    reset_test_dir()

    cmd = [sys.executable, SCRIPT, "--seed", str(seed), "--out-dir", out_dir] + extra_args
    proc = subprocess.run(cmd, cwd=ROOT)
    if proc.returncode != 0:
        print(f"!!! seed {seed} exited with code {proc.returncode} -- continuing with the rest !!!")
    print()
    return proc.returncode


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seeds", type=int, nargs="+", default=[66, 67, 68],
                     help="Seeds to run, in order (default: 66 67 68).")
    ap.add_argument("--only", action="append",
                     help="Only run this benchmark filename (repeatable); passed through to run_infer_benchmarks_deepseek_r1.py.")
    ap.add_argument("--max-rounds", type=int, default=None,
                     help="Passed through to --max-rounds (default: that script's own default).")
    ap.add_argument("--timeout", type=int, default=None,
                     help="Passed through to --timeout (default: that script's own default).")
    ap.add_argument("--sleep", type=float, default=None,
                     help="Passed through to --sleep.")
    args = ap.parse_args()

    extra_args = []
    if args.only:
        for f in args.only:
            extra_args += ["--only", f]
    if args.max_rounds is not None:
        extra_args += ["--max-rounds", str(args.max_rounds)]
    if args.timeout is not None:
        extra_args += ["--timeout", str(args.timeout)]
    if args.sleep is not None:
        extra_args += ["--sleep", str(args.sleep)]

    exit_codes = []
    for seed in args.seeds:
        exit_codes.append(run_one(seed, extra_args))

    print("All DeepSeek seed runs complete: "
          + ", ".join(f"seed {s} -> {'ok' if c == 0 else f'exit {c}'}"
                       for s, c in zip(args.seeds, exit_codes)))
    sys.exit(0 if all(c == 0 for c in exit_codes) else 1)


if __name__ == "__main__":
    main()
