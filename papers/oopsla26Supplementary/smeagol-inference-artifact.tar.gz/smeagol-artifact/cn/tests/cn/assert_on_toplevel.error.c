        /*@
    assert @*/
