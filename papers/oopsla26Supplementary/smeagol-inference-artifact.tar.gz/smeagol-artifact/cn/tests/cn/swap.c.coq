return code: 0
[1/1] tests/cn/swap.c:
  CN verify:    SUCCESS
  Coq compile:  SUCCESS

All 1 tests passed!
