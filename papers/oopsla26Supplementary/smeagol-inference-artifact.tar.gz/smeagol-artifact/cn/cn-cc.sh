mkdir -p ~/bin
cat > ~/bin/cn-cc.sh <<'EOF'
#!/bin/sh
exec clang -std=gnu2x "$@"
EOF
chmod +x ~/bin/cn-cc.sh