#!/usr/bin/env python3
"""
run_infer_benchmarks_opus5.py

Prompting/re-prompting harness for the loop-invariant-inference benchmark
suite in smeagolInfer/. Drives an LLM (Claude Opus 5, Anthropic's
highest-reasoning current model) through the task described in

    smeagolInfer/INVARIANT_INFERENCE_PROMPT.md

against every benchmark under smeagolTest/, validating each attempt with
the real `cn test` tool and feeding failures back per the re-prompting
protocol (up to 5 corrective rounds per loop, 6 attempts total).

This is a fork of run_infer_benchmarks.py (the Haiku-default harness),
identical in every way except:
  - DEFAULT_MODEL is "claude-opus-5".
  - Reasoning depth is controlled via `output_config.effort` (--effort,
    default "xhigh"), not manual extended-thinking budgets. Claude Opus 5
    rejects the old `thinking: {"type": "enabled", "budget_tokens": N}`
    manual-mode request with a 400 error ("thinking.type.enabled is not
    supported for this model") -- as of the Claude 4.7 generation and
    later, Anthropic migrated to *adaptive* thinking, where Claude itself
    decides whether/how much to think, steered by the `effort` parameter
    instead of a fixed token budget. `effort="xhigh"` is Anthropic's own
    recommendation for "demanding coding and agentic work," which is what
    this benchmark suite is, and is a step up from the API default
    ("high"). Pass --effort high|medium|low to spend less, or --effort max
    for the absolute ceiling.
  - MAX_TOKENS is raised to 64000 (default) -- Anthropic's own guidance
    for xhigh/max effort is "starting at 64k tokens and tuning from there
    is a reasonable default," since at these effort levels Claude may
    spend a large, variable number of tokens thinking before it produces
    the final code block, and max_tokens is the hard ceiling on that plus
    the visible response combined.

Only INVARIANT_INFERENCE_PROMPT.md is sent as standing (system-prompt)
instructions -- its own §10 already summarizes the re-prompting protocol in
one sentence per failure category, which is enough for the model to
self-diagnose. INVARIANT_INFERENCE_REPROMPT.md (the full, verbose version)
is a human-facing reference and is not resent on every call. Each re-prompt
instead carries the current failure's `cn test` output in full, plus a
short one-line recap of any earlier failed attempts on that same loop --
not a full transcript of every previous round.

IMPORTANT — where this must run:
  `cn test` is a native macOS binary built via opam (see
  .opam/cn-switch/bin/cn) and the required `clang` toolchain lives on your
  Mac. This script must be run in a real Terminal on your Mac, from the
  `cn` project directory (the one containing smeagolTest/ and
  smeagolOpDir/). It will not run inside a Linux sandbox.

Usage (on your Mac, from the `cn` directory):

    export ANTHROPIC_API_KEY=sk-...
    pip3 install anthropic
    python3 run_infer_benchmarks_opus5.py                 # run all benchmarks
    python3 run_infer_benchmarks_opus5.py --only addOne.c  # run just one
    python3 run_infer_benchmarks_opus5.py --max-rounds 10 --timeout 120
    python3 run_infer_benchmarks_opus5.py --effort high  # cheaper than the xhigh default

Output:
  - smeagolTest/<file>.c is updated in place with accepted invariants as
    they're solved (the harness's working copy).
  - smeagolOpDir/<name>/ (name = filename without .c) gets one
    subdirectory per benchmark, containing:
      - cn test's own --output-dir contents (its generated test artifacts)
      - loop<i>_attempt<k>.c   -- the candidate file sent to cn test
      - loop<i>_attempt<k>.log -- cn test's stdout+stderr for that attempt
      - summary.json -- that benchmark's own machine-readable result
        (status, tokens, reprompts used, elapsed time, per-loop detail)
  - a plain-text report printed to stdout at the end (aggregated across
    whatever benchmarks were run in this invocation)
"""

import argparse
import json
import os
import re
import shutil
import subprocess
import sys
import time
import textwrap
from pathlib import Path

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

ROOT = Path(__file__).resolve().parent
INFER_DIR = ROOT / "smeagolInfer"
TEST_DIR = ROOT / "smeagolTest"
DEFAULT_OUT_DIR_NAME = "smeagolOpDir"
# The prompt/reprompt docs live in their own directory, separate from
# smeagolInfer's benchmark .c files -- they aren't benchmark input, so
# copying them alongside the benchmarks every time smeagolTest gets reset
# from smeagolInfer was just incidental clutter, not anything the harness
# actually read from that location.
PROMPTS_DIR = ROOT / "prompts"
PROMPT_FILE = PROMPTS_DIR / "INVARIANT_INFERENCE_PROMPT.md"
REPROMPT_FILE = PROMPTS_DIR / "INVARIANT_INFERENCE_REPROMPT.md"

DEFAULT_MODEL = "claude-opus-5"  # Anthropic's highest-reasoning current model
DEFAULT_TIMEOUT_S = 120          # 2 minutes per `cn test` invocation
DEFAULT_MAX_REPROMPTS = 10       # + 1 initial attempt = 11 total per loop
MAX_LOG_CHARS = 6000             # truncate the *current* failure's output before resending it
SUMMARY_MAX_CHARS = 300          # truncate *earlier* failures down to a short recap each
MAX_TOKENS = 128000                # Anthropic's documented ceiling for a single (non-batch,
                                   # streaming) Opus 5 call; thinking tokens count against this
                                   # same budget, so this is the most headroom a request can get
                                   # without switching to the batch API's separate 300k limit.
DEFAULT_EFFORT = "xhigh"          # "low" | "medium" | "high" | "xhigh" | "max" -- see output_config.effort
EFFORT_TIERS = ["low", "medium", "high", "xhigh", "max"]
API_RETRIES = 3
API_RETRY_BACKOFF_S = 5


def step_down_effort(effort: str) -> str:
    """One rung down the reasoning-effort ladder from `effort`, or
    unchanged if already at the bottom (or not a recognized tier).

    Used when a response gets cut off before producing any usable text --
    see the MAX_TOKENS-truncation handling in process_benchmark. Adaptive
    thinking at xhigh/max can, for a genuinely hard checkpoint, spend the
    *entire* token budget reasoning and never reach the visible answer
    (usage.output_tokens hits MAX_TOKENS while the extracted text is
    empty or truncated mid-file -- see the module docstring's note on
    what counts as "output"). Repeating the same effort level on retry
    doesn't address that; only giving the model less room to think
    open-endedly does."""
    try:
        idx = EFFORT_TIERS.index(effort)
    except ValueError:
        return effort
    return EFFORT_TIERS[max(0, idx - 1)]

# A literal separator comment (10+ dashes) every benchmark file now has,
# placed by hand right after the preamble's last `/*@ ... @*/` block and
# right before the first real C function declaration in the file (see
# apply_split_response's docstring for why this replaced a keyword-based
# heuristic).
PREAMBLE_SEPARATOR_RE = re.compile(r"/\*-{10,}\*/")

TEMPLATE_LOOP_RE = re.compile(
    r"/\*\s*Template:(?P<tmpl>.*?)\*/\s*"
    r"while\s*\((?P<cond>[^)]*)\)\s*"
    r"(?P<open>/\*@?)(?P<inv>.*?)(?P<close>@?\*/)",
    re.DOTALL,
)

# The model no longer returns the whole file (see
# validate_strict_output_contract / apply_split_response below): it
# returns exactly three labeled blocks --
# new predicates, new functions, and the target loop's inv -- each
# delimited the same way CN's own annotation blocks are, with a label
# glued onto the opening `/*@` with no space so the harness can tell the
# three apart. The labels are deliberately NOT "predicate"/"function"/"inv"
# themselves (those are real CN keywords): inside the INV block the model
# writes ordinary CN inv syntax, which already starts with the word "inv"
# in every worked example, so a same-named label would force the model to
# write "inv" twice in a row (once for the label, once for real syntax) --
# awkward and inconsistent with every example it's just been shown. NEWPRED/
# NEWFUNC/INV (all-caps, never a valid CN keyword) sidestep that: the model
# writes its answer exactly like the worked examples, once, with nothing to
# strip or reconcile. The harness then splices these deterministically into
# the current file itself, rather than trusting the model to reproduce (and
# not accidentally disturb) everything else.
PRED_BLOCK_RE = re.compile(r"/\*@NEWPRED\s*(?P<body>.*?)@\*/", re.DOTALL)
FUNC_BLOCK_RE = re.compile(r"/\*@NEWFUNC\s*(?P<body>.*?)@\*/", re.DOTALL)
INV_BLOCK_RE = re.compile(r"/\*@INV\s*(?P<body>.*?)@\*/", re.DOTALL)

# The full HARNESS OUTPUT CONTRACT, enforced literally: the ENTIRE response
# (after stripping at most one optional wrapping markdown code fence, since
# models habitually wrap answers in ``` even when told not to) must be
# nothing but whitespace, one /*@NEWPRED ... @*/ block, whitespace, one
# /*@NEWFUNC ... @*/ block, whitespace, one /*@INV ... @*/ block, and
# whitespace -- in that order, with nothing else anywhere: no preamble, no
# reasoning, no "wait, let me reconsider", no second copy of any block, no
# trailing remarks. Anchored on the whole string (^...$, DOTALL) so there is
# nowhere for stray content to hide.
STRICT_RESPONSE_RE = re.compile(
    r"^\s*/\*@NEWPRED\s*(?P<predicates>.*?)@\*/"
    r"\s*/\*@NEWFUNC\s*(?P<functions>.*?)@\*/"
    r"\s*/\*@INV\s*(?P<inv>.*?)@\*/\s*$",
    re.DOTALL,
)

# A single markdown code fence wrapping the whole response (```, optionally
# with a language tag, ... ```), which is formatting the model added on top
# of the contract, not content -- stripped before the strict check runs so
# it isn't penalized as "extra content".
_WRAPPING_FENCE_RE = re.compile(r"^\s*```[a-zA-Z]*\s*\n(?P<body>.*?)\n?```\s*$", re.DOTALL)

# Matches a `<Name> is ...` ghost-variable declaration inside a Template
# comment's prose (e.g. "Npar is the node with address parent"). Used by
# find_unused_provided_takes to check the model's returned inv actually
# takes -- and then uses -- every ghost variable the template named.
GHOST_VAR_DECL_RE = re.compile(r"\b([A-Z]\w*)\s+is\b")

# Matches a boolean-returning CN function definition up to its opening brace
# (the body itself is extracted separately via brace-matching, since bodies
# contain nested `match { ... }` blocks that a regex can't balance).
FUNC_BOOL_RE = re.compile(
    r"function\s*(?:\[rec\]\s*)?\(\s*boolean\s*\)\s*(?P<name>\w+)\s*\((?P<params>[^)]*)\)\s*\{"
)

# Matches any function definition (any return type) up to its opening
# brace -- the function-side counterpart to PRED_DEF_RE below, used by
# dedupe_new_defs to recognize a returned function definition's name.
FUNC_DEF_RE = re.compile(
    r"function\s*(?:\[rec\]\s*)?\([^()]*\)\s*(?P<name>\w+)\s*\([^)]*\)\s*\{"
)

# Matches any predicate definition (any return type) up to its opening
# brace -- used to find newly-invented predicates that might launder a call
# to an invented boolean function (§1.8's "check inside that predicate too").
PRED_DEF_RE = re.compile(
    r"predicate\s*(?:\[rec\]\s*)?\([^()]*\)\s*(?P<name>\w+)\s*\([^)]*\)\s*\{"
)

# Any function/predicate definition, any return type -- used only to know
# which names already existed in the file before this attempt (so we don't
# flag something the file itself was given with).
ANY_FUNC_OR_PRED_NAME_RE = re.compile(
    r"\b(?:function|predicate)\s*(?:\[rec\]\s*)?\([^()]*\)\s*(\w+)\s*\("
)

# Bare `||` anywhere in the file. Per §1.2, no case split may ever be
# expressed with `||` -- not as a hedge inside an `inv` block, and not
# inside a function/predicate's own body either. Everything must be a
# genuine `if`/`match` decided by the arguments or real program state (see
# find_disjunctive_equality_violations for the whole-file check this backs).
DISJUNCTION_RE = re.compile(r"\|\|")


# ---------------------------------------------------------------------------
# Parsing: find the templated (to-be-inferred) loops in a benchmark file
# ---------------------------------------------------------------------------

def find_templated_loops(text: str):
    """Return an ordered list of loops that have a /* Template: ... */
    comment immediately before their `while (...) /*@ inv ... @*/` block.
    These are the loops the harness is responsible for filling in, in
    source order (which is outermost-first for nested loops, since the
    outer `while` always appears earlier in the text).

    Loops with no preceding Template comment (the §3.1 "shared sub-loop"
    case, already fully given) are intentionally excluded here and never
    touched by the harness.
    """
    loops = []
    for m in TEMPLATE_LOOP_RE.finditer(text):
        line_no = text[: m.start()].count("\n") + 1
        loops.append({"line": line_no, "start": m.start(), "end": m.end()})
    return loops


def existing_function_names(text: str) -> set:
    """Names of every function/predicate already defined in this text
    (used to tell "already given" from "invented this attempt")."""
    return set(ANY_FUNC_OR_PRED_NAME_RE.findall(text))


def existing_predicate_names(text: str) -> set:
    """Names of every *predicate* (not function) already defined in this
    text -- a strict subset of existing_function_names's combined set,
    built off PRED_DEF_RE specifically so it can never include a function
    name. Used by find_recursive_invented_predicates so that a recursive
    *function* (entirely normal and expected, e.g. `length`/`Double` in
    §1.2's worked examples) is never mistakenly exempted from -- or
    confused with -- the "no recursive invented predicate" check, and so a
    newly-invented predicate that happens to reuse an existing function's
    name isn't incorrectly treated as "already given"."""
    return {m.group("name") for m in PRED_DEF_RE.finditer(text)}


def _find_matching_brace(text: str, open_idx: int) -> int:
    """Given the index of an opening '{', return the index of its matching
    '}' (accounting for nesting), or -1 if unbalanced."""
    depth = 0
    for i in range(open_idx, len(text)):
        if text[i] == "{":
            depth += 1
        elif text[i] == "}":
            depth -= 1
            if depth == 0:
                return i
    return -1


def find_invented_boolean_functions(candidate_text: str, original_fn_names: set):
    """§1.8 check, step 1: every newly-invented (not already in the file),
    boolean-returning `function` -- any shape, not just equality/inequality
    comparators. Anything in this list is not yet established by anything
    in the file, so it cannot be asserted as a bare star-portion fact
    (see find_star_portion_violations)."""
    found = []
    for m in FUNC_BOOL_RE.finditer(candidate_text):
        name = m.group("name")
        if name not in original_fn_names and name not in found:
            found.append(name)
    return found


def _build_predicate_graph(candidate_text: str):
    """Every predicate definition in the candidate (any return type, given
    or invented -- deliberately unfiltered) and its body, plus the
    predicate-calls-predicate graph over all of them (self-edges excluded;
    self-recursion is checked separately by callers that care about it).
    Left unfiltered to "invented only" so that laundering or a recursion
    cycle introduced by *editing* an existing given predicate's body is
    still caught, not just brand-new predicates."""
    predicate_bodies = {}
    for m in PRED_DEF_RE.finditer(candidate_text):
        pname = m.group("name")
        open_brace = m.end() - 1
        close_brace = _find_matching_brace(candidate_text, open_brace)
        if close_brace == -1:
            continue
        predicate_bodies[pname] = candidate_text[open_brace + 1: close_brace]

    #list of predicate names that are called by the current predicate pname
    predicate_calls = {
        pname: [
            other for other in predicate_bodies
            if other != pname and re.search(rf"\b{re.escape(other)}\s*\(", body)
        ]
        for pname, body in predicate_bodies.items()
    }
    return predicate_bodies, predicate_calls


def _reachable_chain(predicate_calls: dict, start: str):
    """BFS over the predicate call graph from `start`, returning
    {reached_predicate: path_from_start} for every predicate reachable
    (including `start` itself). A `seen` set makes this safe against
    self-recursion and cycles between mutually-recursive predicates."""
    seen = {start: [start]}
    queue = [start]
    while queue:
        cur = queue.pop(0)
        for nxt in predicate_calls.get(cur, []):
            if nxt not in seen:
                seen[nxt] = seen[cur] + [nxt]
                queue.append(nxt)
    return seen


def find_boolean_fn_smuggling_violations(candidate_text: str, invented_bool_fns: list):
    """§1.8 check, step 2: does the invariant -- star portion OR inside the
    wand, anywhere in a templated loop's `inv` -- call one of the invented
    boolean functions as a bare, standalone fact? Either directly, or
    indirectly through *any chain* of predicate calls, however many hops
    long, including a predicate that calls itself or a cycle of predicates
    that call each other. Any of those is smuggling in a fact nothing in
    the file has established.

    This deliberately only looks inside `inv` blocks. A boolean function
    called from *inside another function's own body* (a function that
    itself returns something other than boolean, using the boolean helper
    as an internal step) is legitimate per §1.8 and is never inspected
    here -- only what's asserted bare inside the invariant itself counts."""
    violations = []
    if not invented_bool_fns:
        return violations

    predicate_bodies, predicate_calls = _build_predicate_graph(candidate_text)

    def body_calls_invented_fn(body: str):
        for fn in invented_bool_fns:
            if re.search(rf"\b{re.escape(fn)}\s*\(", body):
                return fn
        return None

    for loop_m in TEMPLATE_LOOP_RE.finditer(candidate_text):
        inv_text = loop_m.group("inv")

        # Direct calls to an invented boolean function anywhere in the
        # invariant -- star portion or wand alike.
        for fn in invented_bool_fns:
            if re.search(rf"\b{re.escape(fn)}\s*\(", inv_text):
                violations.append({"function": fn, "via": "direct"})

        # Indirect: the invariant calls a predicate, and somewhere in the
        # full chain of predicates reachable from it -- any number of hops,
        # including through recursion/cycles -- an invented boolean
        # function gets called.
        for pname in predicate_bodies:
            #invariant foes not call this predicate.
            if not re.search(rf"\b{re.escape(pname)}\s*\(", inv_text):
                continue
            for reached, path in _reachable_chain(predicate_calls, pname).items():
                laundered = body_calls_invented_fn(predicate_bodies[reached])
                if laundered:
                    via = (
                        f"predicate `{pname}`" if len(path) == 1
                        else "predicate " + " -> ".join(f"`{p}`" for p in path)
                    )
                    violations.append({"function": laundered, "via": via})

    return violations


def find_recursive_invented_predicates(candidate_text: str, original_predicate_names: set):
    """§1.9 check: an invented predicate may never be recursive -- neither
    by calling itself directly, nor by sitting in a cycle with any other
    predicate (invented, or given-but-edited) that eventually calls back to
    it. Calling a *given* predicate that does not call back (e.g. a new
    predicate that reuses `Treerep`, while `Treerep` itself never calls
    back) is fine -- that's ordinary resource composition, not recursion.
    The cycle check traces through the whole predicate-call graph, not just
    invented predicates, since a cycle routed through an edited *given*
    predicate makes the invented one just as recursive.

    `original_predicate_names` must be a *predicates-only* name set (see
    existing_predicate_names), not the combined function+predicate set --
    otherwise a recursive function (normal and expected, e.g. `length`/
    `Double`) risks being conflated with this check, and a newly-invented
    predicate that happens to share a name with an existing *function*
    would be wrongly treated as "already given" and skipped."""
    predicate_bodies, predicate_calls = _build_predicate_graph(candidate_text)
    invented_predicates = [p for p in predicate_bodies if p not in original_predicate_names]

    violations = []
    for pname in invented_predicates:
        body = predicate_bodies[pname]

        # Direct self-recursion (predicate_calls deliberately excludes
        # self-edges, so this has to be checked against the raw body).
        if re.search(rf"\b{re.escape(pname)}\s*\(", body):
            violations.append({"predicate": pname, "cycle": [pname, pname]})
            continue

        # Indirect/mutual recursion: BFS from pname's own callees and see
        # if any path leads back to pname itself.
        seen = {}
        queue = []
        for nxt in predicate_calls.get(pname, []):
            seen[nxt] = [pname, nxt]
            queue.append(nxt)
        cycle_path = None
        while queue:
            cur = queue.pop(0)
            if cur == pname:
                cycle_path = seen[cur]
                break
            for nxt in predicate_calls.get(cur, []):
                if nxt in seen:
                    continue
                seen[nxt] = seen[cur] + [nxt]
                queue.append(nxt)
        if cycle_path:
            violations.append({"predicate": pname, "cycle": cycle_path})

    return violations


def find_nested_wand_violations(inv_text: str):
    """A `wand(...)` inside another `wand(...)` (antecedent or consequent) is
    never allowed: the testing engine does not support nested wands, and
    `a -* (b -* c)` must be normalized to `(a * b) -* c` instead (see the
    "Wands are never nested" note in INVARIANT_INFERENCE_PROMPT.md). Returns
    one record per outer wand that contains another wand."""
    starts = [m.start() for m in re.finditer(r"\bwand\s*\(", inv_text)]
    violations = []
    for s in starts:
        open_idx = inv_text.index("(", s)
        depth = 0
        end = None
        for i in range(open_idx, len(inv_text)):
            ch = inv_text[i]
            if ch == "(":
                depth += 1
            elif ch == ")":
                depth -= 1
                if depth == 0:
                    end = i
                    break
        if end is None:
            continue
        if any(open_idx < s2 < end for s2 in starts):
            violations.append({"line": inv_text[:s].count("\n") + 1})
    return violations


def find_disjunctive_equality_violations(candidate_text: str):
    """§1.2 check: `||` may never appear anywhere in the file, full stop --
    not in an `inv` block (star portion or wand), and not inside a
    function/predicate's own body either. Every case split must be a
    genuine `if`/`match` decided by the arguments or real program state; a
    `||` is never a legitimate stand-in for that, whether it's hedging a
    fact about a ghost variable in an invariant or defining "1 or 2,
    whichever" inside a function body. This is a blanket, whole-file scan,
    not scoped to `inv` blocks -- simpler and stricter than checking only
    for a same-variable disjunctive equality inside the invariant."""
    violations = []
    for m in DISJUNCTION_RE.finditer(candidate_text):
        line_no = candidate_text[: m.start()].count("\n") + 1
        line_text = candidate_text.splitlines()[line_no - 1].strip()
        violations.append({"line": line_no, "text": line_text})
    return violations


_TAKE_BINDING_RE = re.compile(r"\btake\s+(\w+)\s*=")


def _predicate_body_fully_uses_its_own_takes(body_text: str) -> bool:
    """True iff every `take X = ...` bound inside this predicate body is
    referenced again somewhere else in the SAME body (an equation, a
    return-expression field, an assert, ...) -- the same "taken but
    dropped" principle find_unused_provided_takes applies to an inv's own
    Template-named ghost variables, just applied generically to whatever
    a predicate's own clause takes, under ITS OWN names. Used to "inline"
    a newly-defined predicate the inv calls (see find_unused_provided_
    takes's own comment on delegation) -- a predicate with no internal
    drops is trusted to actually be using what it takes, even though its
    own take-bound names don't literally match the Template's."""
    names = sorted(set(_TAKE_BINDING_RE.findall(body_text)))
    return all(len(re.findall(rf"\b{re.escape(name)}\b", body_text)) >= 2 for name in names)


def find_unused_provided_takes(
    template_text: str, inv_text: str, predicate_bodies: dict = None, predicate_calls: dict = None
):
    """The Template comment declares certain ghost-variable names the model
    is required to `take` (e.g. "Npar is the node with address parent").
    It's not enough to `take` one and then never mention it again -- that's
    exactly the "invariant that quietly ignores part of the heap it was
    handed" failure mode this project has run into concretely (an inv that
    takes a resource, never re-derives or re-asserts anything about it, and
    still passes `cn test` because nothing else disturbs it either). For
    every name the template declares, this checks: (a) the returned inv
    actually has a `take <Name> = ...` for it, and (b) that name is
    referenced again somewhere else in the inv (an equation, a wand side, a
    pure fact) -- not just taken and dropped.

    A model is also free to fold two or more Template ghost variables into
    ONE combined predicate call instead of taking each under its own literal
    name (e.g. `take S = ParCursor(parent, r);` standing in for both `Npar`
    and `Tr` at once, with the predicate's own body doing `take Npar = ...`
    and `take Tr = ...` under those SAME literal names internally). That's
    not a violation on its own -- the concepts the Template named are still
    being taken and used, just via a different, named-once combination the
    model itself just defined. So before flagging a ghost name as "never
    taken" outright, this also checks (given `predicate_bodies`, e.g. from
    _build_predicate_graph over the full candidate including the model's
    own newly-spliced NEWPRED text) whether the inv calls a predicate whose
    OWN body literally binds `take <Name> = ...` under that SAME missing
    name AND -- checked by _predicate_body_fully_uses_its_own_takes --
    doesn't itself drop anything it takes. If so, the ghost name is treated
    as covered by that call rather than flagged. Requiring the literal name
    match (not just "some called predicate is well-formed") matters: an inv
    almost always calls SOME well-formed predicate (e.g. an ordinary
    Listrep(p) with no relation whatsoever to a missing Template name like
    `Ltemp`), so checking well-formedness alone would silently excuse every
    missing name via whatever unrelated predicate happens to be in scope --
    exactly the bug this literal-name requirement closes.

    Heuristic, not exact: it relies on the Template comment's own
    "<Name> is ..." phrasing (see INVARIANT_INFERENCE_PROMPT.md §2). A
    template that only gives prose with no such named existential (worked
    example 6's "par and r walk down the tree together...") yields no names
    to check, and this is then a no-op -- not a false positive."""
    predicate_bodies = predicate_bodies or {}
    predicate_calls = predicate_calls or {}
    names = sorted(set(GHOST_VAR_DECL_RE.findall(template_text)))
    called_predicates = set(re.findall(r"=\s*(\w+)\s*\(", inv_text))

    # A predicate the inv calls directly may itself delegate to a FURTHER
    # non-recursive predicate rather than doing the take itself (e.g. inv
    # calls A, A's own body calls B, and B is where `take <Name> = ...`
    # actually lives) - checking only the directly-called predicate's own
    # body (one hop) misses this. Walk the FULL call graph
    # _build_predicate_graph already computed, from every directly-called
    # predicate, and remember the chain of predicate names from that
    # directly-called predicate down to each one reachable - every link in
    # that chain has to be checked for soundness below, not just the
    # deepest one, since a chain that only stops dropping things at its
    # last hop is still dropping things one hop up.
    reachable_paths = {}
    for start in called_predicates:
        if start not in predicate_bodies:
            continue
        for pred, path in _reachable_chain(predicate_calls, start).items():
            if pred not in reachable_paths or len(path) < len(reachable_paths[pred]):
                reachable_paths[pred] = path

    def chain_is_sound(path):
        return all(
            pred in predicate_bodies
            and _predicate_body_fully_uses_its_own_takes(predicate_bodies[pred])
            for pred in path
        )

    violations = []
    for name in names:
        take_re = re.compile(rf"\btake\s+{re.escape(name)}\s*=")
        total_mentions = len(re.findall(rf"\b{re.escape(name)}\b", inv_text))
        if take_re.search(inv_text):
            if total_mentions < 2:
                violations.append({"name": name, "reason": "taken but never used again"})
            continue
        name_take_re = re.compile(rf"\btake\s+{re.escape(name)}\s*=")
        delegated = any(
            name_take_re.search(predicate_bodies.get(pred, "")) and chain_is_sound(path)
            for pred, path in reachable_paths.items()
        )
        if not delegated:
            violations.append({"name": name, "reason": "never taken"})
    return violations


# A CN comparison/arithmetic operator -- used by _looks_like_literal_cn_fact
# as the signal that a Template line is ready-to-use syntax (a bound, an
# equation, a full proposition) rather than descriptive prose.
_CN_FACT_OPERATOR_RE = re.compile(r"==|<=|>=|!=")

# Common English words that show up in a Template's *prose* lines (ghost-
# variable descriptions, or a plain-English walkthrough like worked example
# 6's "par and r walk down the tree together, par one step behind r.") but
# never in real CN syntax. Used to reject a line that happens to contain a
# comparison-looking operator inside what's actually still prose.
_PROSE_STOPWORDS_RE = re.compile(
    r"\b(is|of|with|the|and|walk|walks|together|behind|one|step|down|through|address|type|node|root)\b",
    re.IGNORECASE,
)


def _looks_like_literal_cn_fact(line: str) -> bool:
    """Is this Template line ready-to-use CN syntax the returned inv is
    expected to carry through verbatim, rather than a ghost-variable
    declaration (handled separately by find_unused_provided_takes) or
    plain descriptive prose (which never belongs in an inv at all)?"""
    if re.match(r"^\{\s*\w+\s*\}\s*unchanged\b", line):
        return True
    if not _CN_FACT_OPERATOR_RE.search(line):
        return False
    return not _PROSE_STOPWORDS_RE.search(line)


def find_missing_template_facts(template_text: str, inv_text: str):
    """A Template comment doesn't just name ghost variables to take -- it
    sometimes hands over ready-to-use CN facts verbatim: a bound like
    "0u32 <= i;", a `{h} unchanged` clause, or a full pure proposition like
    "n + length(Lcurr) == length(L)" (worked examples 1/2). These aren't
    something to re-derive; the returned inv is expected to carry them
    through as-is, the same way it's expected to take every ghost variable
    the template names. This checks that every such literal-fact line in
    the template shows up in the inv, compared after normalizing
    whitespace and a trailing semicolon so "0u32 <= i;" (template) still
    matches "0u32 <= i" (inv) or vice versa.

    Ghost-variable declaration lines ("<Name> is ...") are not facts in
    this sense -- find_unused_provided_takes already covers them -- and
    plain descriptive prose (worked example 6's "par and r walk down the
    tree together...") is deliberately never treated as a fact to carry
    through; see _looks_like_literal_cn_fact."""
    def normalize(s):
        return re.sub(r"\s+", " ", s.strip()).rstrip(";").strip()

    inv_norm = normalize(inv_text)
    missing = []
    for line in template_text.splitlines():
        line = line.strip()
        if not line or re.match(r"^[A-Z]\w*\s+is\b", line):
            continue
        if not _looks_like_literal_cn_fact(line):
            continue
        fact_norm = normalize(line)
        if fact_norm and fact_norm not in inv_norm:
            missing.append({"fact": line})
    return missing


def validate_strict_output_contract(response_text: str):
    """Enforce the HARNESS OUTPUT CONTRACT literally, rather than tolerate
    extra content and try to disambiguate it after the fact: the ENTIRE
    response (after stripping at most one optional wrapping markdown code
    fence -- see _WRAPPING_FENCE_RE) must be nothing but whitespace, one
    /*@NEWPRED ... @*/ block, whitespace, one /*@NEWFUNC ... @*/ block,
    whitespace, one /*@INV ... @*/ block, and whitespace. Any other
    content anywhere -- a preamble, reasoning, "wait, let me reconsider",
    a second copy of any block, trailing remarks -- fails the match.

    This replaces the earlier, more permissive design (extract_split_
    response + select_target_inv), which tolerated reasoning text and a
    resulting multiple-INV-blocks case, and tried to pick the right one
    via a ghost-variable heuristic. That was solving the wrong problem:
    if the contract simply disallows anything but the three blocks, a
    model reasoning out loud in the same response ("wait, let me
    reconsider...") is caught immediately as a contract violation, and
    there's no block-selection ambiguity left to resolve at all -- the
    model must do its reasoning silently and reply with only the answer.

    Returns (ok, result):
      - ok=True:  result is {"predicates", "functions", "inv"}, each
                  block's body, stripped.
      - ok=False: result is a short string describing the violation,
                  suitable for embedding directly in a reprompt
                  message."""
    text = response_text
    fence_m = _WRAPPING_FENCE_RE.match(text.strip())
    if fence_m:
        text = fence_m.group("body")

    m = STRICT_RESPONSE_RE.match(text)
    if m:
        return True, {
            "predicates": m.group("predicates").strip(),
            "functions": m.group("functions").strip(),
            "inv": m.group("inv").strip(),
        }

    inv_count = len(INV_BLOCK_RE.findall(text))
    pred_count = len(PRED_BLOCK_RE.findall(text))
    func_count = len(FUNC_BLOCK_RE.findall(text))
    if inv_count == 0:
        return False, "no `/*@INV ... @*/` block was found anywhere in the response"
    if inv_count > 1 or pred_count > 1 or func_count > 1:
        return False, (
            "more than one copy of a NEWPRED/NEWFUNC/INV block was found -- "
            "the response must contain exactly one of each"
        )
    return False, (
        "the response contains content other than the three NEWPRED/"
        "NEWFUNC/INV blocks -- e.g. reasoning text, a preamble, or "
        "anything before, after, or between the blocks. Do all reasoning "
        "silently; the response itself must be ONLY the three blocks, in "
        "order, with nothing else"
    )


def _split_top_level_defs(block_text: str, def_re):
    """Split a block of one or more concatenated `predicate .../function
    ...` definitions into a list of (name, full_definition_text) pairs,
    using brace matching (a regex alone can't balance the nested `match
    { ... }` blocks a body may contain) to find each definition's extent."""
    defs = []
    for m in def_re.finditer(block_text):
        name = m.group("name")
        open_brace = m.end() - 1
        close_brace = _find_matching_brace(block_text, open_brace)
        if close_brace == -1:
            continue
        defs.append((name, block_text[m.start(): close_brace + 1]))
    return defs


def dedupe_new_defs(predicates_text: str, functions_text: str, attempt_text: str):
    """Drop any predicate/function the model resent that's already defined
    (by name) in attempt_text. Harmless to drop silently: editing an
    existing definition is prohibited anyway (per the prompt's "only add,
    never remove/rename" rule), so a same-named "new" definition is either
    an accidental, no-op resend of something already there, or would just
    be a duplicate-name compile error once spliced in -- neither is worth
    spending a reprompt on. Returns (deduped_predicates, deduped_functions).

    A second, load-bearing side effect: this is also what makes the
    NEWPRED/NEWFUNC blocks robust to anything that isn't a real definition.
    _split_top_level_defs only ever extracts text spanning a matched
    `predicate`/`function` keyword through its closing brace (via
    PRED_DEF_RE/FUNC_DEF_RE + brace matching) and this function then
    rebuilds the block from just those spans, joined by blank lines --
    so whatever the model puts *between* definitions (blank lines, prose,
    or a stray repeated "NEWPRED"/"NEWFUNC" label if the model mistakenly
    treats the label as needing to precede every single definition rather
    than just the block once) is silently discarded, never spliced into
    the real file. The model is free to put multiple new predicates/
    functions in the one NEWPRED/NEWFUNC block it's allowed (the output
    contract permits exactly one of each -- see
    validate_strict_output_contract) -- only well-formed definitions
    within it ever survive to the spliced candidate."""
    existing = existing_function_names(attempt_text)

    def _filter(block_text, def_re):
        kept = [full for name, full in _split_top_level_defs(block_text, def_re) if name not in existing]
        return "\n\n".join(kept)

    return _filter(predicates_text, PRED_DEF_RE), _filter(functions_text, FUNC_DEF_RE)


def apply_split_response(attempt_text: str, target_loop_index: int, inv_text: str,
                          predicates_text: str, functions_text: str):
    """Deterministically build the candidate file by splicing the model's
    returned predicate/function definitions and inv text into attempt_text,
    instead of trusting the model to return (and not accidentally disturb)
    the whole file. Returns None on a structural mismatch (target_loop_index
    doesn't exist in attempt_text, or the preamble anchor below can't be
    found) -- reported as a harness-level error, same as a parse failure.

    New definitions are inserted as a fresh, separate `/*@ ... @*/` block of
    their own, placed right before PREAMBLE_SEPARATOR_RE -- a literal
    `/*----...----*/` comment every benchmark file now has by hand, right
    after the preamble's last `/*@ ... @*/` block and right before the
    first real C function declaration in the file (bstDelete.c, for
    instance, has two separate preamble blocks; the separator sits after
    both, before its first function).

    An earlier version of this anchor was a keyword heuristic: find the
    first `requires` in the file, then the nearest preceding `@*/`, on the
    assumption that `requires` only appears inside a function's own
    contract and the first one found belongs to the function-under-test.
    That assumption breaks the moment a *helper* function -- one with only
    an `ensures` clause, no `requires` -- sits between the preamble and the
    function-under-test (see copyList.c's `allocateNode`): the first
    `requires` in the file is still the function-under-test's, but the
    nearest preceding `@*/` is the helper's own spec-closing one, not the
    preamble's, so new definitions got spliced between the helper's spec
    and its body, corrupting it. A literal separator has no such
    assumption to violate -- it's placed by hand at the one unambiguous
    point that's always correct, before ANY function in the file, and it
    naturally preserves declaration-before-use for anything the new
    definitions need, since everything already in the file comes before
    it.

    The inv text is spliced in as-is (just given a leading `inv` keyword if
    it's missing one -- see the fallback below): the model is asked to
    write ordinary CN inv syntax, which already starts with the word `inv`
    in every worked example, so there's nothing here to strip or re-add on
    the happy path."""
    text = attempt_text

    new_defs = "\n\n".join(t for t in (predicates_text, functions_text) if t.strip())
    if new_defs:
        sep_m = PREAMBLE_SEPARATOR_RE.search(text)
        if sep_m is None:
            return None
        insertion_point = sep_m.start()
        text = text[:insertion_point] + "/*@\n" + new_defs + "\n@*/\n\n" + text[insertion_point:]

    matches = list(TEMPLATE_LOOP_RE.finditer(text))
    if target_loop_index >= len(matches):
        return None
    m = matches[target_loop_index]
    inv_start, inv_end = m.start("inv"), m.end("inv")
    body = inv_text.strip()
    if not re.match(r"^inv\b", body):
        # Safety net, not the expected path: the model was asked to write
        # ordinary inv syntax (which already starts with "inv"), but don't
        # waste a whole reprompt round over a dropped keyword when we can
        # just supply it.
        body = "inv " + body
    new_inv_body = "\n  " + body + "\n"
    # The on-disk placeholder may be a plain comment (`/* inv */`);
    # always emit a real CN annotation around the new body.
    return text[: m.start("open")] + "/*@" + new_inv_body + "@*/" + text[m.end("close") :]


def fill_placeholder_invs(text: str, target_loop_index: int) -> str:
    """CN's grammar is `<loop_spec> ::= CN_INV <condition>+ EOF` (see
    manual/grammar.md) -- an `inv` block needs at least one condition, so
    the bare `/*@ inv @*/` every not-yet-solved templated loop starts as
    is a hard PARSE error for the *whole file*, unconditionally, not just
    for whichever loop happens to be in play. That means a function with
    two or more genuinely separate templated loops can never even parse
    while attempting loop N in isolation, as long as any other loop is
    still bare -- confirmed concretely: addListCount's nested pair and
    bstDelete's two sequential loops both hit this, and historically (in
    the earlier whole-file-return design) the model always ended up
    filling in *every* loop in the function at once, not just the one it
    was nominally asked about, simply because nothing else would parse.

    This auto-fills every OTHER templated loop's still-bare inv (i.e.
    every loop besides target_loop_index whose captured inv body is
    empty/whitespace-only -- an already-solved earlier loop's body is
    non-empty and is left untouched) with the simplest always-valid
    placeholder, `inv true;` (`true` is a valid `<prim_expr>` per the
    grammar, so `true;` is a valid single condition). This is NOT a claim
    that `true` is a correct invariant for that loop -- it almost
    certainly isn't, and cn test's own property-based testing will very
    likely still fail once a generated run actually reaches that loop's
    real checkpoint. The point is narrower: unblock parsing so the loop
    actually under test gets real, loop-specific feedback (a genuine
    entry/preservation/exit/generator failure) instead of the same generic
    whole-file parse error every single time, regardless of how correct
    the loop being tested actually is.

    Re-scans and re-applies one loop at a time (rather than computing all
    the offsets up front) since every edit shifts the positions of
    whatever comes after it in the file."""
    while True:
        matches = list(TEMPLATE_LOOP_RE.finditer(text))
        changed = False
        for i, m in enumerate(matches):
            if i == target_loop_index:
                continue
            # The captured group already includes the literal "inv"
            # keyword from the original placeholder (`/*@ inv @*/`), so a
            # genuinely bare, not-yet-solved loop's stripped body is
            # exactly "inv" -- nothing after it. Anything else (a real
            # take/pure/wand clause following it) means this loop's inv
            # already has real content and must be left alone.
            if m.group("inv").strip() in ("", "inv"):
                # Replace the whole /*@ ... @*/ annotation (markers
                # included) with a plain comment, not a CN annotation.
                # CN's contains_user_spec is false for a loop with no
                # /*@ @*/ at all, so it skips ALL invariant-checking code
                # for this loop -- not just a trivial `inv true;` check --
                # which is fine: this loop isn't the one under test right
                # now, so there's nothing to verify about it yet anyway.
                ann_start, ann_end = m.start("open"), m.end("close")
                text = text[:ann_start] + "/* not yet solved */" + text[ann_end:]
                changed = True
                break
        if not changed:
            return text


# ---------------------------------------------------------------------------
# Anthropic API call
# ---------------------------------------------------------------------------

def get_client():
    try:
        import anthropic
    except ImportError:
        sys.exit(
            "The 'anthropic' package is required. Install it with:\n"
            "    pip3 install anthropic\n"
            "and set ANTHROPIC_API_KEY in your environment."
        )
    if not os.environ.get("ANTHROPIC_API_KEY"):
        sys.exit("ANTHROPIC_API_KEY is not set in the environment.")
    return anthropic.Anthropic()


def call_model(client, model: str, system_prompt: str, user_prompt: str, effort: str = DEFAULT_EFFORT):
    """Returns (response_text, usage) where usage is
    {"input_tokens": int, "output_tokens": int} for that single API call
    (0/0 if the SDK didn't report usage for some reason).

    Claude Opus 5 uses adaptive thinking: Claude itself decides whether and
    how much to think, steered by `output_config.effort` rather than a
    manual `thinking.budget_tokens` (that manual mode is deprecated/
    rejected on this model generation -- see the module docstring). Only
    `type == "text"` blocks are ever extracted into the returned
    response_text, so any thinking block that gets emitted is naturally
    discarded here exactly as it was under the old manual-thinking path.

    Uses `client.messages.stream(...)` rather than a blocking
    `client.messages.create(...)` call. At high effort levels (xhigh/max)
    with a large max_tokens, Anthropic's own SDK requires streaming for any
    request that might run past 10 minutes and raises
    "Streaming is required for operations that may take longer than 10
    minutes" on a plain blocking call otherwise. The harness itself doesn't
    care about incremental tokens -- it drains the stream and only uses the
    final assembled message -- so this is a drop-in replacement, not a
    behavior change."""
    last_err = None
    for attempt in range(1, API_RETRIES + 1):
        try:
            kwargs = dict(
                model=model,
                max_tokens=MAX_TOKENS,
                system=system_prompt,
                messages=[{"role": "user", "content": user_prompt}],
            )
            if effort:
                kwargs["output_config"] = {"effort": effort}
            with client.messages.stream(**kwargs) as stream:
                for _ in stream.text_stream:
                    pass  # incremental tokens aren't needed; only the final message is used
                resp = stream.get_final_message()
            text = "".join(
                block.text for block in resp.content if getattr(block, "type", None) == "text"
            )
            usage_obj = getattr(resp, "usage", None)
            usage = {
                "input_tokens": getattr(usage_obj, "input_tokens", 0) or 0,
                "output_tokens": getattr(usage_obj, "output_tokens", 0) or 0,
            }
            return text, usage
        except Exception as e:  # noqa: BLE001 - genuinely want to retry on anything transient
            last_err = e
            print(f"    [api error, attempt {attempt}/{API_RETRIES}] {e}", file=sys.stderr)
            if attempt < API_RETRIES:
                time.sleep(API_RETRY_BACKOFF_S * attempt)
    raise RuntimeError(f"Anthropic API call failed after {API_RETRIES} attempts: {last_err}")




# ---------------------------------------------------------------------------
# Running cn test
# ---------------------------------------------------------------------------

def run_cn_test(c_file_rel: str, out_dir: Path, timeout_s: int, seed: str = None):
    """Run `CC="clang -std=gnu2x" cn test <c_file_rel> --output-dir <out_dir>
    [--seed <seed>]` from ROOT. Returns
    (passed: bool, timed_out: bool, combined_output: str).
    """
    out_dir.mkdir(parents=True, exist_ok=True)
    env = dict(os.environ)
    env["CC"] = "clang -std=gnu2x"
    cmd = ["cn", "test", c_file_rel, "--output-dir", str(out_dir.relative_to(ROOT))]
    if seed:
        cmd.extend(["--seed", str(seed)])
    try:
        proc = subprocess.run(
            cmd,
            cwd=ROOT,
            env=env,
            capture_output=True,
            text=True,
            timeout=timeout_s,
        )
        combined = proc.stdout + "\n" + proc.stderr
        return proc.returncode == 0, False, combined
    except subprocess.TimeoutExpired as e:
        partial = (e.stdout or "") + "\n" + (e.stderr or "")
        return False, True, partial


# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------

def build_system_prompt() -> str:
    # Only INVARIANT_INFERENCE_PROMPT.md is sent as standing instructions.
    # Its own §10 already gives a one-sentence-per-category summary of the
    # re-prompting protocol, which is enough grounding for the model to
    # self-diagnose a failure; INVARIANT_INFERENCE_REPROMPT.md's full,
    # verbose wording is not resent on every call.
    prompt_md = PROMPT_FILE.read_text()
    return (
        prompt_md
        + "\n\n"
        + textwrap.dedent(
            """
            ---
            HARNESS OUTPUT CONTRACT (read carefully, applies to every response)

            You are being driven by an automated test harness, not a human.
            Do NOT return the whole file. Return exactly three labeled
            blocks and nothing else -- no prose before, after, or between
            them. The harness splices these into the current file itself,
            so it never needs (and will never use) a full copy from you:

            /*@NEWPRED
            ... any NEW predicate definitions you invented, or empty if none ...
            @*/

            /*@NEWFUNC
            ... any NEW function definitions you invented, or empty if none ...
            @*/

            /*@INV
            ... the complete inv for the one loop you were asked about,
            written EXACTLY like every worked example in the prompt above
            -- starting with the word "inv", followed by the take clauses,
            pure facts, and wand if any. Write it once, plainly, the same
            way you'd write it directly into the file ...
            @*/

            NEWPRED/NEWFUNC/INV are just labels so the harness can tell
            the three blocks apart -- they are not CN syntax and must
            never appear anywhere else. Include the NEWPRED/NEWFUNC blocks
            even if empty (just leave the body blank) -- but never include
            a definition that already exists in the file shown to you;
            only genuinely new ones. Return exactly one `/*@INV ... @*/`
            block for the one
            loop in play.

            This is enforced literally: your ENTIRE response must be
            nothing but these three blocks, in this order, with only
            whitespace around and between them. No preamble, no
            explanation, no reasoning, no "wait, let me reconsider" --
            not even a single sentence before or after. If you need to
            think something through, do it silently and only reply once
            you're done; anything else in the response, including a
            second draft of any block, gets the whole response rejected
            and reprompted without ever reaching `cn test`.
            """
        ).strip()
    )


def summarize_output(text: str, timed_out: bool, max_chars: int = SUMMARY_MAX_CHARS) -> str:
    """Best-effort short recap of a past failed attempt's cn test output, for
    use in the "earlier attempts" history block (not the current failure,
    which is still shown in full)."""
    text = (text or "").strip()
    prefix = "[timed out] " if timed_out else ""
    if len(text) <= max_chars:
        return prefix + text
    return prefix + text[:max_chars].rstrip() + " ...[truncated]"


def build_initial_user_prompt(filename: str, loop_line: int, loop_index: int, total_loops: int, file_text: str) -> str:
    return textwrap.dedent(
        f"""
        Benchmark file: `{filename}`

        You are working on loop {loop_index + 1} of {total_loops} in this
        file -- specifically, the one whose `/* Template: ... */` comment
        begins at line {loop_line} of the file below. This is the loop
        currently in play per §3. Any templated loop before this one has
        already been accepted; any templated loop after this one has not
        been reached yet. You are not being asked about either -- only
        about the loop at line {loop_line}.

        Work out this loop's complete `inv` (the take clauses, pure facts,
        and wand if needed), and any new `function`/`predicate`
        definitions you need to invent, per the HARNESS OUTPUT CONTRACT
        above.

        ```c
        {file_text}
        ```
        """
    ).strip()


def build_reprompt_user_prompt(
    filename: str, loop_line: int, loop_index: int, total_loops: int, file_text: str,
    attempt_no: int, max_attempts: int, current_failure: dict, previous_failures: list,
) -> str:
    current_output = current_failure["output"]
    truncated = current_output
    if len(truncated) > MAX_LOG_CHARS:
        truncated = truncated[:MAX_LOG_CHARS] + "\n... [truncated]"
    timeout_note = (
        "\nThe run was killed after exceeding the timeout -- treat this as the "
        "GENERATOR category unless the output below shows it failed earlier "
        "than that." if current_failure["timed_out"] else ""
    )

    if previous_failures:
        history_lines = "\n".join(
            f"- Attempt {h['attempt']}: {'TIMEOUT' if h['timed_out'] else 'FAIL'} -- {h['summary']}"
            for h in previous_failures
        )
        history_block = (
            "Summary of earlier failed attempts on this loop (for context only "
            "-- don't repeat whatever didn't work):\n" + history_lines + "\n\n"
        )
    else:
        history_block = ""

    # Every invariant already tried and rejected FOR THIS LOOP -- current
    # attempt included -- shown verbatim rather than just summarized, so
    # the model can see exactly what it already wrote (not just why it
    # failed) and avoid resubmitting the same text, or a trivial variant
    # of it, again. An attempt rejected before any inv was ever extracted
    # (a contract violation, or a splice failure with no usable inv) has
    # "inv_text" as None and is called out as such rather than omitted --
    # that's still useful context (it tells the model its last response
    # wasn't even in the right shape).
    all_failures = previous_failures + [current_failure]
    tried_inv_lines = []
    for h in all_failures:
        inv_text = h.get("inv_text")
        status = "TIMEOUT" if h["timed_out"] else "FAIL"
        if inv_text:
            tried_inv_lines.append(f"- Attempt {h['attempt']} ({status}):\n  {inv_text}")
        else:
            tried_inv_lines.append(
                f"- Attempt {h['attempt']} ({status}): (no usable invariant was extracted "
                f"from this attempt -- {h['summary']})"
            )
    tried_invs_block = (
        "Invariants already tried and rejected for THIS SPECIFIC LOOP -- do "
        "not resubmit any of these, and don't just restate one with a "
        "cosmetic change; diagnose and fix the actual mistake:\n"
        + "\n".join(tried_inv_lines) + "\n\n"
    )

    return textwrap.dedent(
        f"""
        [Attempt {attempt_no}/{max_attempts}]

        Benchmark file: `{filename}`, loop {loop_index + 1} of {total_loops}
        (line {loop_line}) -- the same loop as before, still the only one
        you're being asked about.

        {tried_invs_block}{history_block}Your most recent submission for this loop did not pass
        `cn test`. Here is the verbatim output from that attempt:{timeout_note}

        ```
        {truncated}
        ```

        Follow the re-prompting protocol (§10) to diagnose whether this is a
        syntax error or a semantic error (and if semantic, which of the 5
        categories), then produce a corrected inv (and predicate/function
        blocks, if needed) per the HARNESS OUTPUT CONTRACT above.

        Current file, for context:

        ```c
        {file_text}
        ```
        """
    ).strip()


# ---------------------------------------------------------------------------
# Per-benchmark driver
# ---------------------------------------------------------------------------

def process_benchmark(client, model, filename: str, max_reprompts: int, timeout_s: int, sleep_s: float,
                       out_dir: Path, seed: str = None, effort: str = DEFAULT_EFFORT):
    bench_start = time.time()
    c_path = TEST_DIR / filename
    base_name = filename[:-2] if filename.endswith(".c") else filename
    bench_out_dir = out_dir / base_name
    bench_out_dir.mkdir(parents=True, exist_ok=True)

    original_text = c_path.read_text()
    loops = find_templated_loops(original_text)
    original_fn_names = existing_function_names(original_text)
    original_predicate_names = existing_predicate_names(original_text)
    max_attempts = 1 + max_reprompts

    result = {
        "file": filename,
        "templated_loops": len(loops),
        "loops": [],
        "tokens": {"input_tokens": 0, "output_tokens": 0},
        "total_reprompts": 0,
        # Sum, across every attempt of every loop, of time spent purely
        # inside `cn test` (i.e. excluding model API latency and the
        # §1.2/§1.8/§1.9 local pre-checks, which never invoke cn test at
        # all). See cn_test_elapsed_s on each individual attempt record for
        # the per-attempt breakdown.
        "cn_test_elapsed_s": 0.0,
    }

    if not loops:
        result["status"] = "no_templated_loops"
        result["elapsed_s"] = round(time.time() - bench_start, 2)
        _write_bench_summary(bench_out_dir, result)
        return result

    current_text = original_text

    for idx, loop in enumerate(loops):
        # Re-locate this loop's line number in the *current* text (earlier
        # loops' accepted invariants may have shifted line numbers).
        live_loops = find_templated_loops(current_text)
        if idx >= len(live_loops):
            # Should not happen, but bail safely if the structure changed
            # unexpectedly.
            result["loops"].append(
                {"index": idx, "status": "error", "detail": "loop count mismatch after prior edits"}
            )
            break
        loop_line = live_loops[idx]["line"]
        checkpoint_text = current_text  # state to restore to if we exhaust attempts
        loop_start = time.time()
        loop_tokens = {"input_tokens": 0, "output_tokens": 0}
        loop_cn_test_elapsed = 0.0

        print(f"[{filename}] loop {idx + 1}/{len(loops)} (line {loop_line}) ...")

        loop_record = {"index": idx, "line": loop_line, "attempts": []}
        solved = False
        attempt_text = current_text
        # Reasoning-effort level for this loop's *next* attempt. Starts at
        # the CLI-requested effort; stepped down (never back up) whenever
        # a response gets truncated before producing any usable text -- see
        # the MAX_TOKENS check below and step_down_effort's own comment.
        current_effort = effort
        # Running record of every failed attempt on *this* loop so far, in
        # order: {"attempt", "timed_out", "output" (full), "summary" (short)}.
        # When building a re-prompt, the last entry is shown in full as the
        # "current failure" and everything before it is shown as a short
        # recap -- not the whole history verbatim, and never the full
        # REPROMPT.md file.
        failure_history = []

        for attempt_no in range(1, max_attempts + 1):
            if attempt_no == 1:
                user_prompt = build_initial_user_prompt(filename, loop_line, idx, len(loops), attempt_text)
            else:
                user_prompt = build_reprompt_user_prompt(
                    filename, loop_line, idx, len(loops), attempt_text, attempt_no, max_attempts,
                    current_failure=failure_history[-1],
                    previous_failures=failure_history[:-1],
                )

            system_prompt = build_system_prompt()
            _save_prompt_debug(bench_out_dir, idx, attempt_no, user_prompt, system_prompt)
            attempt_start = time.time()
            response, usage = call_model(client, model, system_prompt, user_prompt, effort=current_effort)
            attempt_elapsed = round(time.time() - attempt_start, 2)
            ok, contract_result = validate_strict_output_contract(response)

            loop_tokens["input_tokens"] += usage["input_tokens"]
            loop_tokens["output_tokens"] += usage["output_tokens"]

            attempt_log = {
                "attempt": attempt_no, "tokens": usage, "prompt_elapsed_s": attempt_elapsed,
                "effort": current_effort,
            }

            print(
                f"    attempt {attempt_no}/{max_attempts}: prompt used "
                f"{usage['input_tokens']} in / {usage['output_tokens']} out tokens "
                f"({attempt_elapsed}s, effort={current_effort})"
            )

            if not ok:
                # Contract violation: don't touch the working file, but
                # this still consumes one of the 6 attempts.
                # `contract_result` is deliberately NOT named "result" --
                # that name already belongs to this benchmark's own
                # top-level accumulator dict (tokens, loops, status, ...)
                # declared earlier in process_benchmark; reusing it here
                # would silently shadow that outer dict for the rest of
                # the function, since Python has no block scoping.
                attempt_log.update({"parse_error": True, "contract_violation": contract_result})
                # usage.output_tokens counts thinking + text together and
                # cannot exceed MAX_TOKENS -- hitting it exactly (or within
                # a few tokens, since the API can stop a token early) means
                # generation was cut off before finishing, not that the
                # model produced a complete, contract-violating response.
                # Adaptive thinking at high effort can spend the entire
                # budget reasoning and never reach the visible answer (see
                # step_down_effort's docstring) -- that needs a smaller
                # effort next time, not just the same "resend it" nudge.
                truncated = usage["output_tokens"] >= MAX_TOKENS - 4
                if truncated:
                    next_effort = step_down_effort(current_effort)
                    contract_msg = (
                        "[harness] Your previous response was cut off before producing any "
                        f"usable code (it used its entire {usage['output_tokens']}-token budget "
                        "without completing the three-block response) -- most likely it spent "
                        "that budget on open-ended internal reasoning rather than finishing the "
                        "answer. This time, keep your reasoning brief and prioritize emitting "
                        "the NEWPRED/NEWFUNC/INV blocks early in your response, per the "
                        "HARNESS OUTPUT CONTRACT."
                    )
                    if next_effort != current_effort:
                        print(
                            f"    attempt {attempt_no}/{max_attempts}: response truncated at "
                            f"{usage['output_tokens']} tokens (effort={current_effort}) -- "
                            f"stepping down to effort={next_effort} for the next attempt"
                        )
                        current_effort = next_effort
                else:
                    contract_msg = f"[harness] Output contract violation: {contract_result}."
                failure_history.append({
                    "attempt": attempt_no, "timed_out": False, "output": contract_msg,
                    "summary": summarize_output(contract_msg, False), "inv_text": None,
                })
                loop_record["attempts"].append(attempt_log)
                _save_attempt_log(bench_out_dir, idx, attempt_no, response, contract_msg)
                if not truncated:
                    print(f"    attempt {attempt_no}/{max_attempts}: REJECTED (output contract violation -- {contract_result})")
                if sleep_s:
                    time.sleep(sleep_s)
                continue

            split = contract_result

            # This loop's own Template comment, read from the *current*
            # working text -- stable across every attempt on this loop,
            # since apply_split_response only ever replaces the "inv"
            # span, never "tmpl" (see apply_split_response below).
            _loop_matches_now = list(TEMPLATE_LOOP_RE.finditer(attempt_text))
            target_template_text = (
                _loop_matches_now[idx].group("tmpl") if idx < len(_loop_matches_now) else ""
            )

            new_predicates, new_functions = dedupe_new_defs(
                split["predicates"], split["functions"], attempt_text
            )
            candidate = apply_split_response(attempt_text, idx, split["inv"], new_predicates, new_functions)

            if candidate is None:
                attempt_log.update({"parse_error": True})
                parse_err_msg = (
                    "[harness] Could not splice your response into the file -- "
                    "either the target loop's Template/while/inv structure "
                    "couldn't be located, or the file's preamble annotation "
                    "block couldn't be found. Resend your inv/predicate/"
                    "function blocks unchanged in content; if this persists "
                    "it likely means your `inv` block's own /*@ /@*/ markers "
                    "were malformed."
                )
                failure_history.append({
                    "attempt": attempt_no, "timed_out": False, "output": parse_err_msg,
                    "summary": summarize_output(parse_err_msg, False), "inv_text": split["inv"],
                })
                loop_record["attempts"].append(attempt_log)
                _save_attempt_log(bench_out_dir, idx, attempt_no, response, parse_err_msg)
                if sleep_s:
                    time.sleep(sleep_s)
                continue

            # A function with other still-unsolved templated loops besides
            # this one needs every one of them to at least parse (CN's
            # grammar rejects a bare `inv` outright, for the whole file --
            # see fill_placeholder_invs) or cn test can never even start,
            # regardless of how correct THIS loop's own answer is.
            candidate = fill_placeholder_invs(candidate, idx)

            # Write candidate to the working file and to the audit trail.
            c_path.write_text(candidate)
            attempt_c_path = bench_out_dir / f"loop{idx}_attempt{attempt_no}.c"
            attempt_c_path.write_text(candidate)

            # §1.2/§1.8/§1.9 local pre-checks, plus the "did you actually use
            # every take the template handed you" completeness check: don't
            # even spend a `cn test` run on an invariant with one of these
            # known-bad shapes. Unauthorized modification of anything outside
            # this loop's own inv/new-definitions is no longer a check that
            # needs to run at all -- apply_split_response only ever splices
            # in exactly those two things, so nothing else can be touched.
            invented_bool_fns = find_invented_boolean_functions(candidate, original_fn_names)
            fn_violations = find_boolean_fn_smuggling_violations(candidate, invented_bool_fns)
            disjunction_violations = find_disjunctive_equality_violations(candidate)
            nested_wand_violations = find_nested_wand_violations(split["inv"])
            recursive_pred_violations = find_recursive_invented_predicates(candidate, original_predicate_names)
            candidate_predicate_bodies, candidate_predicate_calls = _build_predicate_graph(candidate)
            unused_take_violations = find_unused_provided_takes(
                target_template_text, split["inv"], candidate_predicate_bodies, candidate_predicate_calls
            )
            missing_fact_violations = find_missing_template_facts(target_template_text, split["inv"])
            rule_violations = (
                fn_violations
                or disjunction_violations
                or nested_wand_violations
                or recursive_pred_violations
                or unused_take_violations
                or missing_fact_violations
            )

            if rule_violations:
                msg_parts = [
                    "[harness pre-check -- cn test was NOT run for this attempt]"
                ]
                if fn_violations:
                    # Newly-invented boolean function asserted as a bare,
                    # standalone fact anywhere in the invariant -- star
                    # portion or inside the wand -- nothing in the file has
                    # established it, whether it's an equality, an
                    # inequality, or any other not-yet-checked relationship
                    # (see the checkTwoLists.c-style ListsEqual bug this is
                    # modeled on). Also catches the same thing laundered
                    # through a newly-invented (or edited) predicate.
                    desc = "; ".join(f"`{v['function']}` ({v['via']})" for v in fn_violations)
                    msg_parts.append(
                        f"Your invariant uses a newly-invented boolean function as a bare, "
                        f"standalone fact: {desc}. Per §1.8: a function you invent yourself is "
                        "not yet established by anything in the file, so calling it on its own "
                        "-- whether in the star portion or inside the wand, and whether "
                        "directly or via another predicate you also invented/edited -- is not "
                        "sound, regardless of whether the fact is an equality, an inequality, "
                        "or some other relationship. It's only allowed nested inside another "
                        "function that returns something other than boolean, as an internal "
                        "step in computing that other value -- never asserted by itself. "
                        "Either fold it into such a function, or remove it, and resubmit."
                    )
                if disjunction_violations:
                    desc = "; ".join(f"line {v['line']}: `{v['text']}`" for v in disjunction_violations)
                    msg_parts.append(
                        f"Your file uses the `||` operator: {desc}. Per §1.2, `||` is never "
                        "allowed anywhere in the file -- not in an invariant's star portion or "
                        "wand, and not inside a function/predicate's own body either. Every "
                        "case split must be a genuine `if`/`match` decided by the arguments or "
                        "real program state; `||` is never a legitimate stand-in for that, "
                        "whether it's hedging a fact about a ghost variable or defining \"1 or "
                        "2, whichever\" inside a function body. Rewrite every disjunction as "
                        "nested `if`/`else` (or `if`/`match`) and resubmit."
                    )
                if nested_wand_violations:
                    msg_parts.append(
                        "Your invariant has a `wand(...)` nested inside another `wand(...)`. "
                        "Wands are never nested (see the note in section 1.5). Normalize "
                        "`a -* (b -* c)` to `(a * b) -* c`: one wand whose antecedent holds the "
                        "clauses of both a and b, and whose consequent is c. Use separate, "
                        "non-nested wand clauses if you need more than one wand, and resubmit."
                    )
                if recursive_pred_violations:
                    desc = "; ".join(
                        f"`{v['predicate']}` (cycle: " + " -> ".join(v['cycle']) + ")"
                        for v in recursive_pred_violations
                    )
                    msg_parts.append(
                        f"You invented a recursive predicate: {desc}. Per §1.9: a predicate "
                        "you invent yourself must be non-recursive -- it may never call "
                        "itself, and it may never sit in a cycle (even one routed through an "
                        "edited given predicate) that eventually calls back to it. Calling a "
                        "given predicate that does not call back (e.g. reusing `Treerep` "
                        "without `Treerep` calling you back) is fine. If you need something "
                        "that only covers part of a recursive structure, use the given "
                        "predicate plus a `wand` (§1.5) instead of inventing a new recursive "
                        "predicate. Remove the recursion and resubmit."
                    )
                if unused_take_violations:
                    desc = "; ".join(
                        f"`{v['name']}` ({v['reason']})" for v in unused_take_violations
                    )
                    msg_parts.append(
                        f"The Template comment names a ghost variable your inv doesn't actually "
                        f"use: {desc}. Taking a resource and then never referencing it again "
                        "(in an equation, a wand side, or a pure fact) is not a complete "
                        "invariant -- it's exactly the kind of gap that lets an invariant pass "
                        "`cn test` without actually constraining that part of the heap. Either "
                        "take it and use it in a real fact/equation, or explain (by taking and "
                        "relating it) why it doesn't need one -- but don't drop it silently. "
                        "Resend your inv block with this fixed."
                    )
                if missing_fact_violations:
                    desc = "; ".join(f"`{v['fact']}`" for v in missing_fact_violations)
                    msg_parts.append(
                        f"The Template comment hands you a ready-to-use fact your inv doesn't "
                        f"actually include: {desc}. A bound, an `{{x}} unchanged` clause, or a "
                        "full pure proposition given in the Template isn't something to "
                        "re-derive -- carry it through into your inv as-is, the same way you "
                        "carry through every ghost variable it names. Add the missing fact(s) "
                        "and resubmit."
                    )
                passed, timed_out = False, False
                cn_output = "\n\n".join(msg_parts)
                cn_test_elapsed = 0.0  # cn test was never invoked for this attempt
                print(f"    attempt {attempt_no}/{max_attempts}: REJECTED (local rule check, §1.2/§1.8/§1.9)")
            else:
                cn_test_start = time.time()
                passed, timed_out, cn_output = run_cn_test(
                    str(c_path.relative_to(ROOT)), bench_out_dir, timeout_s, seed=seed
                )
                cn_test_elapsed = round(time.time() - cn_test_start, 2)
            _save_attempt_log(bench_out_dir, idx, attempt_no, candidate, cn_output, is_code=True)

            attempt_log.update({
                "passed": passed,
                "timed_out": timed_out,
                "cn_test_elapsed_s": cn_test_elapsed,
            })
            if rule_violations:
                kinds = []
                if fn_violations:
                    kinds.append("invented_boolean_fact_smuggled")
                if disjunction_violations:
                    kinds.append("disjunction_operator_used")
                if nested_wand_violations:
                    kinds.append("nested_wand")
                if recursive_pred_violations:
                    kinds.append("recursive_invented_predicate")
                if unused_take_violations:
                    kinds.append("unused_provided_take")
                if missing_fact_violations:
                    kinds.append("missing_template_fact")
                attempt_log["rule_violation"] = kinds
            loop_record["attempts"].append(attempt_log)
            loop_cn_test_elapsed += cn_test_elapsed

            if not rule_violations:
                print(
                    f"    attempt {attempt_no}/{max_attempts}: "
                    f"{'PASS' if passed else ('TIMEOUT' if timed_out else 'FAIL')} "
                    f"(cn test: {cn_test_elapsed}s)"
                )

            if passed:
                solved = True
                current_text = candidate
                break

            # Reset to this loop's checkpoint state -- NOT the just-rejected
            # candidate -- before the next attempt. Carrying the rejected
            # candidate forward would leave this loop's inv (and any
            # NEWPRED/NEWFUNC it introduced) sitting in the file shown to
            # the model on the next attempt, which is exactly the wrong
            # invariant that just failed; the model could easily mistake
            # it for an already-accepted starting point rather than
            # something to replace outright. Resetting to checkpoint_text
            # puts this loop's inv back to its "inv true;" placeholder
            # (or bare template, if never filled) while leaving every
            # other loop -- earlier-accepted invariants, later still-
            # unreached loops -- exactly as it was; checkpoint_text never
            # changes across attempts on this same loop, so this is
            # strictly scoped to the loop currently being solved.
            attempt_text = checkpoint_text
            c_path.write_text(checkpoint_text)
            failure_history.append({
                "attempt": attempt_no, "timed_out": timed_out, "output": cn_output,
                "summary": summarize_output(cn_output, timed_out), "inv_text": split["inv"],
            })
            if sleep_s:
                time.sleep(sleep_s)

        if solved:
            loop_record["status"] = "solved"
        else:
            loop_record["status"] = "unresolved"
            # Roll the working file back to its state before this loop was
            # attempted, so smeagolTest/<file>.c doesn't sit at a known-bad
            # candidate.
            c_path.write_text(checkpoint_text)
            current_text = checkpoint_text

        attempts_used = len(loop_record["attempts"])
        loop_record["attempts_used"] = attempts_used
        loop_record["reprompts_used"] = attempts_used - 1  # the initial try isn't a re-prompt
        loop_record["elapsed_s"] = round(time.time() - loop_start, 2)
        loop_record["tokens"] = loop_tokens
        loop_record["cn_test_elapsed_s"] = round(loop_cn_test_elapsed, 2)

        result["tokens"]["input_tokens"] += loop_tokens["input_tokens"]
        result["tokens"]["output_tokens"] += loop_tokens["output_tokens"]
        result["total_reprompts"] += loop_record["reprompts_used"]
        result["cn_test_elapsed_s"] += loop_cn_test_elapsed

        print(
            f"    loop {idx + 1}/{len(loops)} done: {loop_record['status']}, "
            f"{loop_record['reprompts_used']} reprompt(s), "
            f"{loop_tokens['input_tokens']}/{loop_tokens['output_tokens']} in/out tokens, "
            f"{loop_record['elapsed_s']}s total ({loop_record['cn_test_elapsed_s']}s in cn test)"
        )

        result["loops"].append(loop_record)

        if not solved:
            # Per §10.3: don't attempt later loops in the same function once
            # one is unresolved.
            break

    result["status"] = (
        "solved" if all(l["status"] == "solved" for l in result["loops"]) else "partial/unresolved"
    )
    result["elapsed_s"] = round(time.time() - bench_start, 2)
    result["cn_test_elapsed_s"] = round(result["cn_test_elapsed_s"], 2)
    print(
        f"[{filename}] total: {result['status']}, {result['total_reprompts']} reprompt(s), "
        f"{result['tokens']['input_tokens']}/{result['tokens']['output_tokens']} in/out tokens, "
        f"{result['elapsed_s']}s total ({result['cn_test_elapsed_s']}s in cn test)"
    )
    _write_bench_summary(bench_out_dir, result)
    return result


def _write_bench_summary(bench_out_dir: Path, result: dict):
    (bench_out_dir / "summary.json").write_text(json.dumps(result, indent=2))


def _save_attempt_log(bench_out_dir: Path, loop_idx: int, attempt_no: int, code_or_response: str,
                       cn_output: str, is_code: bool = False):
    log_path = bench_out_dir / f"loop{loop_idx}_attempt{attempt_no}.log"
    log_path.write_text(cn_output)
    if not is_code:
        raw_path = bench_out_dir / f"loop{loop_idx}_attempt{attempt_no}_raw_response.txt"
        raw_path.write_text(code_or_response)


def _save_prompt_debug(bench_out_dir: Path, loop_idx: int, attempt_no: int,
                        user_prompt: str, system_prompt: str):
    """Persist the exact prompt text sent to the model for this attempt --
    for debugging, alongside the raw response _save_attempt_log already
    writes. The user prompt (which states the filename, which loop is in
    play by index/line, the current file content, and -- on a reprompt --
    the failure history) is written per attempt, since it changes every
    time. The system prompt (the full INVARIANT_INFERENCE_PROMPT.md
    contents plus the HARNESS OUTPUT CONTRACT appendix -- see
    build_system_prompt) is identical across every attempt and every loop
    of a single benchmark run, so it's written once per benchmark rather
    than duplicated into every attempt's own file."""
    user_path = bench_out_dir / f"loop{loop_idx}_attempt{attempt_no}_user_prompt.txt"
    user_path.write_text(user_prompt)
    system_path = bench_out_dir / "system_prompt.md"
    if not system_path.exists():
        system_path.write_text(system_prompt)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--only", action="append", help="Only run this benchmark filename (repeatable).")
    ap.add_argument("--model", default=DEFAULT_MODEL, help=f"Model id (default: {DEFAULT_MODEL})")
    ap.add_argument("--max-rounds", type=int, default=DEFAULT_MAX_REPROMPTS,
                     help="Max re-prompts per loop, in addition to the initial attempt (default: 10)")
    ap.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_S,
                     help="Timeout in seconds for each `cn test` invocation (default: 120)")
    ap.add_argument("--sleep", type=float, default=0.0, help="Seconds to sleep between API calls.")
    ap.add_argument("--seed", default=None,
                     help="Seed passed through to every `cn test` invocation via --seed "
                          "(default: none, i.e. cn test's own default random behavior).")
    ap.add_argument("--out-dir", default=DEFAULT_OUT_DIR_NAME,
                     help=f"Directory (relative to the cn project root, or absolute) to write "
                          f"per-benchmark results into (default: {DEFAULT_OUT_DIR_NAME}). Use a "
                          "different value per run to keep multiple benchmark rounds separate, "
                          "e.g. smeagolOpDir1, smeagolOpDir2, ...")
    ap.add_argument("--effort", default=DEFAULT_EFFORT, choices=["low", "medium", "high", "xhigh", "max"],
                     help=f"output_config.effort level per API call (default: {DEFAULT_EFFORT}). "
                          "Controls adaptive-thinking depth and overall response thoroughness; "
                          "the Claude API's own default is \"high\", this script starts one step "
                          "above that since Anthropic recommends xhigh for demanding coding/"
                          "agentic work.")
    ap.add_argument("--test-dir", default=None,
                     help="Override the working benchmark directory (relative to the cn "
                          "project root, or absolute) instead of the default smeagolTest/. "
                          "The harness reads AND permanently mutates every .c file in this "
                          "directory as it solves loops, so two invocations running at the "
                          "same time (e.g. comparing against a different model/profile's own "
                          "sweep) need their own separate copy each -- point them at different "
                          "--test-dir values (each pre-synced from smeagolInfer/) to avoid "
                          "clobbering each other's working files.")
    args = ap.parse_args()

    global TEST_DIR
    if args.test_dir:
        TEST_DIR = Path(args.test_dir)
        if not TEST_DIR.is_absolute():
            TEST_DIR = ROOT / TEST_DIR

    if not TEST_DIR.is_dir():
        sys.exit(f"Expected benchmark directory not found: {TEST_DIR}")
    if not PROMPT_FILE.is_file():
        sys.exit(f"Expected prompt doc not found: {PROMPT_FILE}")

    out_dir = Path(args.out_dir)
    if not out_dir.is_absolute():
        out_dir = ROOT / out_dir
    out_dir.mkdir(parents=True, exist_ok=True)

    if args.only:
        benchmarks = args.only
    else:
        benchmarks = sorted(p.name for p in TEST_DIR.glob("*.c"))

    client = get_client()

    summary = {
        "model": args.model, "max_rounds": args.max_rounds, "timeout_s": args.timeout,
        "seed": args.seed, "out_dir": str(out_dir), "effort": args.effort,
        "results": [],
    }

    for filename in benchmarks:
        print(f"\n=== {filename} ===")
        try:
            result = process_benchmark(
                client, args.model, filename, args.max_rounds, args.timeout, args.sleep,
                out_dir=out_dir, seed=args.seed, effort=args.effort,
            )
        except Exception as e:  # noqa: BLE001 - keep going on the rest of the suite
            print(f"    [harness error] {e}", file=sys.stderr)
            result = {"file": filename, "status": "harness_error", "detail": str(e)}
        summary["results"].append(result)

    total_in = total_out = total_reprompts = 0
    total_elapsed = 0.0
    total_cn_test_elapsed = 0.0
    print("\n\n=== Run report ===")
    print(
        f"{'file':<22} {'status':<20} {'reprompts':>9} {'in/out tokens':>16} "
        f"{'time (s)':>9} {'cn test (s)':>12}"
    )
    for r in summary["results"]:
        tokens = r.get("tokens", {"input_tokens": 0, "output_tokens": 0})
        reprompts = r.get("total_reprompts", 0)
        elapsed = r.get("elapsed_s", 0.0)
        cn_test_elapsed = r.get("cn_test_elapsed_s", 0.0)
        total_in += tokens.get("input_tokens", 0)
        total_out += tokens.get("output_tokens", 0)
        total_reprompts += reprompts
        total_elapsed += elapsed
        total_cn_test_elapsed += cn_test_elapsed
        tok_str = f"{tokens.get('input_tokens', 0)}/{tokens.get('output_tokens', 0)}"
        print(
            f"{r['file']:<22} {str(r.get('status')):<20} {reprompts:>9} {tok_str:>16} "
            f"{elapsed:>9} {cn_test_elapsed:>12}"
        )
    print("-" * 92)
    print(
        f"TOTAL: {total_reprompts} reprompt(s), {total_in}/{total_out} in/out tokens, "
        f"{round(total_elapsed, 2)}s wall time (sum across benchmarks, run serially), "
        f"{round(total_cn_test_elapsed, 2)}s of which was spent inside cn test"
    )
    print(
        f"\nPer-benchmark detail written to {out_dir.name}/<name>/summary.json "
        "for each benchmark run above."
    )


if __name__ == "__main__":
    main()
