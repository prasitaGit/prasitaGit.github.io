#!/usr/bin/env python3
"""
run_opus_seeds.py
-------------------
Runs the full (non-ablation) Opus harness -- run_infer_benchmarks_opus5.py --
once per seed, sequentially, for whichever seeds are given.

Before each seed's run, smeagolTest_opus/ (Opus's own test-dir, kept
separate from Haiku's smeagolTest/ via --test-dir so the two can't collide)
is fully reset to an exact copy of smeagolInfer/ (rsync -a --delete), so
every seed starts from the same pristine templated state -- no invariant
solved on a previous seed leaks into the next one.

Equivalent to running, one after another, for each seed in --seeds:

    rsync -a --delete smeagolInfer/ smeagolTest_opus/
    python3 run_infer_benchmarks_opus5.py --seed <seed> \
        --test-dir smeagolTest_opus --out-dir opus_seed<seed>

Run this from anywhere; it locates the cn/ directory relative to itself.

Usage:
    python3 run_opus_seeds.py --seeds 35 36 37
    python3 run_opus_seeds.py --seeds 35 36 37 --only addOne.c
    python3 run_opus_seeds.py --seeds 35 36 37 --max-rounds 10 --timeout 120 --effort high
"""

import argparse
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SCRIPT = "run_infer_benchmarks_opus5.py"
TEST_DIR = "smeagolTest_opus"
OUT_DIR_PREFIX = "opus_seed"


def reset_test_dir() -> None:
    dst_dir = ROOT / TEST_DIR
    dst_dir.mkdir(parents=True, exist_ok=True)
    subprocess.run(
        ["rsync", "-a", "--delete", str(ROOT / "smeagolInfer") + "/", str(dst_dir) + "/"],
        check=True,
    )


def run_one(seed, extra_args: list[str]) -> int:
    out_dir = f"{OUT_DIR_PREFIX}{seed}"
    print(f"=== opus (seed {seed}) -> {out_dir} ===")
    reset_test_dir()

    cmd = [
        sys.executable, SCRIPT,
        "--seed", str(seed),
        "--test-dir", TEST_DIR,
        "--out-dir", out_dir,
    ] + extra_args
    proc = subprocess.run(cmd, cwd=ROOT)
    if proc.returncode != 0:
        print(f"!!! seed {seed} exited with code {proc.returncode} -- continuing with the rest !!!")
    print()
    return proc.returncode


def main() -> None:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--seeds", type=int, nargs="+", default=[35, 36, 37],
                     help="Seeds to run, in order (default: 35 36 37).")
    ap.add_argument("--only", action="append",
                     help="Only run this benchmark filename (repeatable); passed through to run_infer_benchmarks_opus5.py.")
    ap.add_argument("--max-rounds", type=int, default=None,
                     help="Passed through to --max-rounds (default: that script's own default).")
    ap.add_argument("--timeout", type=int, default=None,
                     help="Passed through to --timeout (default: that script's own default).")
    ap.add_argument("--sleep", type=float, default=None,
                     help="Passed through to --sleep.")
    ap.add_argument("--effort", default=None, choices=["low", "medium", "high", "xhigh", "max"],
                     help="Passed through to --effort (default: that script's own default).")
    args = ap.parse_args()

    extra_args = []
    if args.only:
        for f in args.only:
            extra_args += ["--only", f]
    if args.max_rounds is not None:
        extra_args += ["--max-rounds", str(args.max_rounds)]
    if args.timeout is not None:
        extra_args += ["--timeout", str(args.timeout)]
    if args.sleep is not None:
        extra_args += ["--sleep", str(args.sleep)]
    if args.effort is not None:
        extra_args += ["--effort", args.effort]

    exit_codes = []
    for seed in args.seeds:
        exit_codes.append(run_one(seed, extra_args))

    print("All Opus seed runs complete: "
          + ", ".join(f"seed {s} -> {'ok' if c == 0 else f'exit {c}'}"
                       for s, c in zip(args.seeds, exit_codes)))
    sys.exit(0 if all(c == 0 for c in exit_codes) else 1)


if __name__ == "__main__":
    main()
