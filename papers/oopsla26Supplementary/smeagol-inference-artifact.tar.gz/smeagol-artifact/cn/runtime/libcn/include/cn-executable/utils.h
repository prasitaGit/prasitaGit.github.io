
#ifndef CN_UTILS
#define CN_UTILS

#include "bump_alloc.h"
#include "fulminate_alloc.h"
#include "hash_table.h"
#include "rts_deps.h"
#include "stack.h"

#define fallthrough __attribute__((__fallthrough__))

#define cn_printf(level, ...)                                                            \
  if (get_cn_logging_level() >= level) {                                                 \
    printf(__VA_ARGS__);                                                                 \
  }

// XXX: things used by injected code
#define true  1
#define false 0

#ifdef __cplusplus
extern "C" {
#endif

enum spec_mode {
  PRE = 1,
  POST = 2,
  LOOP = 3,
  STATEMENT = 4,
  C_ACCESS = 5,
  NON_SPEC = 6,
  /* testing-only magic wand: check ownership of an antecedent resource and
     read its value, WITHOUT consuming it (no ghost-state retag) - see
     cn_get_or_put_ownership in utils.c */
  WAND_PEEK = 7
};

enum region_owned {
  NO_WILDCARD,
  SOME_WILDCARD,
  FULL_WILDCARD,
};

/* Error handlers */
void fulminate_destroy(void);
void fulminate_init(void);

enum cn_logging_level {
  CN_LOGGING_NONE = 0,
  CN_LOGGING_ERROR = 1,
  CN_LOGGING_INFO = 2
};

enum cn_logging_level get_cn_logging_level(void);

/** Sets the logging level, returning the previous one */
enum cn_logging_level set_cn_logging_level(enum cn_logging_level new_level);

enum cn_trace_granularity {
  CN_TRACE_NONE = 0,
  CN_TRACE_ENDS = 1,
  CN_TRACE_ALL = 2,
};

enum cn_trace_granularity get_cn_trace_granularity(void);

/** Sets the trace granularity, returning the previous one */
enum cn_trace_granularity set_cn_trace_granularity(
    enum cn_trace_granularity new_granularity);

void cn_print_nr_owned_predicates(void);

struct cn_error_message_info {
  const char* function_name;
  char* file_name;
  int line_number;
  char* cn_source_loc;
  struct cn_error_message_info* parent;
  struct cn_error_message_info* child;
};

void initialise_error_msg_info_(
    const char* function_name, char* file_name, int line_number);

#define initialise_error_msg_info()                                                      \
  initialise_error_msg_info_(__func__, __FILE__, __LINE__)

void reset_error_msg_info(void);
void free_error_msg_info(void);

void update_error_message_info_(
    const char* function_name, char* file_name, int line_number, char* cn_source_loc);

void cn_pop_msg_info(void);

/* Prints the source-location trail for a failing check (same formatting
   every existing "[CN WAND] ..." failure message already uses) - exposed
   here, alongside a getter for the current global error-info pointer, so
   other translation units (e.g. wand.c's own new overlap-check failure
   path) can report a failure with the same location info ordinary
   in-utils.c checks already attach, without needing their own copy of
   this logic. */
void print_error_msg_info(struct cn_error_message_info* info);
struct cn_error_message_info* get_global_error_msg_info(void);

#define update_cn_error_message_info(x)                                                  \
  update_error_message_info_(__func__, __FILE__, __LINE__ + 1, x)

#define update_cn_error_message_info_access_check(x)                                     \
  update_error_message_info_(__func__, __FILE__, __LINE__, x)

/* Wrappers for C types */

/* Signed bitvectors */

typedef struct cn_bits_i8 {
  int8_t val;
} cn_bits_i8;

typedef struct cn_bits_i16 {
  int16_t val;
} cn_bits_i16;

typedef struct cn_bits_i32 {
  int32_t val;
} cn_bits_i32;

typedef struct cn_bits_i64 {
  int64_t val;
} cn_bits_i64;

/* Unsigned bitvectors */

typedef struct cn_bits_u8 {
  uint8_t val;
} cn_bits_u8;

typedef struct cn_bits_u16 {
  uint16_t val;
} cn_bits_u16;

typedef struct cn_bits_u32 {
  uint32_t val;
} cn_bits_u32;

typedef struct cn_bits_u64 {
  uint64_t val;
} cn_bits_u64;

typedef struct cn_integer {
  int64_t val;
} cn_integer;

typedef struct cn_pointer {
  void* ptr;
} cn_pointer;

typedef struct cn_bool {
  bool val;
} cn_bool;

typedef struct cn_alloc_id {
  uint8_t val;
} cn_alloc_id;

typedef hash_table cn_map;

void initialise_ownership_ghost_state(void);
void free_ownership_ghost_state(void);
void initialise_ghost_stack_depth(void);
void initialise_exec_c_locs_mode(bool flag);
void initialise_correct_missing_ownership(bool flag);
void initialise_ownership_stack_mode(bool flag);
signed long get_cn_stack_depth(void);
void ghost_stack_depth_incr(void);
void ghost_stack_depth_decr(void);
void cn_postcondition_leak_check(void);

struct loop_ownership* initialise_loop_ownership_state(void);
void cn_loop_leak_check(void);
void cn_loop_put_back_ownership(struct loop_ownership* loop_ownership);

/* Testing-only: does the given loop invariant-check pass's own recorded
   take-ranges (loop_ownership, populated by cn_add_to_loop_ownership_state
   every time a LOOP-mode take succeeds - see cn_loop_get_ownership in
   utils.c) fully cover [generic_c_ptr, generic_c_ptr + size)? Used by
   c_ownership_check_loop_tolerant to recognize an address already claimed
   for real by an earlier take in this same pass - see the long comment
   above cn_wand_construct_depth in utils.c for the motivating bstDelete.c
   scenario and why this is more precise than a bare depth check. */
_Bool cn_loop_ownership_contains(
    void* generic_c_ptr, size_t size, struct loop_ownership* loop_ownership);

/* malloc, free */
void* cn_aligned_alloc(size_t align, size_t size);
void* cn_unsafe_aligned_alloc(size_t align, size_t size);
void* cn_malloc(size_t size);
void* cn_unsafe_malloc(size_t size);
void* cn_calloc(size_t num, size_t size);
void* cn_unsafe_calloc(size_t num, size_t size);
void cn_free_sized(void*, size_t len);

/* Is any part of the region still tracked in the ownership ghost state?
   False once cn_free_sized has removed it. See utils.c. */
_Bool cn_ownership_region_tracked(void* ptr, size_t size);

void cn_print_nr_u64(int i, unsigned long u);
void cn_print_u64(const char* str, unsigned long u);
void dump_ownership_ghost_state(int stack_depth);
bool is_mapped(void* ptr);

/* cn_failure callbacks */
enum cn_failure_mode {
  CN_FAILURE_ASSERT = 1,
  CN_FAILURE_CHECK_OWNERSHIP,
  CN_FAILURE_OWNERSHIP_LEAK,
  CN_FAILURE_FULM_ALLOC,
  CN_FAILURE_USER_ALLOC,
  CN_FAILURE_GHOST_ARGS
};

typedef void (*cn_failure_callback)(enum cn_failure_mode, enum spec_mode);
void set_cn_failure_cb(cn_failure_callback callback);
void reset_cn_failure_cb(void);
void cn_failure(enum cn_failure_mode failure_mode, enum spec_mode spec_mode);

/* Conversion functions */

cn_bool* convert_to_cn_bool(bool b);
bool convert_from_cn_bool(cn_bool* b);
/* is_layout_fact: true for a predicate-internal assert that mentions a
   pointer/address-valued (BT.Loc) subterm (e.g. Dllrep's own
   `assert(addr_eq(prev, H.prev))`) - see it_mentions_loc_subterm's own
   comment in cn_to_ail.ml. Such a fact is about the CURRENT, already-
   fixed relationship between real addresses, never something a wand's
   own transform function is in the business of changing, so unlike an
   ordinary value fact it must never be bypassed under WAND_PEEK.

   is_wand_consequent: true for an assert compiled from a wand's own
   consequent clause list (mirrors the existing in_wand_consequent flag
   already threaded through LRT.Constraint/LAT.Constraint compilation
   in cn_to_ail.ml). Together with spec_mode == WAND_PEEK (which, given
   the is_layout_fact bypass above, can only reach this function for a
   real layout fact), these two flags let cn_assert print a category-
   specific line on failure - "antecedent, layout" vs "consequent,
   value" - before falling back to the ordinary error report, instead
   of leaving the spec writer to guess which side of the wand broke.

   expr_str: a plain-text rendering of the failing CN constraint itself
   (LogicalConstraints.pp, via Pp.plain, at the generate_cn_assert call
   site), printed alongside the category line so the spec writer sees
   not just THAT something failed under a wand but WHAT specifically -
   e.g. `addr_eq(prev, H.prev)` or `Tcc == AddOne(T)`. */
void cn_assert(cn_bool* cn_b,
    enum spec_mode spec_mode,
    _Bool is_layout_fact,
    _Bool is_wand_consequent,
    const char* expr_str);

cn_bool* cn_bool_and(cn_bool* b1, cn_bool* b2);
void cn_bool_inplace_and(cn_bool* inplace_b1, cn_bool* b2);
cn_bool* cn_bool_or(cn_bool* b1, cn_bool* b2);
cn_bool* cn_bool_not(cn_bool* b);
cn_bool* cn_bool_implies(cn_bool* b1, cn_bool* b2);
cn_bool* cn_bool_equality(cn_bool* b1, cn_bool* b2);
void* cn_ite(cn_bool* b, void* e1, void* e2);

cn_map* map_create(void);
cn_map* cn_map_set(cn_map* m, cn_integer* key, void* value);
cn_map* cn_map_deep_copy(cn_map* m1);
cn_bool* cn_map_equality(
    cn_map* m1, cn_map* m2, cn_bool*(value_equality_fun)(void*, void*));

#define convert_to_cn_map(c_ptr, cntype_conversion_fn, num_elements)                     \
  ({                                                                                     \
    cn_map* m = map_create();                                                            \
    for (int i = 0; i < num_elements; i++) {                                             \
      cn_map_set(m, convert_to_cn_integer(i), cntype_conversion_fn((c_ptr)[i]));         \
    }                                                                                    \
    m;                                                                                   \
  })
#define convert_from_cn_map(arr, m, cntype, num_elements)                                \
  for (int i = 0; i < num_elements; i++) {                                               \
    (arr)[i] = convert_from_##cntype(cn_map_get_##cntype(m, convert_to_cn_integer(i)));  \
  }

cn_bool* cn_pointer_equality(void* i1, void* i2);
cn_bool* cn_pointer_is_null(cn_pointer*);
cn_bool* cn_pointer_le(cn_pointer* i1, cn_pointer* i2);
cn_bool* cn_pointer_lt(cn_pointer* i1, cn_pointer* i2);
cn_bool* cn_pointer_ge(cn_pointer* i1, cn_pointer* i2);
cn_bool* cn_pointer_gt(cn_pointer* i1, cn_pointer* i2);

#define cn_pointer_deref(CN_PTR, CTYPE) *((CTYPE*)CN_PTR->ptr)

/* CN integer type auxilliary functions */

#define CN_GEN_EQUALITY(CNTYPE) CN_GEN_EQUALITY_(CNTYPE)

#define CN_GEN_EQUALITY_(CNTYPE)                                                         \
  static inline cn_bool* CNTYPE##_equality(void* i1, void* i2) {                         \
    return convert_to_cn_bool(((CNTYPE*)i1)->val == ((CNTYPE*)i2)->val);                 \
  }

#define CN_GEN_CONVERT(CTYPE, CNTYPE)                                                    \
  static inline CNTYPE* convert_to_##CNTYPE(CTYPE i) {                                   \
    CNTYPE* ret = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    ret->val = i;                                                                        \
    return ret;                                                                          \
  }

#define CN_GEN_CONVERT_FROM(CTYPE, CNTYPE)                                               \
  static inline CTYPE convert_from_##CNTYPE(CNTYPE* i) {                                 \
    return i->val;                                                                       \
  }

/* Arithmetic operators */

#define CN_GEN_LT(CNTYPE)                                                                \
  static inline cn_bool* CNTYPE##_lt(CNTYPE* i1, CNTYPE* i2) {                           \
    return convert_to_cn_bool(i1->val < i2->val);                                        \
  }

#define CN_GEN_LE(CNTYPE)                                                                \
  static inline cn_bool* CNTYPE##_le(CNTYPE* i1, CNTYPE* i2) {                           \
    return convert_to_cn_bool(i1->val <= i2->val);                                       \
  }

#define CN_GEN_GT(CNTYPE)                                                                \
  static inline cn_bool* CNTYPE##_gt(CNTYPE* i1, CNTYPE* i2) {                           \
    return convert_to_cn_bool(i1->val > i2->val);                                        \
  }

#define CN_GEN_GE(CNTYPE)                                                                \
  static inline cn_bool* CNTYPE##_ge(CNTYPE* i1, CNTYPE* i2) {                           \
    return convert_to_cn_bool(i1->val >= i2->val);                                       \
  }

#define CN_GEN_NEGATE(CNTYPE)                                                            \
  static inline CNTYPE* CNTYPE##_negate(CNTYPE* i) {                                     \
    return convert_to_##CNTYPE(-(i->val));                                               \
  }

#define CN_GEN_BW_COMPL(CNTYPE)                                                          \
  static inline CNTYPE* CNTYPE##_bw_compl(CNTYPE* i) {                                   \
    return convert_to_##CNTYPE(~(i->val));                                               \
  }

#define CN_GEN_ADD(UCTYPE, CTYPE, CNTYPE)                                                \
  static inline CNTYPE* CNTYPE##_add(CNTYPE* i1, CNTYPE* i2) {                           \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = (UCTYPE)i1->val + (UCTYPE)i2->val;                                        \
    return res;                                                                          \
  }

#define CN_GEN_SUB(UCTYPE, CTYPE, CNTYPE)                                                \
  static inline CNTYPE* CNTYPE##_sub(CNTYPE* i1, CNTYPE* i2) {                           \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = (UCTYPE)i1->val - (UCTYPE)i2->val;                                        \
    return res;                                                                          \
  }

#define CN_GEN_MUL(CTYPE, CNTYPE)                                                        \
  static inline CNTYPE* CNTYPE##_multiply(CNTYPE* i1, CNTYPE* i2) {                      \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val * i2->val;                                                        \
    return res;                                                                          \
  }

#define CN_GEN_DIV(CTYPE, CNTYPE)                                                        \
  static inline CNTYPE* CNTYPE##_divide(CNTYPE* i1, CNTYPE* i2) {                        \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val / i2->val;                                                        \
    return res;                                                                          \
  }

#define CN_GEN_SHIFT_LEFT(CTYPE, CNTYPE)                                                 \
  static inline CNTYPE* CNTYPE##_shift_left(CNTYPE* i1, CNTYPE* i2) {                    \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val << i2->val;                                                       \
    return res;                                                                          \
  }

#define CN_GEN_SHIFT_RIGHT(CTYPE, CNTYPE)                                                \
  static inline CNTYPE* CNTYPE##_shift_right(CNTYPE* i1, CNTYPE* i2) {                   \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val >> i2->val;                                                       \
    return res;                                                                          \
  }

#define CN_GEN_MIN(CNTYPE)                                                               \
  static inline CNTYPE* CNTYPE##_min(CNTYPE* i1, CNTYPE* i2) {                           \
    return convert_from_cn_bool(CNTYPE##_lt(i1, i2)) ? i1 : i2;                          \
  }

#define CN_GEN_MAX(CNTYPE)                                                               \
  static inline CNTYPE* CNTYPE##_max(CNTYPE* i1, CNTYPE* i2) {                           \
    return convert_from_cn_bool(CNTYPE##_gt(i1, i2)) ? i1 : i2;                          \
  }

/* TODO: Account for UB: https://stackoverflow.com/a/20638659 */
#define CN_GEN_MOD(CTYPE, CNTYPE)                                                        \
  static inline CNTYPE* CNTYPE##_mod(CNTYPE* i1, CNTYPE* i2) {                           \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val % i2->val;                                                        \
    if (res->val < 0) {                                                                  \
      res->val = (i2->val < 0) ? res->val - i2->val : res->val + i2->val;                \
    }                                                                                    \
    return res;                                                                          \
  }

#define CN_GEN_REM(CTYPE, CNTYPE)                                                        \
  static inline CNTYPE* CNTYPE##_rem(CNTYPE* i1, CNTYPE* i2) {                           \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val % i2->val;                                                        \
    return res;                                                                          \
  }

#define CN_GEN_XOR(CTYPE, CNTYPE)                                                        \
  static inline CNTYPE* CNTYPE##_xor(CNTYPE* i1, CNTYPE* i2) {                           \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val ^ i2->val;                                                        \
    return res;                                                                          \
  }

#define CN_GEN_BWAND(CTYPE, CNTYPE)                                                      \
  static inline CNTYPE* CNTYPE##_bwand(CNTYPE* i1, CNTYPE* i2) {                         \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val & i2->val;                                                        \
    return res;                                                                          \
  }

#define CN_GEN_BWOR(CTYPE, CNTYPE)                                                       \
  static inline CNTYPE* CNTYPE##_bwor(CNTYPE* i1, CNTYPE* i2) {                          \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = i1->val | i2->val;                                                        \
    return res;                                                                          \
  }

cn_bits_u32* cn_bits_u32_fls(cn_bits_u32* i1);
cn_bits_u64* cn_bits_u64_flsl(cn_bits_u64* i1);

static inline int ipow(int base, int exp) {
  int result = 1;
  for (;;) {
    if (exp & 1)
      result *= base;
    exp >>= 1;
    if (!exp)
      break;
    base *= base;
  }

  return result;
}

#define CN_GEN_POW(CTYPE, CNTYPE)                                                        \
  static inline CNTYPE* CNTYPE##_pow(CNTYPE* i1, CNTYPE* i2) {                           \
    CNTYPE* res = (CNTYPE*)cn_bump_aligned_alloc(alignof(CNTYPE), sizeof(CNTYPE));       \
    res->val = ipow(i1->val, i2->val);                                                   \
    return res;                                                                          \
  }

#define cn_array_shift(cn_ptr, size, index)                                              \
  convert_to_cn_pointer(                                                                 \
      (char*)((uintptr_t)cn_ptr->ptr + (uintptr_t)index->val * (uintptr_t)size))

#define cn_member_shift(cn_ptr, tag, member_name)                                        \
  convert_to_cn_pointer(                                                                 \
      (void*)(((uintptr_t)cn_ptr->ptr) + offsetof(struct tag, member_name)))

#define CN_GEN_INCREMENT(CNTYPE)                                                         \
  static inline CNTYPE* CNTYPE##_increment(CNTYPE* i) {                                  \
    i->val = i->val + 1;                                                                 \
    return i;                                                                            \
  }

#define CN_GEN_PTR_ADD(CNTYPE)                                                           \
  static inline cn_pointer* cn_pointer_add_##CNTYPE(cn_pointer* ptr, CNTYPE* i) {        \
    cn_pointer* res = (cn_pointer*)cn_bump_malloc(sizeof(cn_pointer));                   \
    res->ptr = (char*)ptr->ptr + i->val;                                                 \
    return res;                                                                          \
  }

/* Casting functions */

#define CN_GEN_CAST_TO_PTR(CNTYPE, INTPTR_TYPE)                                          \
  static inline cn_pointer* cast_##CNTYPE##_to_cn_pointer(CNTYPE* i) {                   \
    cn_pointer* res = (cn_pointer*)cn_bump_malloc(sizeof(cn_pointer));                   \
    res->ptr = (void*)(INTPTR_TYPE)i->val;                                               \
    return res;                                                                          \
  }

#define CN_GEN_CAST_FROM_PTR(CTYPE, CNTYPE, INTPTR_TYPE)                                 \
  static inline CNTYPE* cast_cn_pointer_to_##CNTYPE(cn_pointer* ptr) {                   \
    CNTYPE* res = (CNTYPE*)cn_bump_malloc(sizeof(CNTYPE));                               \
    res->val = (CTYPE)(INTPTR_TYPE)(ptr->ptr);                                           \
    return res;                                                                          \
  }

#define CN_GEN_CAST_INT_TYPES(CNTYPE1, CTYPE2, CNTYPE2)                                  \
  static inline CNTYPE2* cast_##CNTYPE1##_to_##CNTYPE2(CNTYPE1* i) {                     \
    CNTYPE2* res = (CNTYPE2*)cn_bump_aligned_alloc(alignof(CNTYPE2), sizeof(CNTYPE2));   \
    res->val = (CTYPE2)i->val;                                                           \
    return res;                                                                          \
  }

#define CN_GEN_DEFAULT(CNTYPE)                                                           \
  static inline CNTYPE* default_##CNTYPE(void) {                                         \
    return convert_to_##CNTYPE(0);                                                       \
  }

cn_map* default_cn_map(void);
cn_bool* default_cn_bool(void);

#define CN_GEN_MAP_GET(CNTYPE)                                                           \
  static inline void* cn_map_get_##CNTYPE(cn_map* m, cn_integer* key) {                  \
    int64_t* key_ptr = (int64_t*)fulm_malloc(sizeof(int64_t), &fulm_default_alloc);      \
    *key_ptr = key->val;                                                                 \
    void* res = ht_get(m, key_ptr);                                                      \
    fulm_free(key_ptr, &fulm_default_alloc);                                             \
    if (!res) {                                                                          \
      return (void*)default_##CNTYPE();                                                  \
    }                                                                                    \
    return res;                                                                          \
  }

#define CN_GEN_CASTS_INNER(CTYPE, CNTYPE)                                                \
  CN_GEN_CAST_INT_TYPES(cn_bits_i8, CTYPE, CNTYPE)                                       \
  CN_GEN_CAST_INT_TYPES(cn_bits_i16, CTYPE, CNTYPE)                                      \
  CN_GEN_CAST_INT_TYPES(cn_bits_i32, CTYPE, CNTYPE)                                      \
  CN_GEN_CAST_INT_TYPES(cn_bits_i64, CTYPE, CNTYPE)                                      \
  CN_GEN_CAST_INT_TYPES(cn_bits_u8, CTYPE, CNTYPE)                                       \
  CN_GEN_CAST_INT_TYPES(cn_bits_u16, CTYPE, CNTYPE)                                      \
  CN_GEN_CAST_INT_TYPES(cn_bits_u32, CTYPE, CNTYPE)                                      \
  CN_GEN_CAST_INT_TYPES(cn_bits_u64, CTYPE, CNTYPE)                                      \
  CN_GEN_CAST_INT_TYPES(cn_integer, CTYPE, CNTYPE)

#define CN_GEN_PTR_CASTS_UNSIGNED(CTYPE, CNTYPE)                                         \
  CN_GEN_CAST_TO_PTR(CNTYPE, uintptr_t)                                                  \
  CN_GEN_CAST_FROM_PTR(CTYPE, CNTYPE, uintptr_t)

#define CN_GEN_PTR_CASTS_SIGNED(CTYPE, CNTYPE)                                           \
  CN_GEN_CAST_TO_PTR(CNTYPE, intptr_t)                                                   \
  CN_GEN_CAST_FROM_PTR(CTYPE, CNTYPE, intptr_t)

#define CN_GEN_ALL(UCTYPE, CTYPE, CNTYPE) CN_GEN_ALL_(UCTYPE, CTYPE, CNTYPE)

#define CN_GEN_ALL_(UCTYPE, CTYPE, CNTYPE)                                               \
  CN_GEN_CONVERT(CTYPE, CNTYPE)                                                          \
  CN_GEN_CONVERT_FROM(CTYPE, CNTYPE)                                                     \
  CN_GEN_EQUALITY(CNTYPE)                                                                \
  CN_GEN_LT(CNTYPE)                                                                      \
  CN_GEN_LE(CNTYPE)                                                                      \
  CN_GEN_GT(CNTYPE)                                                                      \
  CN_GEN_GE(CNTYPE)                                                                      \
  CN_GEN_NEGATE(CNTYPE)                                                                  \
  CN_GEN_BW_COMPL(CNTYPE)                                                                \
  CN_GEN_ADD(UCTYPE, CTYPE, CNTYPE)                                                      \
  CN_GEN_SUB(UCTYPE, CTYPE, CNTYPE)                                                      \
  CN_GEN_MUL(CTYPE, CNTYPE)                                                              \
  CN_GEN_DIV(CTYPE, CNTYPE)                                                              \
  CN_GEN_SHIFT_LEFT(CTYPE, CNTYPE)                                                       \
  CN_GEN_SHIFT_RIGHT(CTYPE, CNTYPE)                                                      \
  CN_GEN_MIN(CNTYPE)                                                                     \
  CN_GEN_MAX(CNTYPE)                                                                     \
  CN_GEN_MOD(CTYPE, CNTYPE)                                                              \
  CN_GEN_REM(CTYPE, CNTYPE)                                                              \
  CN_GEN_XOR(CTYPE, CNTYPE)                                                              \
  CN_GEN_BWAND(CTYPE, CNTYPE)                                                            \
  CN_GEN_BWOR(CTYPE, CNTYPE)                                                             \
  CN_GEN_POW(CTYPE, CNTYPE)                                                              \
  CN_GEN_INCREMENT(CNTYPE)                                                               \
  CN_GEN_PTR_ADD(CNTYPE)                                                                 \
  CN_GEN_CASTS_INNER(CTYPE, CNTYPE)                                                      \
  CN_GEN_DEFAULT(CNTYPE)                                                                 \
  CN_GEN_MAP_GET(CNTYPE)

CN_GEN_ALL(uint8_t, int8_t, cn_bits_i8)
CN_GEN_ALL(uint16_t, int16_t, cn_bits_i16)
CN_GEN_ALL(uint32_t, int32_t, cn_bits_i32)
CN_GEN_ALL(uint64_t, int64_t, cn_bits_i64)
CN_GEN_ALL(uint8_t, uint8_t, cn_bits_u8)
CN_GEN_ALL(uint16_t, uint16_t, cn_bits_u16)
CN_GEN_ALL(uint32_t, uint32_t, cn_bits_u32)
CN_GEN_ALL(uint64_t, uint64_t, cn_bits_u64)
CN_GEN_ALL(unsigned long, signed long, cn_integer)

CN_GEN_PTR_CASTS_SIGNED(int8_t, cn_bits_i8)
CN_GEN_PTR_CASTS_SIGNED(int16_t, cn_bits_i16)
CN_GEN_PTR_CASTS_SIGNED(int32_t, cn_bits_i32)
CN_GEN_PTR_CASTS_SIGNED(int64_t, cn_bits_i64)
CN_GEN_PTR_CASTS_UNSIGNED(uint8_t, cn_bits_u8)
CN_GEN_PTR_CASTS_UNSIGNED(uint16_t, cn_bits_u16)
CN_GEN_PTR_CASTS_UNSIGNED(uint32_t, cn_bits_u32)
CN_GEN_PTR_CASTS_UNSIGNED(uint64_t, cn_bits_u64)
CN_GEN_PTR_CASTS_SIGNED(signed long, cn_integer)

cn_pointer* convert_to_cn_pointer(const void* ptr);
void* convert_from_cn_pointer(cn_pointer* cn_ptr);
cn_pointer* cn_pointer_min(cn_pointer* p, cn_pointer* q);
cn_pointer* cn_pointer_max(cn_pointer* p, cn_pointer* q);
cn_pointer* cn_pointer_mod(cn_pointer* ptr, cn_pointer* n);
cn_pointer* cast_cn_pointer_to_cn_pointer(cn_pointer* p);

CN_GEN_CONVERT(uint8_t, cn_alloc_id)
CN_GEN_EQUALITY(cn_alloc_id)
CN_GEN_DEFAULT(cn_pointer)
CN_GEN_MAP_GET(cn_pointer)
CN_GEN_MAP_GET(cn_map)

/* OWNERSHIP */

// GEN_ALL_STACK(cn_source_location, char*);

// typedef struct ownership_ghost_info {
//   int depth;
//   cn_source_location_stack*
//       source_loc_stack;  // set to null if ownership_stack_mode is disabled
// } ownership_ghost_info;

// enum STACK_OP {
//   PUSH,
//   POP,
//   NO_OP
// };

int ownership_ghost_state_get_depth(int64_t address);
void ownership_ghost_state_set(int64_t address,
    size_t size,
    int stack_depth_val,
    struct cn_error_message_info* error_msg_info);
void ownership_ghost_state_remove(int64_t address, size_t size);

/* CN ownership checking */
void cn_assume_ownership(void* generic_c_ptr, unsigned long size, char* fun);
void cn_get_or_put_ownership(enum spec_mode spec_mode,
    void* generic_c_ptr,
    size_t size,
    struct loop_ownership* loop_ownership);

/* Wand postulate tracking (testing-only): see cn_wand_peek_ownership in
   utils.c. cn_wand_peek_push starts tracking a new wand occurrence;
   cn_wand_peek_and/cn_wand_peek_and_bool record whether one more part of
   its antecedent matched (never aborting); cn_wand_peek_pop finishes
   tracking and reports whether every part matched, so the generated code
   can decide whether to run the wand's consequent. */
void cn_wand_peek_push(void);
void cn_wand_peek_and(_Bool matched);
void cn_wand_peek_and_bool(cn_bool* cn_b);
cn_bool* cn_wand_peek_pop(void);

/* Wand CONSTRUCT-side tracking (testing-only): companion to
   cn_wand_peek_push/pop above, but marks that generated code is currently
   running the real, ownership-consuming "construct" half of a wand rather
   than its read-only "postulate" half. Nestable (a wand's construct can
   itself contain another wand), so this is a depth counter rather than a
   flag.

   This counter's job is now purely a GATE, not a tolerance rule by itself:
   see c_ownership_check_loop_tolerant / cn_loop_ownership_contains in
   utils.c. While cn_wand_construct_depth > 0, a loop-mode take that
   collides with an already-claimed address is allowed to fall back to
   checking the enclosing loop invariant-check pass's own recorded
   take-ranges (loop_ownership) for address-range membership, rather than
   the coarser "is anything at all sitting at depth - 1" check this used to
   enable. The gate itself must stay: without it, an ordinary (non-wand)
   loop invariant with a genuine double-take bug on the same address would
   also find that address already in loop_ownership (added by its own
   first, legitimate take) and wrongly treat the second take as fine. Only
   inside a wand's construct is that address-reuse expected and intentional
   - see the long comment above cn_wand_construct_depth in utils.c for the
   motivating bstDelete.c/ParRep scenario. */
void cn_wand_construct_push(void);
void cn_wand_construct_pop(void);

/* C ownership checking */
void c_add_to_ghost_state(void* ptr_to_local, size_t size, signed long stack_depth);
void c_remove_from_ghost_state(void* ptr_to_local, size_t size);
enum region_owned c_ownership_check(
    char* access_kind, void* generic_c_ptr, int size, signed long expected_stack_depth);
enum region_owned c_ownership_check_loop_tolerant(char* access_kind,
    void* generic_c_ptr,
    int size,
    signed long expected_stack_depth,
    struct loop_ownership* loop_ownership);

/* Ghost arguments */
void alloc_ghost_array(int ghost_array_size);
void add_to_ghost_array(int i, void* ptr_to_ghost_arg);
void free_ghost_array(void);
void* load_from_ghost_array(int i);
void cn_ghost_arg_failure(void);

// Unused
#define c_concat_with_mapping_stat(STAT, CTYPE, VAR_NAME, GHOST_STATE, STACK_DEPTH)      \
  STAT;                                                                                  \
  c_add_to_ghost_state(&VAR_NAME, GHOST_STATE, sizeof(CTYPE), STACK_DEPTH);

#define c_declare_and_map_local(CTYPE, VAR_NAME)                                         \
  c_concat_with_mapping_stat(CTYPE VAR_NAME, CTYPE, VAR_NAME)

#define c_declare_init_and_map_local(CTYPE, VAR_NAME, EXPR)                              \
  c_concat_with_mapping_stat(CTYPE VAR_NAME = EXPR, CTYPE, VAR_NAME)
// /Unused

static inline void cn_load(void* ptr, size_t size) {
  //   cn_printf(CN_LOGGING_INFO, "  \x1b[31mLOAD\x1b[0m[%lu] - ptr: %p\n", size, ptr);
}
static inline void cn_store(void* ptr, size_t size) {
  //   cn_printf(CN_LOGGING_INFO, "  \x1b[31mSTORE\x1b[0m[%lu] - ptr: %p\n", size, ptr);
}
static inline void cn_postfix(void* ptr, size_t size) {
  //   cn_printf(CN_LOGGING_INFO, "  \x1b[31mPOSTFIX\x1b[0m[%lu] - ptr: %p\n", size, ptr);
}

// use this macro to wrap an argument to another macro that contains commas
#define CN_IGNORE_COMMA(...) __VA_ARGS__

#define CN_LOAD(LV)                                                                      \
  ({                                                                                     \
    typeof(LV)* __tmp = &(LV);                                                           \
    update_cn_error_message_info_access_check(0);                                        \
    c_ownership_check("Load", __tmp, sizeof(typeof(LV)), get_cn_stack_depth());          \
    cn_load(__tmp, sizeof(typeof(LV)));                                                  \
    *__tmp;                                                                              \
  })

#define CN_STORE_OP(LV, op, X)                                                           \
  ({                                                                                     \
    typeof(LV)* __tmp;                                                                   \
    __tmp = &(LV);                                                                       \
    update_cn_error_message_info_access_check(0);                                        \
    c_ownership_check("Store", __tmp, sizeof(typeof(LV)), get_cn_stack_depth());         \
    cn_store(__tmp, sizeof(typeof(LV)));                                                 \
    *__tmp op## = (X);                                                                   \
  })

#define CN_STORE(LV, X) CN_STORE_OP(LV, , X)

#define CN_POSTFIX(LV, OP)                                                               \
  ({                                                                                     \
    typeof(LV)* __tmp;                                                                   \
    __tmp = &(LV);                                                                       \
    update_cn_error_message_info_access_check(0);                                        \
    c_ownership_check(                                                                   \
        "Postfix operation", __tmp, sizeof(typeof(LV)), get_cn_stack_depth());           \
    cn_postfix(__tmp, sizeof(typeof(LV)));                                               \
    (*__tmp) OP;                                                                         \
  })

#ifdef __cplusplus
}
#endif

#ifdef __CN_INSTRUMENT
  #undef size_t
  #undef uint8_t
  #undef uint16_t
  #undef uint32_t
  #undef uint64_t
  #undef uintptr_t
  #undef int8_t
  #undef int16_t
  #undef int32_t
  #undef int64_t
  #undef intptr_t
  #undef alignof
#endif

#endif  // CN_UTILS
