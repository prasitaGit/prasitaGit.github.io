// System dependent definitions of the basic Cerberus types.
//
// These follow the host compiler's own definitions (via the predefined
// __*_TYPE__ macros that both GCC and Clang provide) so that declarations
// emitted by Cerberus, e.g. `__cerbty_uint64_t __builtin_bswap64(...)` or
// `typedef __cerbty_wchar_t wchar_t;`, never conflict with compiler builtins
// or system headers. (On LP64 Linux uint64_t is `unsigned long`, on macOS
// it is `unsigned long long`; wchar_t is `unsigned int` on aarch64 Linux.)
#ifndef CERB_TYPES
#define CERB_TYPES

#if defined(__UINT8_TYPE__) && defined(__INT64_TYPE__) && defined(__WCHAR_TYPE__) && \
    defined(__SIZE_TYPE__) && defined(__PTRDIFF_TYPE__) && defined(__INTMAX_TYPE__) && \
    defined(__UINTPTR_TYPE__)

typedef __UINT8_TYPE__ __cerbty_uint8_t;
typedef __UINT16_TYPE__ __cerbty_uint16_t;
typedef __UINT32_TYPE__ __cerbty_uint32_t;
typedef __UINT64_TYPE__ __cerbty_uint64_t;

typedef __INT8_TYPE__ __cerbty_int8_t;
typedef __INT16_TYPE__ __cerbty_int16_t;
typedef __INT32_TYPE__ __cerbty_int32_t;
typedef __INT64_TYPE__ __cerbty_int64_t;

typedef __INTMAX_TYPE__ __cerbty_intmax_t;
typedef __UINTMAX_TYPE__ __cerbty_uintmax_t;

typedef __UINTPTR_TYPE__ __cerbty_uintptr_t;
typedef __INTPTR_TYPE__ __cerbty_intptr_t;
typedef __PTRDIFF_TYPE__ __cerbty_ptrdiff_t;
typedef __SIZE_TYPE__ __cerbty_size_t;
typedef __WCHAR_TYPE__ __cerbty_wchar_t;

#else

typedef unsigned char __cerbty_uint8_t;
typedef unsigned short __cerbty_uint16_t;
typedef unsigned int __cerbty_uint32_t;
typedef unsigned long long __cerbty_uint64_t;

typedef signed char __cerbty_int8_t;
typedef signed short __cerbty_int16_t;
typedef signed int __cerbty_int32_t;
typedef signed long long __cerbty_int64_t;

typedef long __cerbty_intmax_t;
typedef unsigned long __cerbty_uintmax_t;

typedef unsigned long __cerbty_uintptr_t;
typedef signed long __cerbty_intptr_t;
typedef signed long __cerbty_ptrdiff_t;
typedef unsigned long __cerbty_size_t;
typedef signed int __cerbty_wchar_t;

#endif

#define __cerbvar_MAX_ALIGNMENT 16
#define __cerbvar_NULL          0

#endif
