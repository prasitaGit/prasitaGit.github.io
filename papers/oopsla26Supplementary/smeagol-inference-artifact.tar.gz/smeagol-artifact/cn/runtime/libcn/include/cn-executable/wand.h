#ifndef CN_WAND
#define CN_WAND

////////////////////////////////////////////////////////////////////////
// Wand engine support (testing-only, Bennet/Fulminate).
//
// A wand statement lays out two independent, purely symbolic heaps - one
// for its antecedent, one for its consequent - neither of which touches
// real memory or performs any real allocation/deallocation. Every node in
// either heap is identified by a "wand address": a real address reused
// from an actual take (e.g. `curr`). See cn_to_ail.ml's wand engine
// comments for the full design; this header provides the address/heap
// representation layer 2 builds on, plus the real-footprint checks
// (overlap, disjointness, coverage) and layer 4's structural transform
// that run against it.
////////////////////////////////////////////////////////////////////////

#include <stddef.h>

#include "rts_deps.h"

/* For enum spec_mode, used by cn_wand_heap_check_disjoint_from_inv's own
   signature below - utils.h does not include this header, so no
   circularity. */
#include <cn-executable/utils.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct cn_wand_addr {
  void* real;
} cn_wand_addr;

/* Wrap a real, already-known address (e.g. `curr`, `h`, or a field read
   off a real struct) as a wand address. Does NOT special-case NULL -
   see cn_wand_addr_is_null below for why NULL is never treated as a
   valid, matchable anchor regardless of which constructor produced it. */
cn_wand_addr cn_wand_addr_real(void* p);

/* Is this address NULL? NULL is a shared sentinel every terminated
   structure reaches, not a unique identity the way a real malloc'd
   address is - so it must never be treated as a valid anchor for a
   layout or a match point (this is what makes `Dllrep(curr, NULL)`-style
   forced arguments, and postulating a node "at" a null pointer, get
   rejected rather than silently accepted - see cn_wand_addr_eq below). */
_Bool cn_wand_addr_is_null(cn_wand_addr a);

/* Are two addresses the identical real anchor? Two real, non-NULL
   addresses are equal iff the underlying pointers are equal; NULL is
   never equal to anything (including another NULL-wrapping address). */
_Bool cn_wand_addr_eq(cn_wand_addr a, cn_wand_addr b);

////////////////////////////////////////////////////////////////////////
// Layer 2: generic per-side heap container.
//
// A wand's antecedent and consequent are each laid out as an ordered
// list of nodes. Every node is one `take`'s worth of postulated/
// constructed structure: its wand address (real or dummy, see above),
// a tag identifying which predicate/struct produced it (used by layer
// 4's cn_wand_heap_transform_range below to pick out which nodes in a
// range get rewritten, and threaded into this file's own failure
// messages for diagnostics), and an opaque pointer to the
// already-generated, per-call-site C struct holding that node's actual
// field values (there is no generic runtime value representation - see
// cn_to_ail.ml's wand engine comments - so this container only threads
// the pointer through; layer 2's per-predicate/struct-specific
// value-struct generation reads and writes `value` via generated code,
// not via anything in this header).
//
// One `cn_wand_heap` exists per side (antecedent/consequent) per wand
// occurrence, built fresh (via cn_wand_heap_init) every time that wand
// checkpoint runs, and walked/discarded once the checks that consume it
// (overlap, disjointness, coverage, forwarding) have run, before the
// next checkpoint - nothing here persists across checkpoints.
////////////////////////////////////////////////////////////////////////

typedef struct cn_wand_node {
  cn_wand_addr addr;
  /* Byte size of the real memory this node's leaf take covers - added
     alongside addr specifically so cn_wand_heap_add can detect two
     leaf takes (anywhere in the SAME heap, from different PName takes
     in the same wand occurrence - see the overlap check below) that
     claim overlapping real memory, e.g. `take Lh = Listrep(h); take
     Lc = Listrep(curr);` where `curr` is itself one of `h`'s own list
     cells. Real heap allocations are NOT contiguous or ordered in any
     way relative to each other, so this is always just one node's own
     fixed-size span, never merged/coalesced with any other node's. */
  size_t size;
  /* True for a genuine leaf (Owned/RW) memory cell - size is then that
     cell's real, meaningful byte extent. False for the single OPAQUE
     per-take summary node a PName take also registers here (see
     cn_to_ail.ml's generate_wand_heap_add_stmts) - that node's `size`
     is just a non-zero placeholder (1), not a real extent, since it
     stands for "the whole constructed/peeked value", not one memory
     cell; its own address is always identical to (or the same as the
     start of) whichever leaf node its own take's real recursive walk
     visits first, so comparing it against THAT leaf node would always
     "overlap" even for a single, perfectly ordinary take with no
     aliasing at all. cn_wand_heap_add's overlap check therefore only
     ever compares two nodes when BOTH are is_leaf - an opaque summary
     node is still appended (unchanged from before) but never
     participates in the overlap scan either as the new node or as an
     existing one, in either direction. */
  _Bool is_leaf;
  /* Not const - generated code always passes a plain char* (a string
     literal's own C type), matching the existing convention for other
     generated-string-literal-consuming runtime parameters (see e.g.
     cn_source_loc/file_name in utils.h's cn_error_message_info). */
  char* pred_name;
  void* value;
  struct cn_wand_node* next;
} cn_wand_node;

typedef struct cn_wand_heap {
  cn_wand_node* head;
  cn_wand_node* tail;
} cn_wand_heap;

/* Must be called before the first cn_wand_heap_add for a fresh heap
   (i.e. once per side, per wand occurrence). */
void cn_wand_heap_init(cn_wand_heap* heap);

/* Append a node to the end of `heap`, preserving layout order (the order
   nodes were postulated/constructed in - this is what lets
   cn_wand_heap_mark/cn_wand_heap_transform_range below identify
   "everything appended after this point" purely positionally, with no
   per-node id needed). Allocates from the bump allocator, so - like the
   rest of the wand machinery - never needs an explicit free. `heap` may be NULL - every
   generated predicate function calls this at each of its own leaf
   (Owned/RW) takes unconditionally, passing whatever cn_wand_heap* it
   itself received, which is NULL for an ordinary, non-wand call; NULL
   makes this a no-op (returning NULL) rather than a null deref.

   Before appending, this ALSO walks every node already in `heap` (if
   any) and checks whether [addr, addr+size) overlaps that node's own
   [addr, addr+size) - a plain pairwise scan against each individually-
   recorded node, never a merged/coalesced range, since real allocations
   from different leaf takes can land anywhere relative to each other.
   This is how two DIFFERENT PName takes claiming overlapping (or
   identical) real memory within the SAME wand occurrence's antecedent
   get caught - e.g. two takes that alias, or one take whose own real
   footprint is a strict superset of another's (`Listrep(h)` followed
   by `Listrep(curr)` where `curr` is already one of `h`'s own nodes).
   Unlike an ordinary take (which would catch this for free via the real
   ghost-state retag - see cn_get_ownership/cn_loop_get_ownership), a
   postulate peek never retags anything, so nothing else catches this
   for the antecedent side; hence this check lives here instead. A real
   overlap hard-fails via cn_failure (this is a fixed, already-true-or-
   false fact about current real memory, never a "not yet true, might
   become true later" postulate fact - same principle as the is_layout_fact
   carve-out in cn_assert), rather than being folded into the postulate's
   own soft not-applicable/match accumulator.

   Only ever compares two nodes when BOTH are is_leaf (see that field's
   own comment on cn_wand_node) - a PName take's own opaque summary node
   is skipped on both sides of the comparison, since its address always
   coincides with the first real leaf cell its own recursive walk
   visits, which would otherwise register as a false self-overlap for
   every ordinary, non-aliasing take. */
cn_wand_node* cn_wand_heap_add(cn_wand_heap* heap,
    cn_wand_addr addr,
    size_t size,
    _Bool is_leaf,
    char* pred_name,
    void* value);

/* Checks that the wand's own real footprint - whatever `cons_heap`'s real
   construct-side walk touches that ISN'T already covered by `ante_heap`'s
   own postulated subtree - is disjoint from `inv_heap`, the real footprint
   of every ordinary (non-wand) resource taken elsewhere in the same
   checkpoint (a loop invariant's own ghost takes sitting next to the
   wand, e.g. a Template-named resource the wand never mentions on either
   side). See this function's own comment in wand.c for the full
   rationale and a worked example (bstDelete.c's `Npar`); `spec_mode` is
   just forwarded to cn_failure on a real collision, matching whatever
   context this check is itself running under (LOOP for a loop invariant).
   Any of the three heaps may be NULL (no-ops, matching cn_wand_heap_add's
   own NULL-heap convention) - this lets a call site pass `inv_heap_sym_opt
   = None` when there happen to be no ordinary ghost takes in this
   checkpoint at all, rather than needing its own separate guard. */
void cn_wand_heap_check_disjoint_from_inv(
    cn_wand_heap* cons_heap, cn_wand_heap* ante_heap, cn_wand_heap* inv_heap,
    enum spec_mode spec_mode);

/* Same disjointness check as cn_wand_heap_check_disjoint_from_inv above,
   PLUS: every surviving leaf (every cons_heap leaf not covered by
   ante_heap, and not colliding with inv_heap) is also copied into
   `wands_footprint_heap` - a heap the caller declares once per
   checkpoint and shares across every wand occurrence in it (NOT fresh
   per wand, unlike ante_heap/cons_heap). This is what lets a later,
   separate call to cn_wand_heap_check_coverage see the combined
   real footprint of EVERY wand in the checkpoint, not just one. Reuses
   cn_wand_heap_add itself to do the copy, which means two DIFFERENT
   wands in the same checkpoint whose surviving footprints overlap each
   other also get caught here for free (via cn_wand_heap_add's own
   antecedent-vs-antecedent-shaped overlap check) - the error message in
   that specific corner case is phrased for the ordinary case and reads
   a little oddly, but the failure itself is still correct. `pred_name`
   and `value` are copied through unchanged so the appended node is
   indistinguishable from one cn_wand_heap_add would have produced
   directly against wands_footprint_heap. Any of the four heaps may be
   NULL, matching cn_wand_heap_add's own convention - wands_footprint_heap
   = NULL skips the copy step entirely (equivalent to calling
   cn_wand_heap_check_disjoint_from_inv alone).

   inv_heap specifically may be NULL to mean "skip the disjointness
   check, but still copy" - not "nothing to do". This is what a wand
   embedded directly in a predicate body (cn_to_ail.ml's cn_to_ail_lat,
   as opposed to a loop invariant's cn_to_ail_lat_internal_loop) uses:
   such a wand has no sibling "ordinary ghost take in this same
   checkpoint" to collide-check against - there is no checkpoint, just
   a predicate call - so it calls this with inv_heap = NULL purely to
   forward its surviving footprint into wands_footprint_heap, which
   there is Wand_heap_passthrough's resolved expression (the
   predicate's own received cn_wand_heap_arg), so the footprint reaches
   whatever heap the predicate's OWN caller is using - e.g. a loop
   invariant's inv_heap, if that's who called this predicate. */
void cn_wand_heap_register_footprint(
    cn_wand_heap* cons_heap, cn_wand_heap* ante_heap, cn_wand_heap* inv_heap,
    cn_wand_heap* wands_footprint_heap, enum spec_mode spec_mode);

/* The coverage check: once every
   ordinary (non-wand) take in a checkpoint has registered into
   `inv_heap`, and every wand occurrence in it has registered its
   surviving footprint into `wands_footprint_heap` (see
   cn_wand_heap_register_footprint above), this checks that the union of
   those two heaps covers the real footprint the function's own
   `requires` clause started with (`global_heap`, captured once at
   function entry) - nothing from the original footprint left
   unaccounted for (a "weak invariant" gap - some real memory the
   checkpoint's resources silently stopped describing). Call this once
   per checkpoint, after every ordinary take and every wand in it have
   already registered (i.e. at the very end of the checkpoint's own
   statement list) - calling it earlier would see a
   partially-populated inv_heap/wands_footprint_heap and misreport a gap
   that the rest of the checkpoint was always going to fill in. Any of
   the three heaps may be NULL (global_heap = NULL skips the whole
   check - e.g. there's no well-defined "global_heap" for a checkpoint
   whose enclosing function compilation never set one up).

   One-directional (coverage only): global_heap ⊆ inv_heap ∪
   wands_footprint_heap. A global_heap leaf whose region Fulminate's
   ownership ghost state no longer tracks (cn_ownership_region_tracked -
   i.e. the function has since cn_free_sized it) is skipped, so a
   legitimately freed precondition cell is not reported as dropped.
   The reverse direction is deliberately NOT checked: an invariant take
   of a cell the function doesn't own already fails Fulminate's ordinary
   ownership check; cells the function malloc'd itself are held to the
   postcondition; and a wand's footprint comes from the consequent's real
   walk (the antecedent is the peek side), checked against inv_heap by
   cn_wand_heap_register_footprint. Checking "nothing extra" here would
   only add false positives (stack-slot ownership, malloc'd cells). */
void cn_wand_heap_check_coverage(
    cn_wand_heap* inv_heap, cn_wand_heap* wands_footprint_heap,
    cn_wand_heap* global_heap, enum spec_mode spec_mode);

/* Compare two pred_name tags for equality - a thin wrapper around
   strcmp so generated code (which this project doesn't want depending
   on <string.h> directly) never needs to call strcmp itself. Used by
   cn_wand_heap_transform_range below to filter which nodes in a marked
   range a layer-4 transform applies to, and by this file's own failure
   messages for diagnostics. */
_Bool cn_wand_pred_name_eq(char* a, char* b);

////////////////////////////////////////////////////////////////////////
// Layer 4: structural per-field transform over an already-laid-out range.
//
// Motivating case: `take T = Dllrep(H.next, p);` followed later by
// `take Tc = Dllrep(Hc.next, curr); Tc == AddOne(T);` in the SAME
// antecedent. Since Hc.next and H.next are the same real, unmutated
// address, Tc's own recursion would walk the exact same real chain T's
// take already walked - so cn_to_ail.ml does not lay Tc out as a second,
// separate range of nodes at all. Instead it re-uses the range of nodes
// T's take already appended (bracketed by a marker captured just before
// that take ran - see cn_wand_heap_mark below) and mutates each matching
// node's value in place, according to a per-field transform derived by
// lining up AddOne's recursive case against Dllrep's own return clause
// (see cn_to_ail.ml's wand engine comments for the full field-matching
// algorithm). This only ever runs against the ANTECEDENT heap - it is
// what makes that heap's stored values reflect what the antecedent
// actually claims (e.g. "head + 1"), rather than the real, not-yet-
// mutated memory a plain peek would otherwise store.
////////////////////////////////////////////////////////////////////////

/* Snapshot the current end of `heap`, to later bound a range of nodes
   with cn_wand_heap_transform_range. Call this immediately before the
   take whose nodes you want to bracket runs (so the snapshot reflects
   "nothing from that take yet"), then again is not needed after - the
   range is always "whatever got appended since this snapshot, up to
   whenever the transform is applied". May be NULL (an empty heap so
   far), which cn_wand_heap_transform_range treats as "start from
   heap->head". */
cn_wand_node* cn_wand_heap_mark(cn_wand_heap* heap);

/* Mutates a single node's value in place - generated per (predicate,
   function) pair by cn_to_ail.ml (see its wand engine comments), not
   provided generically here, since what to actually do to the value is
   entirely specific to that pair's own field layout. */
typedef void (*cn_wand_value_transform_fn)(void* value);

/* Walk every node appended to `heap` after `start_exclusive` (or from
   `heap->head` if `start_exclusive` is NULL) up to the current tail,
   and for each node whose pred_name matches `pred_name_filter`, call
   `transform` on its value in place. Nodes with a different pred_name
   are left untouched (a defensive default - a well-formed single-
   recursive-field predicate's own range should be uniformly one tag,
   but this avoids silently mistransforming anything unexpected if
   that's ever not the case). */
void cn_wand_heap_transform_range(cn_wand_heap* heap,
    cn_wand_node* start_exclusive,
    char* pred_name_filter,
    cn_wand_value_transform_fn transform);


////////////////////////////////////////////////////////////////////////
// Borrow stop-pointer SET (testing-only). A wand consequent's predicate
// call receives, in place of a single stop pointer, a list of
// (stop, substitute, consumed-flag) entries; the predicate stops at
// whichever registered stop address its real walk reaches.
////////////////////////////////////////////////////////////////////////
void* cn_borrow_list_cons(void* stop, void* sub, cn_bool* consumed, void* tail);
/* Is `p` (a cn_pointer*) the stop address of some entry? A NULL stop only
   matches when `is_outer` is nonzero. */
int cn_borrow_list_hit(void* list, void* p, int is_outer);
/* Marks the matching entry's consumed flag and returns its substitute. */
void* cn_borrow_list_take(void* list, void* p, int is_outer);

/* The first leaf (Owned/RW) node appended to `heap` after `mark` (or from the
   head if `mark` is NULL), as a fresh cn_pointer* - the entry address of the
   take whose walk just ran. Returns `fallback` (a cn_pointer*) if `heap` is
   NULL or no leaf was appended. */
void* cn_wand_first_leaf_stop(cn_wand_heap* heap, cn_wand_node* mark, void* fallback);

/* Did the heap take a real leaf cell at the address a stop pointer (a
   cn_pointer*) holds? Used by the "borrow consumed" check: a borrow that the
   consequent never reached is allowed (extra antecedent memory), only a
   borrow whose stop address the consequent walked over must be consumed. */
cn_bool* cn_wand_heap_touches(cn_wand_heap* heap, void* stop);

#ifdef __cplusplus
}
#endif

#endif  // CN_WAND
