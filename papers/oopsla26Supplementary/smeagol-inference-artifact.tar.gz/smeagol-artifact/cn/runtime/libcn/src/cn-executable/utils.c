#include <assert.h>
#include <inttypes.h>
#include <limits.h>
#include <signal.h>  // for SIGABRT
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

#include <cn-executable/rmap.h>
#include <cn-executable/utils.h>

typedef rmap ownership_ghost_state;

ownership_ghost_state cn_ownership_global_ghost_state;

struct cn_error_message_info* global_error_msg_info;

/* Getter for other translation units (e.g. wand.c's overlap-check failure
   path) that need to pass the current error-info pointer to
   print_error_msg_info without their own copy of this global. */
struct cn_error_message_info* get_global_error_msg_info(void) {
  return global_error_msg_info;
}

struct cn_error_message_info* no_error_msg_info = 0;

signed long cn_stack_depth;

signed long nr_owned_predicates;

_Bool exec_c_locs_mode;
_Bool correct_missing_ownership;
_Bool ownership_stack_mode;

static signed long UNMAPPED_VAL = -1;
static signed long WILDCARD_DEPTH = INT_MIN + 1;

static allocator bump_alloc = (allocator){
    .malloc = &cn_bump_malloc, .calloc = &cn_bump_calloc, .free = &cn_bump_free};

static _Bool fulminate_initialized = false;

/* Wand CONSTRUCT-side tracking (testing-only): companion to the
   antecedent-only cn_wand_peek_push/pop stack further below. Nestable
   counter, incremented/decremented around the real, ownership-consuming
   "construct" half of a wand (see cn_to_ail_lrt_consume_loop /
   cn_to_ail_lrt_consume_pred and the LRT/LAT.Package arms in
   cn_to_ail.ml), as opposed to its read-only "postulate" half.

   Motivating case (bstDelete.c): a loop invariant contains
   `take T2 = ParRep(parent, temp, curr);
    wand(take T2c = Treerep(curr);, take Tr = Treerep(root); Tr == T;);`.
   ParRep's own internal `take H = RW<struct tree>(par)` plus `take L/R =
   Treerep(H.left/right)` already cover `curr`'s whole subtree once
   `par == curr` (a dynamic coincidence, not something declared in
   ParRep's type signature). The wand's construct-side `Treerep(root)`
   walk then collides with that coverage the moment it recurses back down
   into `curr`, because nothing tells it that memory is already spoken
   for.

   ADDRESS-MEMBERSHIP, NOT JUST DEPTH: an earlier version of this fix (see
   git history) had cn_loop_get_ownership (below, via
   c_ownership_check_loop_tolerant) accept ANY address retagged to
   (expected_stack_depth - 1) while this counter was > 0, no matter which
   predicate produced that retag - i.e. "something in this checkpoint pass
   claimed something at the right depth", not "this SPECIFIC address is
   what an earlier take in this pass actually claimed". That was sound
   (every depth-1 address really was claimed by some earlier take in this
   pass, since only cn_loop_get_ownership ever retags to
   expected_stack_depth - 1), but imprecise: depth alone can't distinguish
   "this is what the loop's own take just legitimately claimed" from "this
   happens to be some other, unrelated resource that coincidentally also
   sits at depth - 1" - depth was simply the only signal available at the
   check site.

   Now that address-range membership against the specific enclosing loop's
   own `struct loop_ownership` is available (cn_loop_ownership_contains,
   near cn_add_to_loop_ownership_state below - that struct already records,
   for this exact loop invariant-check pass, every address range any take
   within it, e.g. ParRep's internal RW(par), has actually claimed),
   c_ownership_check_loop_tolerant checks THAT instead of the bare depth:
   is the SPECIFIC colliding address range one this pass's own earlier
   takes actually produced, rather than merely "is anything, produced by
   anything, sitting at the right depth". This counter's role changes
   accordingly: it is no longer part of the tolerance rule itself, only the
   GATE deciding whether the tolerant fallback is consulted at all - see
   the comment above cn_wand_construct_push in utils.h for why the gate
   must stay even so: without it, a genuine double-take bug in an
   ordinary, non-wand loop invariant would also find its own address
   already in loop_ownership (from its own earlier, legitimate take) and
   would be wrongly forgiven. WAND_PEEK's read-only depth-or-depth-1
   tolerance in c_ownership_check_bool below is unaffected by any of this -
   it never mutates ghost state, so it was never the imprecise part.

   IMPORTANT: this counter is reset to 0 in fulminate_init() below, which
   runs once per test case/iteration (see CN_TEST_INIT() in test.h). This
   is essential: a genuine ownership-check failure that longjmp's out of
   generated C code while this counter is > 0 would otherwise leave it
   stuck non-zero for the rest of the process (fulminate_destroy() does
   not touch it either), silently loosening c_ownership_check_loop_tolerant
   for every subsequent, unrelated loop-invariant check in later test
   cases/iterations. Resetting it unconditionally on every init closes
   that gap. */
static int cn_wand_construct_depth = 0;

/* NB: deliberately does not call cn_wand_debug_enabled() - that's a
   static helper defined later in this file (near cn_wand_peek_push) and
   this needs to sit earlier, right next to cn_get_ownership/
   cn_loop_get_ownership which it exists to affect. */
void cn_wand_construct_push(void) {
  cn_wand_construct_depth++;
}

void cn_wand_construct_pop(void) {
  if (cn_wand_construct_depth <= 0) {
    cn_printf(CN_LOGGING_ERROR, "******** FULMINATE ERROR *********\n");
    cn_printf(CN_LOGGING_ERROR, "cn_wand_construct_pop called with depth <= 0\n");
    exit(1);
  }
  cn_wand_construct_depth--;
}

void fulminate_destroy(void) {
  if (!fulminate_initialized) {
    return;  // Already destroyed or never initialized
  }

  cn_bump_free_all();
  free_ownership_ghost_state();
  free_error_msg_info();

  fulminate_initialized = false;
}

void fulminate_init(void) {
  assert(!fulminate_initialized && "Fulminate already initialized - destroy first");

  initialise_ownership_ghost_state();
  initialise_ghost_stack_depth();
  initialise_exec_c_locs_mode(0);
  initialise_correct_missing_ownership(0);
  initialise_ownership_stack_mode(0);
  cn_wand_construct_depth = 0;

  fulminate_initialized = true;
}

static enum cn_logging_level logging_level = CN_LOGGING_INFO;

enum cn_logging_level get_cn_logging_level(void) {
  return logging_level;
}

enum cn_logging_level set_cn_logging_level(enum cn_logging_level new_level) {
  enum cn_logging_level old_level = logging_level;
  logging_level = new_level;
  return old_level;
}

void cn_failure_default(enum cn_failure_mode failure_mode, enum spec_mode spec_mode) {
  int exit_code =
      spec_mode;  // Might need to differentiate between failure modes via this exit code in the future
  switch (failure_mode) {
    case CN_FAILURE_USER_ALLOC:
      cn_printf(CN_LOGGING_INFO, "User allocation failed\n");
      break;
    case CN_FAILURE_FULM_ALLOC:
      cn_printf(CN_LOGGING_INFO, "Out of memory!\n");
      fallthrough;
    case CN_FAILURE_ASSERT:
    case CN_FAILURE_CHECK_OWNERSHIP:
    case CN_FAILURE_OWNERSHIP_LEAK:
    case CN_FAILURE_GHOST_ARGS:
      exit(exit_code);
  }
}

static cn_failure_callback cn_failure_aux = &cn_failure_default;

void cn_failure(enum cn_failure_mode failure_mode, enum spec_mode spec_mode) {
  cn_failure_aux(failure_mode, spec_mode);
}

void set_cn_failure_cb(cn_failure_callback callback) {
  cn_failure_aux = callback;
}

void reset_cn_failure_cb(void) {
  cn_failure_aux = &cn_failure_default;
}

static enum cn_trace_granularity trace_granularity = CN_TRACE_NONE;

enum cn_trace_granularity get_cn_trace_granularity(void) {
  return trace_granularity;
}

enum cn_trace_granularity set_cn_trace_granularity(
    enum cn_trace_granularity new_granularity) {
  enum cn_trace_granularity old_granularity = trace_granularity;
  trace_granularity = new_granularity;
  return old_granularity;
}

void print_error_msg_info_single(struct cn_error_message_info* info) {
  if (exec_c_locs_mode) {
    cn_printf(CN_LOGGING_ERROR,
        "function %s, file %s, line %d\n",
        info->function_name,
        info->file_name,
        info->line_number);
  } else {
    if (info->cn_source_loc) {
      cn_printf(
          CN_LOGGING_ERROR, "original source location: \n%s\n\n", info->cn_source_loc);
    } else {
      cn_printf(CN_LOGGING_ERROR,
          "no source location found (try running with --exec-c-locs-mode enabled)")
    }
  }
}

void print_error_msg_info(struct cn_error_message_info* info) {
  if (info) {
    enum cn_trace_granularity granularity = get_cn_trace_granularity();
    if (granularity != CN_TRACE_NONE && info->parent != NULL) {
      struct cn_error_message_info* curr = info;
      while (curr->parent != NULL) {
        curr = curr->parent;
      }

      cn_printf(CN_LOGGING_ERROR,
          "********************* Originated from **********************\n");
      print_error_msg_info_single(curr);
      curr = curr->child;

      while (granularity > CN_TRACE_ENDS && curr->child != NULL) {
        cn_printf(CN_LOGGING_ERROR,
            "************************************************************\n");
        print_error_msg_info_single(curr);
        curr = curr->child;
      }
    }

    cn_printf(CN_LOGGING_ERROR,
        "************************ Failed at *************************\n");
    print_error_msg_info_single(info);
  } else {
    cn_printf(CN_LOGGING_ERROR, "Internal error: no error_msg_info available.");
    exit(SIGABRT);
  }
}

// void print_owned_calls_stack(ownership_ghost_info* entry_maybe) {
//   if (entry_maybe && entry_maybe->source_loc_stack) {
//     cn_printf(CN_LOGGING_ERROR, "Owned locations stack:\n");
//     char* popped_elem =
//         cn_source_location_stack_pop(entry_maybe->source_loc_stack, &fulm_default_alloc);
//     while (popped_elem) {
//       cn_printf(CN_LOGGING_ERROR, "%s\n", popped_elem);
//       cn_printf(CN_LOGGING_ERROR, "==========================\n");
//       popped_elem = cn_source_location_stack_pop(
//           entry_maybe->source_loc_stack, &fulm_default_alloc);
//     }
//   }
// }

int* create_ownership_ghost_state_entry(int depth) {
  int* ghost_state_entry = fulm_malloc(sizeof(int), &fulm_default_alloc);
  *ghost_state_entry = depth;
  return ghost_state_entry;
}

cn_bool* convert_to_cn_bool(_Bool b) {
  cn_bool* res = cn_bump_malloc(sizeof(cn_bool));
  if (!res)
    exit(1);
  res->val = b;
  return res;
}

_Bool convert_from_cn_bool(cn_bool* b) {
  return b->val;
}

void cn_assert(cn_bool* cn_b,
    enum spec_mode spec_mode,
    _Bool is_layout_fact,
    _Bool is_wand_consequent,
    const char* expr_str) {
  // cn_printf(CN_LOGGING_INFO, "[CN: assertion] function %s, file %s, line %d\n", error_msg_info.function_name, error_msg_info.file_name, error_msg_info.line_number);
  if (spec_mode == WAND_PEEK && !is_layout_fact) {
    /* Postulate-as-assumption semantics (see dest_with_unit_check's
       Assert case and generate_cn_assert's ~is_layout_fact in
       cn_to_ail.ml): an ORDINARY-VALUE predicate-internal assert
       reached while evaluating a wand's antecedent must never itself
       abort the test, exactly like the wand's own top-level ==
       equations get hardcoded to true - it may not be true YET, but
       could become true by the time the wand is redeemed. The OCaml-
       level static hardcode only fires when spec_mode_opt is KNOWN to
       be Wand_peek at compile time, which is never the case for a
       shared predicate's own body (e.g. Dllrep's own asserts) - that
       body is compiled ONCE, with spec_mode_opt = None, since the very
       same generated function also serves ordinary, non-wand calls.
       So a predicate's own internal assert only ever learns it's being
       evaluated under a wand's postulate via THIS runtime spec_mode
       parameter (passed by cn_to_ail_lrt_postulate's fast path, which
       "ALSO run[s] the ordinary WAND_PEEK walk...purely for its side
       effect on the postulate accumulator") - this check is what
       actually protects it.

       is_layout_fact carves out the one case where that deferral is
       simply wrong: an assert mentioning a pointer/address-valued
       subterm (e.g. `addr_eq(prev, H.prev)`) is a fact about the
       CURRENT, already-fixed relationship between real addresses in
       memory, not something a wand's own transform function is ever in
       the business of changing - there is no "not true yet, will be
       true later" story for it, so it stays a real, unconditional
       check even under WAND_PEEK. Ownership-existence checking
       (c_ownership_check_bool/cn_wand_peek_ownership) is a completely
       separate mechanism, unaffected either way. */
    return;
  }
  if (!(cn_b->val)) {
    /* Category-specific line, ahead of the ordinary source-location
       dump, so a spec writer doesn't have to guess which side of the
       wand broke just from a bare failing-test report:
       - "antecedent, layout": this is a real (non-bypassed) check that
         only survives to here under WAND_PEEK because is_layout_fact
         is true - i.e. the antecedent's claimed memory layout (an
         address relationship, e.g. a `prev`/`next` pointer) doesn't
         match the real structure at this address.
       - "consequent, value": is_wand_consequent is true - this assert
         was compiled from the wand's own consequent clause list (see
         in_wand_consequent in cn_to_ail.ml), i.e. the value the wand
         claims to construct on redemption doesn't match what's
         required here.
       expr_str (a plain-text rendering of the failing CN constraint,
       via LogicalConstraints.pp/Pp.plain at the generate_cn_assert
       call site) is printed either way, so the spec writer also sees
       WHAT specifically failed, not just which category. An ordinary,
       non-wand assert hits neither case and falls straight through to
       today's unchanged report. */
    if (is_wand_consequent) {
      cn_printf(CN_LOGGING_ERROR,
          "[CN WAND] the wand's constructed value doesn't match what's required here\n");
      cn_printf(CN_LOGGING_ERROR, "  failing expression: %s\n", expr_str);
    } else if (spec_mode == WAND_PEEK) {
      cn_printf(CN_LOGGING_ERROR,
          "[CN WAND] antecedent's claimed memory layout is inconsistent with the real structure at this address\n");
      cn_printf(CN_LOGGING_ERROR, "  failing expression: %s\n", expr_str);
    }
    print_error_msg_info(global_error_msg_info);
    cn_failure(CN_FAILURE_ASSERT, spec_mode);
  }
}

cn_bool* cn_bool_and(cn_bool* b1, cn_bool* b2) {
  cn_bool* res = cn_bump_malloc(sizeof(cn_bool));
  res->val = b1->val && b2->val;
  return res;
}

void cn_bool_inplace_and(cn_bool* inplace_b1, cn_bool* b2) {
  inplace_b1->val = inplace_b1->val && b2->val;
}

cn_bool* cn_bool_or(cn_bool* b1, cn_bool* b2) {
  cn_bool* res = cn_bump_malloc(sizeof(cn_bool));
  res->val = b1->val || b2->val;
  return res;
}

cn_bool* cn_bool_implies(cn_bool* b1, cn_bool* b2) {
  cn_bool* res = cn_bump_malloc(sizeof(cn_bool));
  res->val = !b1->val || b2->val;
  return res;
}

cn_bool* cn_bool_not(cn_bool* b) {
  cn_bool* res = cn_bump_malloc(sizeof(cn_bool));
  res->val = !(b->val);
  return res;
}

cn_bool* cn_bool_equality(cn_bool* b1, cn_bool* b2) {
  return convert_to_cn_bool(b1->val == b2->val);
}

void* cn_ite(cn_bool* b, void* e1, void* e2) {
  return b->val ? e1 : e2;
}

cn_map* map_create(void) {
  return ht_create(&bump_alloc);
}

void initialise_ownership_ghost_state(void) {
  nr_owned_predicates = 0;
  cn_ownership_global_ghost_state =
      rmap_create(4, fulm_default_alloc.malloc, fulm_default_alloc.free);
}

void free_ownership_ghost_state(void) {
  nr_owned_predicates = 0;
  rmap_free(cn_ownership_global_ghost_state);
}

void initialise_ghost_stack_depth(void) {
  cn_stack_depth = 0;
}

void initialise_exec_c_locs_mode(_Bool flag) {
  exec_c_locs_mode = flag;
}

void initialise_correct_missing_ownership(_Bool flag) {
  correct_missing_ownership = flag;
}

void initialise_ownership_stack_mode(_Bool flag) {
  ownership_stack_mode = flag;
}

signed long get_cn_stack_depth(void) {
  return cn_stack_depth;
}

void ghost_stack_depth_incr(void) {
  cn_stack_depth++;
}

// TODO: one of these should maybe go away
#define FMT_PTR "\x1b[33m%#" PRIxPTR "\x1b[0m"
// #define KMAG  "\x1B[35m"
#define FMT_PTR_2 "\x1B[35m%#" PRIxPTR "\x1B[0m"

void ghost_stack_depth_decr(void) {
  cn_stack_depth--;
  // update_error_message_info(0);
  // print_error_msg_info();

  // cn_printf(CN_LOGGING_INFO, "\n");
}

void cn_postcondition_leak_check(void) {
  rmap_range_res_t res = rmap_find_range(0UL, -1UL, cn_ownership_global_ghost_state);
  if (res.defined && res.max > cn_stack_depth) {
    print_error_msg_info(global_error_msg_info);
    // XXX TODO: scan for the failing address
    // cn_printf(CN_LOGGING_ERROR,
    //     "Postcondition leak check failed, ownership leaked for pointer " FMT_PTR "\n",
    //     (uintptr_t)*key);
    cn_failure(CN_FAILURE_OWNERSHIP_LEAK, POST);
  }
}

void cn_loop_leak_check(void) {
  rmap_range_res_t res = rmap_find_range(0UL, -1UL, cn_ownership_global_ghost_state);
  if (res.defined && res.max == cn_stack_depth) {
    print_error_msg_info(global_error_msg_info);
    // XXX TODO: scan for the failing address
    // cn_printf(CN_LOGGING_ERROR,
    //     "Loop invariant leak check failed, ownership leaked for pointer " FMT_PTR "\n",
    //     (uintptr_t)*key);
    cn_failure(CN_FAILURE_OWNERSHIP_LEAK, LOOP);
  }
}

typedef struct loop_ownership_nd {
  uintptr_t addr;
  size_t size;
  struct loop_ownership_nd* next;
} loop_ownership_nd;

struct loop_ownership {
  loop_ownership_nd* head;
};

// No destructors: expects to be dropped by the bump allocator _in a timely
// manner_.
struct loop_ownership* initialise_loop_ownership_state(void) {
  struct loop_ownership* loop_ownership =
      bump_alloc.malloc(sizeof(struct loop_ownership));
  assert(loop_ownership);
  *loop_ownership = (struct loop_ownership){.head = NULL};
  return loop_ownership;
}

// XXX: Compresses explicit ranges. Catches iteratively fed ranges.
// To improve: coalesce with any known range, rather than just the last.
void cn_add_to_loop_ownership_state(
    void* generic_c_ptr, size_t size, struct loop_ownership* loop_ownership) {
  uintptr_t addr = (uintptr_t)generic_c_ptr;
  loop_ownership_nd* hd = loop_ownership->head;
  if (hd && addr == (hd->addr + hd->size))
    hd->size += size;
  else {
    loop_ownership_nd* newhd = bump_alloc.malloc(sizeof(loop_ownership_nd));
    assert(newhd);
    *newhd = (loop_ownership_nd){.addr = addr, .size = size, .next = hd};
    loop_ownership->head = newhd;
  }
}

// Testing-only: is [generic_c_ptr, generic_c_ptr + size) fully covered by a
// SINGLE recorded range in loop_ownership? (Ranges are only ever added by
// cn_add_to_loop_ownership_state above, coalescing adjacent ones, so this
// does not need to stitch multiple non-adjacent ranges together to answer
// "is this whole request covered".) See c_ownership_check_loop_tolerant
// below, and the long comment above cn_wand_construct_depth, for why this
// is the precise replacement for the old bare-depth tolerance check: it
// answers "did THIS pass's own earlier takes actually claim this SPECIFIC
// address range", not just "is anything sitting at the right depth".
//
// NB: only ever consults the ONE loop_ownership pointer it's given, i.e.
// the innermost enclosing loop invariant-check pass reachable via however
// this call was threaded (see cn_to_ail_lrt_consume_loop / the
// loop_ownership_sym threading in cn_to_ail.ml). If a wand's construct is
// nested inside more than one enclosing loop and the collision was
// actually produced by an OUTER loop's own take rather than the
// innermost one, this will not find it - multi-level loop nesting is not
// handled here, since doing so would need threading a stack of
// loop_ownership pointers everywhere loop_ownership_sym currently threads
// a single one, a much larger change. In that unhandled case, this simply
// returns false and the ownership check proceeds to fail normally, same
// as if this function did not exist - i.e. failing safe, not silently
// accepting something it shouldn't.
_Bool cn_loop_ownership_contains(
    void* generic_c_ptr, size_t size, struct loop_ownership* loop_ownership) {
  if (size < 1)
    return true;
  if (!loop_ownership)
    return false;

  uintptr_t addr = (uintptr_t)generic_c_ptr;
  uintptr_t addr_end = addr + size;  // exclusive

  for (loop_ownership_nd* nd = loop_ownership->head; nd; nd = nd->next) {
    uintptr_t nd_end = nd->addr + nd->size;  // exclusive
    if (addr >= nd->addr && addr_end <= nd_end)
      return true;
  }
  return false;
}

void cn_loop_put_back_ownership(struct loop_ownership* loop_ownership) {
  for (loop_ownership_nd* nd = loop_ownership->head; nd; nd = nd->next) {
    ownership_ghost_state_set(nd->addr, nd->size, cn_stack_depth, no_error_msg_info);
  }
}

int ownership_ghost_state_get(int64_t address) {
  rmap_value_opt_t res = rmap_find(address, cn_ownership_global_ghost_state);
  return res.defined ? res.v : UNMAPPED_VAL;
}

void ownership_ghost_state_set(int64_t address,
    size_t size,
    int stack_depth_val,
    struct cn_error_message_info* error_msg_info) {
  if (size > 0)
    rmap_add(
        address, address + size - 1, stack_depth_val, cn_ownership_global_ghost_state);

  // rmap_range_res_t res = rmap_find_range(address, address + size - 1, cn_ownership_global_ghost_state);
  // if (!res.defined || res.min > WILDCARD_DEPTH)
  //   rmap_add(address, address + size - 1, stack_depth_val, cn_ownership_global_ghost_state);
  // else if (res.max > WILDCARD_DEPTH)
  //   for (int64_t addr = address; addr < address + size; addr++) {
  //     rmap_value_opt_t res2 = rmap_find(addr, cn_ownership_global_ghost_state);
  //     if (!(res2.defined && res2.v == WILDCARD_DEPTH))
  //       rmap_add(addr, addr, stack_depth_val, cn_ownership_global_ghost_state);
  // }
}

void ownership_ghost_state_remove(int64_t address, size_t size) {
  if (size > 0)
    rmap_remove(address, address + size - 1, cn_ownership_global_ghost_state);

  // rmap_range_res_t res = rmap_find_range(address, address + size - 1, cn_ownership_global_ghost_state);
  // if (!res.defined || res.min > WILDCARD_DEPTH)
  //   rmap_remove(address, address + size - 1, cn_ownership_global_ghost_state);
  // else if (res.max > WILDCARD_DEPTH)
  //   for (int64_t addr = address; addr < address + size; addr++) {
  //     rmap_value_opt_t res2 = rmap_find(addr, cn_ownership_global_ghost_state);
  //     if (!(res2.defined && res2.v == WILDCARD_DEPTH))
  //       rmap_remove(addr, addr, cn_ownership_global_ghost_state);
  //   }
}

rmap_range_res_t ownership_ghost_state_extrema(int64_t address, size_t size) {
  if (size > 0)
    return rmap_find_range(address, address + size - 1, cn_ownership_global_ghost_state);
  return (rmap_range_res_t){.defined = false};
}

/* Is any part of [ptr, ptr+size) still tracked in the ownership ghost state
   (at any depth)? cn_free_sized removes a freed region entirely, so
   "not tracked" means freed (or never owned). Used by the wand coverage
   check to skip precondition cells the function has since freed. */
_Bool cn_ownership_region_tracked(void* ptr, size_t size) {
  rmap_range_res_t res = ownership_ghost_state_extrema((uintptr_t)ptr, size);
  return res.defined;
}

_Bool is_wildcard(void* generic_c_ptr, int size) {
  int64_t address = (uintptr_t)generic_c_ptr;
  if (size > 0) {
    rmap_range_res_t res =
        rmap_find_range(address, address + size - 1, cn_ownership_global_ghost_state);
    return res.defined && res.max == WILDCARD_DEPTH;
  }
  return true;
}

/* Calls to this generated by Fulminate for stack-local variable ownership checking */
void c_add_to_ghost_state(void* ptr_to_local, size_t size, signed long stack_depth) {
  // cn_printf(CN_LOGGING_INFO, "[C access checking] add local:" FMT_PTR ", size: %lu\n", ptr_to_local, size);
  ownership_ghost_state_set(
      (uintptr_t)ptr_to_local, size, stack_depth, global_error_msg_info);
}

/* Only called internally for tracking ownership of heap addresses */
void c_add_to_ghost_state_internal(uintptr_t ptr_to_local,
    size_t size,
    signed long stack_depth,
    struct cn_error_message_info* error_msg_info) {
  // cn_printf(CN_LOGGING_INFO, "[C access checking] add local:" FMT_PTR ", size: %lu\n", ptr_to_local, size);
  ownership_ghost_state_set(ptr_to_local, size, stack_depth, error_msg_info);
}

void c_remove_from_ghost_state(void* ptr_to_local, size_t size) {
  // cn_printf(CN_LOGGING_INFO, "[C access checking] remove local:" FMT_PTR ", size: %lu\n", ptr_to_local, size);
  ownership_ghost_state_remove((uintptr_t)ptr_to_local, size);
}

void c_remove_from_ghost_state_internal(uintptr_t ptr_to_local, size_t size) {
  // cn_printf(CN_LOGGING_INFO, "[C access checking] remove local:" FMT_PTR ", size: %lu\n", ptr_to_local, size);
  ownership_ghost_state_remove(ptr_to_local, size);
}

void cn_get_ownership(void* generic_c_ptr, size_t size) {
  /* Used for precondition and loop invariant taking/getting of ownership */
  enum region_owned owned = c_ownership_check(
      "Precondition ownership check", generic_c_ptr, size, cn_stack_depth - 1);
  if (owned == NO_WILDCARD)
    c_add_to_ghost_state_internal(
        (uintptr_t)generic_c_ptr, size, cn_stack_depth, global_error_msg_info);
  else
    assert(owned == FULL_WILDCARD);  // INCOMPLETE
}

void cn_loop_get_ownership(
    void* generic_c_ptr, size_t size, struct loop_ownership* loop_ownership) {
  enum region_owned owned = c_ownership_check_loop_tolerant(
      "Loop ownership check", generic_c_ptr, size, cn_stack_depth, loop_ownership);
  if (owned == NO_WILDCARD) {
    c_add_to_ghost_state_internal(
        (uintptr_t)generic_c_ptr, size, cn_stack_depth - 1, global_error_msg_info);
    if (loop_ownership) {
      cn_add_to_loop_ownership_state(generic_c_ptr, size, loop_ownership);
    } else {
      // Should never be triggered if Fulminate implementation is correct
      cn_printf(CN_LOGGING_ERROR, "******** FULMINATE ERROR *********\n");
      cn_printf(CN_LOGGING_ERROR, "No loop ownership state found.\n");
      cn_printf(CN_LOGGING_ERROR,
          "Please open a pull request at https://github.com/rems-project/cn\n");
      exit(1);
    }
  } else
    assert(owned == FULL_WILDCARD);  // INCOMPLETE
}

void cn_put_ownership(void* generic_c_ptr, size_t size) {
  // cn_printf(CN_LOGGING_INFO, "[CN: returning ownership] " FMT_PTR_2 ", size: %lu\n", generic_c_ptr, size);
  //// print_error_msg_info();
  enum region_owned owned = c_ownership_check(
      "Postcondition ownership check", generic_c_ptr, size, cn_stack_depth);
  if (owned == NO_WILDCARD)
    c_add_to_ghost_state_internal(
        (uintptr_t)generic_c_ptr, size, cn_stack_depth - 1, global_error_msg_info);
  else
    assert(owned == FULL_WILDCARD);  // INCOMPLETE
}

void fulminate_assume_ownership(
    void* generic_c_ptr, unsigned long size, char* fun, _Bool wildcard) {
  signed long depth = wildcard ? WILDCARD_DEPTH : cn_stack_depth;
  ownership_ghost_state_set((uintptr_t)generic_c_ptr, size, depth, global_error_msg_info);
  /* // cn_printf(CN_LOGGING_INFO, "CN: Assuming ownership for %lu (function: %s)\n",  */
  /*        ((uintptr_t) generic_c_ptr) + i, fun); */
}

void cn_assume_ownership(void* generic_c_ptr, unsigned long size, char* fun) {
  // cn_printf(CN_LOGGING_INFO, "[CN: assuming ownership (%s)] " FMT_PTR_2 ", size: %lu\n", fun, (uintptr_t) generic_c_ptr, size);
  //// print_error_msg_info();
  fulminate_assume_ownership(generic_c_ptr, size, fun, false);
}

/* WAND POSTULATE TRACKING (testing-only): a wand's antecedent ("postulate")
   is checked read-only. Unlike an ordinary take/assert, a postulate
   mismatch must NOT abort the test: it just means the wand doesn't apply
   at this checkpoint, so the generated code skips its consequent
   ("construct") entirely and carries on. This small stack accumulates,
   per wand occurrence, whether every part of its antecedent matched; it
   supports nested wands (a wand appearing inside another wand's
   antecedent) via ordinary push/pop nesting. */
#define CN_WAND_PEEK_STACK_MAX 64
static _Bool cn_wand_peek_stack[CN_WAND_PEEK_STACK_MAX];
static int cn_wand_peek_stack_top = -1;

/* Off by default - opt in with `CN_WAND_DEBUG=1 cn test ...` (or however
   the generated binary is invoked). Checked once and cached, since this is
   read from a hot path (every wand checkpoint, e.g. once per loop
   iteration for a wand inside a loop invariant). */
static int cn_wand_debug_cached = -1; /* -1 = not yet checked */

static _Bool cn_wand_debug_enabled(void) {
  if (cn_wand_debug_cached < 0) {
    const char* env = getenv("CN_WAND_DEBUG");
    cn_wand_debug_cached = (env != NULL && env[0] != '\0' && env[0] != '0');
  }
  return (_Bool)cn_wand_debug_cached;
}

void cn_wand_peek_push(void) {
  cn_wand_peek_stack_top++;
  if (cn_wand_peek_stack_top >= CN_WAND_PEEK_STACK_MAX) {
    cn_printf(CN_LOGGING_ERROR, "******** FULMINATE ERROR *********\n");
    cn_printf(CN_LOGGING_ERROR,
        "wand nesting depth exceeded (max %d)\n",
        CN_WAND_PEEK_STACK_MAX);
    exit(1);
  }
  cn_wand_peek_stack[cn_wand_peek_stack_top] = true;
  if (cn_wand_debug_enabled()) {
    fprintf(stderr, "[WAND DEBUG] push -> depth=%d\n", cn_wand_peek_stack_top);
  }
}

void cn_wand_peek_and(_Bool matched) {
  if (cn_wand_peek_stack_top < 0) {
    cn_printf(CN_LOGGING_ERROR, "******** FULMINATE ERROR *********\n");
    cn_printf(
        CN_LOGGING_ERROR, "cn_wand_peek_and called outside a wand postulate\n");
    exit(1);
  }
  cn_wand_peek_stack[cn_wand_peek_stack_top] =
      cn_wand_peek_stack[cn_wand_peek_stack_top] && matched;
  if (cn_wand_debug_enabled()) {
    fprintf(stderr,
        "[WAND DEBUG] and(%d) -> depth=%d running=%d\n",
        (int)matched,
        cn_wand_peek_stack_top,
        (int)cn_wand_peek_stack[cn_wand_peek_stack_top]);
  }
}

void cn_wand_peek_and_bool(cn_bool* cn_b) {
  if (cn_wand_debug_enabled()) {
    fprintf(stderr, "[WAND DEBUG] and_bool(%d)\n", (int)cn_b->val);
  }
  cn_wand_peek_and(cn_b->val);
}

cn_bool* cn_wand_peek_pop(void) {
  if (cn_wand_peek_stack_top < 0) {
    cn_printf(CN_LOGGING_ERROR, "******** FULMINATE ERROR *********\n");
    cn_printf(CN_LOGGING_ERROR, "cn_wand_peek_pop called with an empty stack\n");
    exit(1);
  }
  _Bool result = cn_wand_peek_stack[cn_wand_peek_stack_top];
  cn_wand_peek_stack_top--;
  if (cn_wand_debug_enabled()) {
    fprintf(stderr, "[WAND DEBUG] pop -> result=%d\n", (int)result);
  }
  return convert_to_cn_bool(result);
}

_Bool c_ownership_check_bool(
    void* generic_c_ptr, int size, signed long expected_stack_depth) {
  /* Same ghost-state lookup as c_ownership_check, but reports a
     match/no-match result instead of aborting the test on failure - used
     only by a wand's postulate (WAND_PEEK), which must never itself fail
     the test.

     A postulate is evaluated within the SAME checkpoint pass as any
     ordinary take clauses that precede it (e.g. the outer `take L2 =
     Listrep(curr)` in a loop invariant, or an ordinary take earlier in an
     ensures block). Those ordinary takes (cn_put_ownership,
     cn_loop_get_ownership) check at expected_stack_depth but then RETAG
     the resource to expected_stack_depth - 1, all before this postulate
     ever runs. So a resource the postulate is peeking may legitimately
     sit at either expected_stack_depth (untouched, e.g. still-PRE-tagged)
     or expected_stack_depth - 1 (already retagged by a sibling take in
     this same block) - accept either, since a peek never mutates
     anything, so being lenient about which one doesn't introduce any
     unsoundness. */
  if (size < 1)
    return true;

  uintptr_t address = (uintptr_t)generic_c_ptr;
  rmap_range_res_t res = ownership_ghost_state_extrema(address, size);

  if (res.defined && res.min == res.max) {
    if (res.max == WILDCARD_DEPTH)
      return true;
    if (res.max == expected_stack_depth || res.max == expected_stack_depth - 1)
      return true;
    return false;
  }

  for (size_t addr = address; addr < address + size; addr++) {
    int depth = ownership_ghost_state_get(addr);
    if (depth != expected_stack_depth && depth != expected_stack_depth - 1
        && depth != WILDCARD_DEPTH) {
      return false;
    }
  }

  return true;
}

void cn_wand_peek_ownership(void* generic_c_ptr, size_t size) {
  /* Used for a wand's antecedent: check the address is currently owned by
     this frame, WITHOUT retagging/consuming it - the address must remain
     available for whatever consumes it next (either the wand's consequent,
     if it happens to reuse the same address, or the ordinary postcondition/
     loop leak check, unaffected either way since nothing was mutated
     here). A mismatch does not abort: it's recorded via cn_wand_peek_and,
     and the generated code decides (via cn_wand_peek_pop) whether to skip
     the wand's consequent. */
  _Bool matched = c_ownership_check_bool(generic_c_ptr, (int)size, cn_stack_depth);
  if (cn_wand_debug_enabled()) {
    fprintf(stderr,
        "[WAND DEBUG] peek ownership ptr=%p size=%zu depth=%ld matched=%d\n",
        generic_c_ptr,
        size,
        cn_stack_depth,
        (int)matched);
  }
  cn_wand_peek_and(matched);
}

void cn_get_or_put_ownership(enum spec_mode spec_mode,
    void* generic_c_ptr,
    size_t size,
    struct loop_ownership* loop_ownership) {
  nr_owned_predicates++;
  if (!is_wildcard(generic_c_ptr, (int)size)) {
    switch (spec_mode) {
      case PRE:
        cn_get_ownership(generic_c_ptr, size);
        break;
      case POST:
        cn_put_ownership(generic_c_ptr, size);
        break;
      case WAND_PEEK:
        cn_wand_peek_ownership(generic_c_ptr, size);
        break;
      case LOOP:
        cn_loop_get_ownership(generic_c_ptr, size, loop_ownership);
        fallthrough;
      default:
        break;
    }
  }
}

void report_and_correct_missing_ownership(
    int64_t addr, size_t size, int depth, int expected_stack_depth) {
  // TODO: switch depth check depending on access kind
  // see https://github.com/rems-project/cn-private/blob/main/notes/notes124-2025-09-02-fulminate-inferring-ownership.md
  if (depth == UNMAPPED_VAL || depth < expected_stack_depth) {
    assert(size > 0);

    // report missing ownership
    if (global_error_msg_info)
      print_error_msg_info_single(global_error_msg_info);
    if (size == 1) {
      cn_printf(CN_LOGGING_INFO,
          "  ==> " FMT_PTR " missing ownership specification.\n",
          (unsigned long)addr);
    } else {
      cn_printf(CN_LOGGING_INFO,
          "  ==> " FMT_PTR "..." FMT_PTR " (%d bytes) missing ownership specification.\n",
          (unsigned long)addr,
          (unsigned long)addr + size - 1,
          (int)size);
    }

    // correct entry in ghost state
    ownership_ghost_state_set(addr, size, expected_stack_depth, 0);
  }
}

enum region_owned c_ownership_check(
    char* access_kind, void* generic_c_ptr, int size, signed long expected_stack_depth) {
  if (size < 1)
    return FULL_WILDCARD;  // Arbitrary...

  uintptr_t address = (uintptr_t)generic_c_ptr;
  rmap_range_res_t res = ownership_ghost_state_extrema(address, size);

  // contiguous range mapped to a single stack depth
  if (res.defined && res.min == res.max) {
    if (res.max == WILDCARD_DEPTH)
      return FULL_WILDCARD;
    else if (res.max == expected_stack_depth)
      return NO_WILDCARD;
    else if (correct_missing_ownership) {
      report_and_correct_missing_ownership(address, size, res.max, expected_stack_depth);
      return NO_WILDCARD;
    }
  }

  // ownership error handling
  for (size_t addr = address; addr < address + size; addr++) {
    int depth = ownership_ghost_state_get(addr);
    if (depth != expected_stack_depth && depth != WILDCARD_DEPTH) {
      if (correct_missing_ownership) {
        report_and_correct_missing_ownership(addr, 1, depth, expected_stack_depth);
      } else {
        print_error_msg_info(global_error_msg_info);
        cn_printf(CN_LOGGING_ERROR, "%s failed.\n", access_kind);
        if (depth == UNMAPPED_VAL) {
          cn_printf(CN_LOGGING_ERROR,
              "  ==> " FMT_PTR "[%d] (" FMT_PTR ") not owned\n",
              addr,
              0,
              addr);
        } else {
          cn_printf(CN_LOGGING_ERROR,
              "  ==> " FMT_PTR "[%d] (" FMT_PTR
              ") not owned at expected function call stack depth %ld\n",
              addr,
              0,
              addr,
              expected_stack_depth);
          cn_printf(CN_LOGGING_ERROR, "  ==> (owned at stack depth: %d)\n", depth);
        }
        cn_failure(CN_FAILURE_CHECK_OWNERSHIP, C_ACCESS);
      }
    }
  }

  return SOME_WILDCARD;
}

enum region_owned c_ownership_check_loop_tolerant(char* access_kind,
    void* generic_c_ptr,
    int size,
    signed long expected_stack_depth,
    struct loop_ownership* loop_ownership) {
  /* Identical to c_ownership_check immediately above, except: while
     cn_wand_construct_depth > 0 (see its definition, and the comment above
     cn_wand_construct_push in utils.h, for why this gate must stay even
     though the tolerance rule below is no longer depth-based), an address
     already retagged to (expected_stack_depth - 1) is ALSO accepted as
     owned, PROVIDED it also falls within loop_ownership - i.e. PROVIDED
     this SPECIFIC address range was actually claimed by an earlier take
     within this exact loop invariant-check pass (see
     cn_loop_ownership_contains above, and the long comment above
     cn_wand_construct_depth for the bstDelete.c/ParRep motivating case).
     depth-1 alone is deliberately no longer sufficient here (contrast an
     earlier version of this function, see git history): depth-1 only
     tells us SOME earlier take in this dynamic checkpoint scope retagged
     SOMETHING, not that it was THIS address; loop_ownership membership
     tells us which addresses those earlier takes actually were. Only
     consulted from cn_loop_get_ownership, which is also the only place
     that ever populates loop_ownership (see
     cn_add_to_loop_ownership_state), so membership here always means
     "claimed for real by an earlier take in this exact pass", never a
     coincidental match against some unrelated resource. */
  if (size < 1)
    return FULL_WILDCARD;  // Arbitrary...

  uintptr_t address = (uintptr_t)generic_c_ptr;
  rmap_range_res_t res = ownership_ghost_state_extrema(address, size);

  // contiguous range mapped to a single stack depth
  if (res.defined && res.min == res.max) {
    if (res.max == WILDCARD_DEPTH)
      return FULL_WILDCARD;
    else if (res.max == expected_stack_depth)
      return NO_WILDCARD;
    else if (cn_wand_construct_depth > 0 && res.max == expected_stack_depth - 1
        && cn_loop_ownership_contains(generic_c_ptr, (size_t)size, loop_ownership))
      return NO_WILDCARD;
    else if (correct_missing_ownership) {
      report_and_correct_missing_ownership(address, size, res.max, expected_stack_depth);
      return NO_WILDCARD;
    }
  }

  // ownership error handling
  for (size_t addr = address; addr < address + size; addr++) {
    int depth = ownership_ghost_state_get(addr);
    if (cn_wand_construct_depth > 0 && depth == expected_stack_depth - 1
        && cn_loop_ownership_contains((void*)addr, 1, loop_ownership))
      continue;
    if (depth != expected_stack_depth && depth != WILDCARD_DEPTH) {
      if (correct_missing_ownership) {
        report_and_correct_missing_ownership(addr, 1, depth, expected_stack_depth);
      } else {
        print_error_msg_info(global_error_msg_info);
        cn_printf(CN_LOGGING_ERROR, "%s failed.\n", access_kind);
        if (depth == UNMAPPED_VAL) {
          cn_printf(CN_LOGGING_ERROR,
              "  ==> " FMT_PTR "[%d] (" FMT_PTR ") not owned\n",
              addr,
              0,
              addr);
        } else {
          cn_printf(CN_LOGGING_ERROR,
              "  ==> " FMT_PTR "[%d] (" FMT_PTR
              ") not owned at expected function call stack depth %ld\n",
              addr,
              0,
              addr,
              expected_stack_depth);
          cn_printf(CN_LOGGING_ERROR, "  ==> (owned at stack depth: %d)\n", depth);
        }
        cn_failure(CN_FAILURE_CHECK_OWNERSHIP, C_ACCESS);
      }
    }
  }

  return SOME_WILDCARD;
}

// TODO: Reimplement for new ownership ghost state data structure
void dump_ownership_ghost_state(int stack_depth) {
  // hash_table_iterator it = ht_iterator(cn_ownership_global_ghost_state);
  // cn_printf(CN_LOGGING_INFO, "ADDRESS \t\t\tCN STACK DEPTH\n")
  //     cn_printf(CN_LOGGING_INFO, "====================\n") while (ht_next(&it)) {
  //   int64_t* key = it.key;
  //   int* depth = it.value;
  //   if (*depth == stack_depth) {
  //     cn_printf(CN_LOGGING_INFO, "[%p] => depth: %d\n", (void*)*key, *depth);
  //   }
  // }
}

// TODO: Reimplement for new ownership ghost state data structure
_Bool is_mapped(void* ptr) {
  // hash_table_iterator it = ht_iterator(cn_ownership_global_ghost_state);
  // while (ht_next(&it)) {
  //   int64_t* key = it.key;
  //   if (*key == (int64_t)ptr) {
  //     int* depth = it.value;
  //     cn_printf(CN_LOGGING_INFO, "[%p] => depth: %d\n", (void*)*key, *depth);
  //     return true;
  //   }
  // }
  return false;
}

/* TODO: Need address of and size of every stack-allocated variable - could store in struct and pass through. But this is an optimisation */
// void c_map_locals_to_stack_depth(ownership_ghost_state *cn_ownership_global_ghost_state, size_t size, int cn_stack_depth, ...) {
//     va_list args;

//     va_start(args, n);

//     for (int i = 0; i < n; i++) {
//         uintptr_t fn_local_ptr = va_arg(args, uintptr_t);
//         signed long address_key = fn_local_ptr;
//         ghost_state_set(cn_ownership_global_ghost_state, &address_key, cn_stack_depth);
//         fulminate_free(address_key);
//     }

//     va_end(args);
// }

cn_map* cn_map_set(cn_map* m, cn_integer* key, void* value) {
  ht_set(m, &key->val, value);
  return m;
}

cn_map* cn_map_deep_copy(cn_map* m1) {
  cn_map* m2 = map_create();

  hash_table_iterator hti = ht_iterator(m1);

  while (ht_next(&hti)) {
    int64_t* curr_key = hti.key;
    void* val = ht_get(m1, curr_key);
    ht_set(m2, curr_key, val);
  }

  return m2;
}

cn_map* default_cn_map(void) {
  return map_create();
}

cn_bool* default_cn_bool(void) {
  return convert_to_cn_bool(false);
}

cn_bool* cn_pointer_equality(void* i1, void* i2) {
  return convert_to_cn_bool((((cn_pointer*)i1)->ptr) == (((cn_pointer*)i2)->ptr));
}

cn_bool* cn_pointer_is_null(cn_pointer* p) {
  return convert_to_cn_bool(p->ptr == NULL);
}

cn_bool* cn_pointer_lt(cn_pointer* p1, cn_pointer* p2) {
  return convert_to_cn_bool(p1->ptr < p2->ptr);
}

cn_bool* cn_pointer_le(cn_pointer* p1, cn_pointer* p2) {
  return convert_to_cn_bool(p1->ptr <= p2->ptr);
}

cn_bool* cn_pointer_gt(cn_pointer* p1, cn_pointer* p2) {
  return convert_to_cn_bool(p1->ptr > p2->ptr);
}

cn_bool* cn_pointer_ge(cn_pointer* p1, cn_pointer* p2) {
  return convert_to_cn_bool(p1->ptr >= p2->ptr);
}

cn_pointer* cast_cn_pointer_to_cn_pointer(cn_pointer* p) {
  return p;
}

// Check if m2 is a subset of m1
cn_bool* cn_map_subset(
    cn_map* m1, cn_map* m2, cn_bool*(value_equality_fun)(void*, void*)) {
  if (ht_size(m1) != ht_size(m2))
    return convert_to_cn_bool(0);

  hash_table_iterator hti1 = ht_iterator(m1);

  while (ht_next(&hti1)) {
    int64_t* curr_key = hti1.key;
    void* val1 = ht_get(m1, curr_key);
    void* val2 = ht_get(m2, curr_key);

    /* Check if other map has this key at all */
    if (!val2)
      return convert_to_cn_bool(0);

    if (convert_from_cn_bool(cn_bool_not(value_equality_fun(val1, val2)))) {
      // cn_printf(CN_LOGGING_INFO, "Values not equal!\n");
      return convert_to_cn_bool(0);
    }
  }

  return convert_to_cn_bool(1);
}

cn_bool* cn_map_equality(
    cn_map* m1, cn_map* m2, cn_bool*(value_equality_fun)(void*, void*)) {
  return cn_bool_and(cn_map_subset(m1, m2, value_equality_fun),
      cn_map_subset(m2, m1, value_equality_fun));
}

cn_pointer* convert_to_cn_pointer(const void* ptr) {
  cn_pointer* res = (cn_pointer*)cn_bump_malloc(sizeof(cn_pointer));
  res->ptr = (void*)ptr;  // Carries around an address
  return res;
}

void* convert_from_cn_pointer(cn_pointer* cn_ptr) {
  return cn_ptr->ptr;
}

cn_pointer* cn_pointer_min(cn_pointer* p, cn_pointer* q) {
  uintptr_t p_raw = (uintptr_t)convert_from_cn_pointer(p);
  uintptr_t q_raw = (uintptr_t)convert_from_cn_pointer(q);
  return convert_to_cn_pointer((void*)(p_raw < q_raw ? p_raw : q_raw));
}

cn_pointer* cn_pointer_max(cn_pointer* p, cn_pointer* q) {
  uintptr_t p_raw = (uintptr_t)convert_from_cn_pointer(p);
  uintptr_t q_raw = (uintptr_t)convert_from_cn_pointer(q);
  return convert_to_cn_pointer((void*)(p_raw > q_raw ? p_raw : q_raw));
}

cn_pointer* cn_pointer_mod(cn_pointer* ptr, cn_pointer* n) {
  uintptr_t ptr_raw = (uintptr_t)convert_from_cn_pointer(ptr);
  uintptr_t n_raw = (uintptr_t)convert_from_cn_pointer(n);
  return convert_to_cn_pointer((void*)(ptr_raw % n_raw));
}

struct cn_error_message_info* make_error_message_info_entry(const char* function_name,
    char* file_name,
    int line_number,
    char* cn_source_loc,
    struct cn_error_message_info* parent) {
  struct cn_error_message_info* entry =
      fulm_malloc(sizeof(struct cn_error_message_info), &fulm_default_alloc);
  entry->function_name = function_name;
  entry->file_name = file_name;
  entry->line_number = line_number;
  entry->cn_source_loc = cn_source_loc;
  entry->parent = parent;
  entry->child = NULL;
  if (parent) {
    parent->child = entry;
  }
  return entry;
}

void update_error_message_info_(
    const char* function_name, char* file_name, int line_number, char* cn_source_loc) {
  global_error_msg_info = make_error_message_info_entry(
      function_name, file_name, line_number, cn_source_loc, global_error_msg_info);
}

void initialise_error_msg_info_(
    const char* function_name, char* file_name, int line_number) {
  // cn_printf(CN_LOGGING_INFO, "Initialising error message info\n");
  global_error_msg_info =
      make_error_message_info_entry(function_name, file_name, line_number, 0, NULL);
}

void reset_error_msg_info(void) {
  global_error_msg_info = NULL;
}

void free_error_msg_info(void) {
  while (global_error_msg_info != NULL) {
    cn_pop_msg_info();
  }
}

void cn_pop_msg_info(void) {
  struct cn_error_message_info* old = global_error_msg_info;
  global_error_msg_info = old->parent;
  if (global_error_msg_info) {
    global_error_msg_info->child = NULL;
  }
  fulm_free(old, &fulm_default_alloc);
}

static uint32_t cn_fls(uint32_t x) {
  return x ? sizeof(x) * 8 - __builtin_clz(x) : 0;
}

static uint64_t cn_flsl(uint64_t x) {
  return x ? sizeof(x) * 8 - __builtin_clzl(x) : 0;
}

cn_bits_u32* cn_bits_u32_fls(cn_bits_u32* i1) {
  cn_bits_u32* res = (cn_bits_u32*)cn_bump_malloc(sizeof(cn_bits_u32));
  res->val = cn_fls(i1->val);
  return res;
}

cn_bits_u64* cn_bits_u64_flsl(cn_bits_u64* i1) {
  cn_bits_u64* res = (cn_bits_u64*)cn_bump_malloc(sizeof(cn_bits_u64));
  res->val = cn_flsl(i1->val);
  return res;
}

void* cn_aligned_alloc_aux(size_t align, size_t size, _Bool wildcard) {
  void* p = aligned_alloc(align, size);
  if (p) {
    char str[] = "cn_aligned_alloc";
    fulminate_assume_ownership((void*)p, size, str, wildcard);
  } else if (size != 0) {
    cn_failure(CN_FAILURE_USER_ALLOC, NON_SPEC);
  }

  return p;
}

void* cn_aligned_alloc(size_t align, size_t size) {
  return cn_aligned_alloc_aux(align, size, false);
}

void* cn_unsafe_aligned_alloc(size_t align, size_t size) {
  return cn_aligned_alloc_aux(align, size, true);
}

void* cn_malloc_aux(unsigned long size, _Bool wildcard) {
  void* p = malloc(size);
  if (p) {
    char str[] = "cn_malloc";
    fulminate_assume_ownership((void*)p, size, str, wildcard);
  } else if (size != 0) {
    cn_failure(CN_FAILURE_USER_ALLOC, NON_SPEC);
  }

  return p;
}

void* cn_malloc(unsigned long size) {
  return cn_malloc_aux(size, false);
}

void* cn_unsafe_malloc(unsigned long size) {
  return cn_malloc_aux(size, true);
}

void* cn_calloc_aux(size_t num, size_t size, _Bool wildcard) {
  void* p = calloc(num, size);
  if (p) {
    char str[] = "cn_calloc";
    fulminate_assume_ownership((void*)p, num * size, str, wildcard);
  } else if (size != 0) {
    cn_failure(CN_FAILURE_USER_ALLOC, NON_SPEC);
  }

  return p;
}

void* cn_calloc(size_t num, size_t size) {
  return cn_calloc_aux(num, size, false);
}

void* cn_unsafe_calloc(size_t num, size_t size) {
  return cn_calloc_aux(num, size, true);
}

void cn_free_sized(void* malloced_ptr, size_t size) {
  // cn_printf(CN_LOGGING_INFO, "[CN: freeing ownership] " FMT_PTR ", size: %lu\n", (uintptr_t) malloced_ptr, size);
  if (malloced_ptr != NULL) {
    enum region_owned owned =
        c_ownership_check("Free", malloced_ptr, size, cn_stack_depth);
    if (owned == NO_WILDCARD)
      c_remove_from_ghost_state_internal((uintptr_t)malloced_ptr, size);
    else
      assert(owned == FULL_WILDCARD);  // INCOMPLETE
  }
}

void cn_print_nr_owned_predicates(void) {
  printf("Owned predicates £%lu\n", nr_owned_predicates);
}

void cn_print_u64(const char* str, unsigned long u) {
  // cn_printf(CN_LOGGING_INFO, "\n\nprint %s: %20lx,  %20lu\n\n", str, u, u);
}

void cn_print_nr_u64(int i, unsigned long u) {
  // cn_printf(CN_LOGGING_INFO, "\n\nprint %d: %20lx,  %20lu\n", i, u, u);
}

// ghost arguments
void** ghost_arg_array;

void alloc_ghost_array(int ghost_array_size) {
  ghost_arg_array = fulm_malloc(ghost_array_size * sizeof(void*), &fulm_default_alloc);
}

void add_to_ghost_array(int i, void* ptr_to_ghost_arg) {
  ghost_arg_array[i] = ptr_to_ghost_arg;
}

void free_ghost_array(void) {
  fulm_free(ghost_arg_array, &fulm_default_alloc);
}

void* load_from_ghost_array(int i) {
  return ghost_arg_array[i];
}

void cn_ghost_arg_failure(void) {
  cn_printf(CN_LOGGING_ERROR, "Runtime typechecking of ghost arguments failed\n")
      cn_printf(CN_LOGGING_ERROR,
          "************************************************************\n")
          print_error_msg_info(global_error_msg_info);
  cn_failure(CN_FAILURE_GHOST_ARGS, PRE);
}
