#include <assert.h>
#include <inttypes.h>
#include <limits.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cn-smt/memory/arena.h>
#include <cn-smt/memory/intern.h>
#include <cn-smt/memory/test_alloc.h>
#include <cn-smt/sexp.h>
#include <cn-smt/solver.h>
#include <cn-smt/subst.h>
#include <cn-smt/terms.h>
#include <cn-smt/to_smt.h>

// Generate vector implementation for cn_member_pair
BENNET_VECTOR_IMPL(cn_member_pair)

// Generate vector implementation for cn_term_ptr
BENNET_VECTOR_IMPL(cn_term_ptr)

// Generate vector implementation for cn_match_case
BENNET_VECTOR_IMPL(cn_match_case)

// Functions that pick names for things (converted from OCaml CN_Names module)

// Helper function to get string representation of a symbol without numbers
const char* sym_pp_string_no_nums(cn_sym sym) {
  // Return the name part of the cn_sym struct
  return sym.name;
}

// Helper function to get the numeric part of a symbol
uint64_t sym_num(cn_sym sym) {
  // Return the id part of the cn_sym struct
  return sym.id;
}

// Helper function to get string from Id
const char* id_get_string(int id) {
  char buffer[64];
  snprintf(buffer, sizeof(buffer), "id_%d", id);
  return cn_intern_string(buffer);
}

const char* fn_name(cn_sym x) {
  assert(x.name);
  const char* base_name = sym_pp_string_no_nums(x);
  uint64_t num = sym_num(x);

  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_%" PRIu64, base_name, num);
  return cn_intern_string(buffer);
}

// Function definition name - just append _func without number
const char* fn_def_name(cn_sym x) {
  assert(x.name);
  const char* base_name = sym_pp_string_no_nums(x);

  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_func", base_name);
  return cn_intern_string(buffer);
}

const char* named_expr_name(void) {
  return "_cn_named";
}

const char* cn_smt_struct_name(const char* name) {
  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_struct", name);
  return cn_intern_string(buffer);
}

const char* struct_con_name(const char* name) {
  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_struct_con", name);
  return cn_intern_string(buffer);
}

const char* struct_field_name(const char* member_name) {
  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_struct_fld", member_name);
  return cn_intern_string(buffer);
}

const char* datatype_name(cn_sym x) {
  const char* base_name = sym_pp_string_no_nums(x);
  uint64_t num = sym_num(x);

  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_%" PRIu64, base_name, num);
  return cn_intern_string(buffer);
}

const char* datatype_con_name(cn_sym x) {
  const char* base_name = sym_pp_string_no_nums(x);
  uint64_t num = sym_num(x);

  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_%" PRIu64, base_name, num);
  return cn_intern_string(buffer);
}

const char* datatype_field_name(int x) {
  const char* base_name = id_get_string(x);

  char buffer[256];
  snprintf(buffer, sizeof(buffer), "%s_data_fld", base_name);
  return cn_intern_string(buffer);
}

// Global counter for fresh name generation
static int fresh_counter = 0;

/** Generate a fresh name */
char* fresh_name(const char* x) {
  // Calculate required buffer size: x + "_" + fresh_counter + null terminator
  size_t len = strlen(x) + 1 + snprintf(NULL, 0, "%d", fresh_counter) + 1;
  char* result = cn_test_malloc(len);
  assert(result);

  sprintf(result, "%s_%d", x, fresh_counter);
  fresh_counter++;
  return result;
}

/* Note: CVC5 would have support for arbitrary tuples without declaring them. */

// CN_Tuple module functionality
const int CN_TUPLE_MAX_ARITY =
    15; /* TODO: compute required arity based on the input program. */

static const char* cn_tuple_name(int arity) {
  assert(arity <= CN_TUPLE_MAX_ARITY);

  char buffer[64];
  snprintf(buffer, sizeof(buffer), "cn_tuple_%d", arity);
  return cn_intern_string(buffer);
}

static const char* cn_tuple_selector(int arity, int field) {
  assert(arity <= CN_TUPLE_MAX_ARITY);

  char buffer[64];
  snprintf(buffer, sizeof(buffer), "cn_get_%d_of_%d", field, arity);
  return cn_intern_string(buffer);
}

/** A tuple type with the given list of types */
sexp_t* cn_tuple_type_name(sexp_t** types, size_t type_count) {
  int arity = (int)type_count;
  const char* name = cn_tuple_name(arity);
  sexp_t* result = sexp_app_str(name, types, type_count);
  return result;
}

/** Make a tuple value */
const char* cn_tuple_constructor_name(int arity) {
  assert(arity <= CN_TUPLE_MAX_ARITY);
  return cn_tuple_name(arity);
}

/** Get a field of a tuple */
const char* cn_tuple_get_selector_name(int arity, int field) {
  return cn_tuple_selector(arity, field);
}

// CN_Option module functionality (converted from OCaml)

/** Option type name */
const char* cn_option_name = "cn_option";

/** None constructor name */
const char* cn_option_none_name = "cn_none";

/** Some constructor name */
const char* cn_option_some_name = "cn_some";

/** Value field name */
const char* cn_option_val_name = "cn_val";

/** Create an option type with element type a */
sexp_t* cn_option_type(sexp_t* a) {
  sexp_t* args[] = {a};
  return sexp_app_str(cn_option_name, args, 1);
}

/** Create a None value with given element type */
sexp_t* cn_option_none(sexp_t* elT) {
  return sexp_as_type(sexp_atom(cn_option_none_name), cn_option_type(elT));
}

/** Create a Some value with given content */
sexp_t* cn_option_some(sexp_t* x) {
  sexp_t* args[] = {x};
  return sexp_app_str(cn_option_some_name, args, 1);
}

/** Test if an option value is Some */
sexp_t* cn_option_is_some(sexp_t* x) {
  // Generate "is-cn_some" predicate name
  char buffer[256];
  snprintf(buffer, sizeof(buffer), "is-%s", cn_option_some_name);
  const char* predicate_name = cn_intern_string(buffer);

  sexp_t* args[] = {x};
  sexp_t* result = sexp_app_str(predicate_name, args, 1);

  return result;
}

/** Extract the value from a Some option */
sexp_t* cn_option_val(sexp_t* x) {
  sexp_t* args[] = {x};
  return sexp_app_str(cn_option_val_name, args, 1);
}

// CN_List module functionality (placeholder)
sexp_t* cn_list_type(sexp_t* element_type) {
  sexp_t* args[] = {element_type};
  return sexp_app_str("cn_list", args, 1);
}

/** Translate a base type to SMT */
sexp_t* translate_base_type(cn_base_type bt) {
  switch (bt.tag) {
    case CN_BASE_UNIT: {
      // Unit -> CN_Tuple.t []
      return cn_option_type(sexp_list(NULL, 0));  // Empty tuple
    }

    case CN_BASE_BOOL: {
      // Bool -> SMT.t_bool
      return t_bool();
    }

    case CN_BASE_INTEGER: {
      // Integer -> SMT.t_int
      return t_int();
    }

    case CN_BASE_BITS: {
      // Bits (_, n) -> SMT.t_bits n
      return t_bits(bt.data.bits.size_bits);
    }

    case CN_BASE_REAL: {
      // Real -> SMT.t_real
      return t_real();
    }

    case CN_BASE_LOC: {
      return t_loc();
    }

    case CN_BASE_CTYPE: {
      // CType -> SMT.t_int
      return t_int();
    }

    case CN_BASE_LIST: {
      // List bt -> CN_List.t (translate_base_type bt)
      assert(bt.data.list.element_type);
      sexp_t* element_sexp = translate_base_type(*bt.data.list.element_type);
      assert(element_sexp);

      sexp_t* result = cn_list_type(element_sexp);
      return result;
    }

    case CN_BASE_SET: {
      // Set bt -> CN_Set.t (translate_base_type bt)
      assert(bt.data.set.element_type);
      sexp_t* element_sexp = translate_base_type(*bt.data.set.element_type);
      assert(element_sexp);

      sexp_t* result = t_set(element_sexp);
      return result;
    }

    case CN_BASE_MAP: {
      // Map (k, v) -> SMT.t_array (translate_base_type k) (translate_base_type v)
      assert(bt.data.map.key_type && bt.data.map.value_type);

      sexp_t* key_sexp = translate_base_type(*bt.data.map.key_type);
      assert(key_sexp);

      sexp_t* value_sexp = translate_base_type(*bt.data.map.value_type);
      assert(value_sexp);

      sexp_t* result = t_array(key_sexp, value_sexp);
      return result;
    }

    case CN_BASE_TUPLE: {
      // Tuple bts -> CN_Tuple.t (List.map translate_base_type bts)

      sexp_t** translated_types = cn_test_malloc(bt.data.tuple.count * sizeof(sexp_t*));
      assert(translated_types);

      for (size_t i = 0; i < bt.data.tuple.count; i++) {
        translated_types[i] = translate_base_type(bt.data.tuple.types[i]);
        assert(translated_types[i]);
      }

      sexp_t* result = cn_tuple_type_name(translated_types, bt.data.tuple.count);

      // Clean up
      for (size_t i = 0; i < bt.data.tuple.count; i++) {
      }
      cn_test_free(translated_types);
      return result;
    }

    case CN_BASE_STRUCT: {
      // Struct tag -> SMT.atom (CN_Names.struct_name tag)
      // Convert int tag to cn_sym (assuming tag is symbol id)
      const char* struct_name_str = cn_smt_struct_name(bt.data.struct_tag.tag);
      assert(struct_name_str);

      sexp_t* result = sexp_atom(struct_name_str);
      return result;
    }

    case CN_BASE_DATATYPE: {
      // Datatype tag -> SMT.atom (datatype name with _dt suffix)
      const char* tag_name = bt.data.datatype_tag.tag;
      assert(tag_name);

      // Create datatype SMT name: tag_name + "_dt"
      char buffer[256];
      snprintf(buffer, sizeof(buffer), "%s_dt", tag_name);

      sexp_t* result = sexp_atom(buffer);
      return result;
    }

    case CN_BASE_OPTION: {
      // Option bt -> CN_Option.t (translate_base_type bt)
      assert(bt.data.option.element_type);

      sexp_t* element_sexp = translate_base_type(*bt.data.option.element_type);
      assert(element_sexp);

      sexp_t* result = cn_option_type(element_sexp);
      return result;
    }

    case CN_BASE_RECORD: {
      // Record members -> translate_base_type (Tuple (List.map snd members))

      // Create a tuple of the member types
      cn_base_type tuple_bt =
          cn_base_type_tuple(bt.data.record.types, bt.data.record.count);

      return translate_base_type(tuple_bt);
    }

    default:
      assert(false);
      return NULL;
  }
}

/////////////////
/* Term to SMT */
/////////////////

/** Translate a constant to SMT */
sexp_t* translate_const(void* s, cn_const* co) {
  assert(co);

  switch (co->type) {
    case CN_CONST_Z: {
      // Z z -> SMT.int_zk z
      return int_k(co->data.z);
    }

    case CN_CONST_BITS: {
      // Bits ((_, w), z) -> SMT.bv_k w z
      return bv_k(co->data.bits.info.size_bits, co->data.bits.value);
    }

    case CN_CONST_Q: {
      // Q q -> SMT.real_k q
      char* buffer = malloc(64);
      snprintf(buffer, 64, "%.15g", co->data.q);
      return sexp_atom(buffer);
    }

    case CN_CONST_POINTER: {
      return loc_k(co->data.pointer);
    }

    case CN_CONST_BOOL: {
      // Bool b -> SMT.bool_k b
      return bool_k(co->data.boolean);
    }

    case CN_CONST_UNIT: {
      // Unit -> type-annotated 0-tuple
      // Create the nullary tuple type
      sexp_t* tuple_type = cn_tuple_type_name(NULL, 0);
      assert(tuple_type);

      // Create type-annotated tuple constructor
      const char* tuple_name = cn_tuple_constructor_name(0);
      sexp_t* constructor_atom = sexp_atom(tuple_name);
      sexp_t* result = sexp_as_type(constructor_atom, tuple_type);

      // Cleanup
      // tuple_name is interned, no need to free

      return result;
    }

    case CN_CONST_NULL: {
      // Null -> CN_Pointer.con_null
      return loc_k((uintptr_t)NULL);
    }

    case CN_CONST_DEFAULT: {
      // Default t -> CN_Option.val_ (CN_Option.none (translate_base_type t))
      sexp_t* base_type_sexp = translate_base_type(co->data.default_type);
      assert(base_type_sexp);

      sexp_t* none_option = cn_option_none(base_type_sexp);
      sexp_t* result = cn_option_val(none_option);
      return result;
    }

    default:
      assert(false);
      return NULL;
  }
}

/** Helper to check if base type is a bits type and extract sign and size */
static bool is_bits_type(cn_base_type bt, bool* is_signed, int* size) {
  if (bt.tag != CN_BASE_BITS) {
    return false;
  }

  *is_signed = bt.data.bits.is_signed;
  *size = bt.data.bits.size_bits;

  return true;
}

/** Casting between bit-vector types */
sexp_t* bv_cast(cn_base_type to_type, cn_base_type from_type, sexp_t* x) {
  assert(x != NULL);

  bool to_signed, from_signed;
  int to_sz, from_sz;

  assert(is_bits_type(to_type, &to_signed, &to_sz));        // Error: non-bv type
  assert(is_bits_type(from_type, &from_signed, &from_sz));  // Error: non-bv type

  if (to_sz == from_sz) {
    // Same size, return as-is
    sexp_t* result = sexp_app(x, NULL, 0);  // Deep copy
    assert(result != NULL);
    return result;
  } else if (to_sz < from_sz) {
    // Truncate using extract
    sexp_t* result = bv_extract(to_sz - 1, 0, x);
    assert(result != NULL);
    return result;
  } else if (from_signed) {
    // Sign extend
    sexp_t* result = bv_sign_extend(to_sz - from_sz, x);
    assert(result != NULL);
    return result;
  } else {
    // Zero extend
    sexp_t* result = bv_zero_extend(to_sz - from_sz, x);
    assert(result != NULL);
    return result;
  }
}

// Forward declarations for recursive functions
static sexp_t* bv_clz_count(int result_w, int w, sexp_t* e);
static sexp_t* bv_ctz_count(int result_w, int w, sexp_t* e);

/** [bv_clz result_w w e] counts the leading zeroes in [e], which should
    be a bit-vector of width [w].  The result is a bit-vector of width [result_w].
    Note that this duplicates [e]. */
sexp_t* bv_clz(int result_w, int w, sexp_t* e) {
  assert(result_w > 0);
  assert(w > 0);
  assert(e != NULL);

  return bv_clz_count(result_w, w, e);
}

static sexp_t* bv_clz_count(int result_w, int w, sexp_t* e) {
  if (w == 1) {
    sexp_t* zero = bv_k(w, 0);
    assert(zero != NULL);

    sexp_t* is_zero = eq(e, zero);
    assert(is_zero != NULL);

    sexp_t* one_result = bv_k(result_w, 1);
    assert(one_result != NULL);

    sexp_t* zero_result = bv_k(result_w, 0);
    assert(zero_result != NULL);

    sexp_t* result = ite(is_zero, one_result, zero_result);
    assert(result != NULL);

    return result;
  } else {
    int top_w = w / 2;
    int bot_w = w - top_w;

    sexp_t* top = bv_extract(w - 1, w - top_w, e);
    assert(top != NULL);

    sexp_t* bot = bv_extract(bot_w - 1, 0, e);
    assert(bot != NULL);

    sexp_t* top_zero = bv_k(top_w, 0);
    assert(top_zero != NULL);

    sexp_t* top_is_zero = eq(top, top_zero);
    assert(top_is_zero != NULL);

    sexp_t* bot_count = bv_clz_count(result_w, bot_w, bot);
    assert(bot_count != NULL);

    sexp_t* top_count = bv_clz_count(result_w, top_w, top);
    assert(top_count != NULL);

    sexp_t* top_w_const = bv_k(result_w, top_w);
    assert(top_w_const != NULL);

    sexp_t* bot_plus_topw = bv_add(bot_count, top_w_const);
    assert(bot_plus_topw != NULL);

    sexp_t* result = ite(top_is_zero, bot_plus_topw, top_count);
    assert(result != NULL);

    // Clean up

    return result;
  }
}

/** [bv_ctz result_w w e] counts the trailing zeroes in [e], which should
    be a bit-vector of width [w].  The result is a bit-vector of width [result_w].
    Note that this duplicates [e]. */
sexp_t* bv_ctz(int result_w, int w, sexp_t* e) {
  assert(e && w > 0 && result_w > 0);

  return bv_ctz_count(result_w, w, e);
}

static sexp_t* bv_ctz_count(int result_w, int w, sexp_t* e) {
  if (w == 1) {
    sexp_t* zero = bv_k(w, 0);
    assert(zero != NULL);

    sexp_t* is_zero = eq(e, zero);
    assert(is_zero != NULL);

    sexp_t* one_result = bv_k(result_w, 1);
    assert(one_result != NULL);

    sexp_t* zero_result = bv_k(result_w, 0);
    assert(zero_result != NULL);

    sexp_t* result = ite(is_zero, one_result, zero_result);
    assert(result != NULL);

    return result;
  } else {
    int top_w = w / 2;
    int bot_w = w - top_w;

    sexp_t* top = bv_extract(w - 1, w - top_w, e);
    assert(top != NULL);

    sexp_t* bot = bv_extract(bot_w - 1, 0, e);
    assert(bot != NULL);

    sexp_t* bot_zero = bv_k(bot_w, 0);
    assert(bot_zero != NULL);

    sexp_t* bot_is_zero = eq(bot, bot_zero);
    assert(bot_is_zero != NULL);

    sexp_t* bot_count = bv_ctz_count(result_w, bot_w, bot);
    assert(bot_count != NULL);

    sexp_t* top_count = bv_ctz_count(result_w, top_w, top);
    assert(top_count != NULL);

    sexp_t* bot_w_const = bv_k(result_w, bot_w);
    assert(bot_w_const != NULL);

    sexp_t* top_plus_botw = bv_add(top_count, bot_w_const);
    assert(top_plus_botw != NULL);

    sexp_t* result = ite(bot_is_zero, top_plus_botw, bot_count);
    assert(result != NULL);

    // Clean up

    return result;
  }
}

// Helper function names from OCaml CN_Names module
const char* mul_name(cn_base_type bt) {
  return "cn_mul";
}
const char* div_name(cn_base_type bt) {
  return "cn_div";
}
const char* exp_name(cn_base_type bt) {
  return "cn_exp";
}
const char* rem_name(cn_base_type bt) {
  return "cn_rem";
}
const char* mod_name(cn_base_type bt) {
  return "cn_mod";
}

/** Helper to extract integer literal value */
static bennet_optional(sexp_ptr) get_num_z(cn_term* term, int64_t* result) {
  if (term && term->type == CN_TERM_CONST && term->data.const_val.type == CN_CONST_Z) {
    *result = term->data.const_val.data.z;
    sexp_t* found = sexp_atom("found");  // Placeholder for Some
    return bennet_optional_some(sexp_ptr, found);
  }
  return bennet_optional_none(sexp_ptr);  // None
}

/** Translate a CN term to SMT */
static sexp_t* translate_term_aux(struct cn_smt_solver* s, cn_term* iterm) {
  assert(s && iterm);

  switch (iterm->type) {
    case CN_TERM_CONST:
      return translate_const(s, &iterm->data.const_val);

    case CN_TERM_SYM: {
      const char* name = fn_name(iterm->data.sym);
      sexp_t* result = sexp_atom(name);
      return result;
    }

    case CN_TERM_UNOP: {
      cn_term* e1 = iterm->data.unop.operand;

      switch (iterm->data.unop.op) {
        case CN_UNOP_BW_FFS_NOSMT: {
          // NOTE: This desugaring duplicates e1
          // let intl i = int_lit_ i (IT.get_bt e1) loc in
          // translate_term s (ite_ (eq_ (e1, intl 0) loc, intl 0, add_ (arith_unop BW_CTZ_NoSMT e1 loc, intl 1) loc) loc)

          cn_term* zero = cn_smt_num(e1->base_type, 0);  // int_lit with e1's base type
          cn_term* one = cn_smt_num(e1->base_type, 1);

          // Create eq_(e1, 0)
          cn_term* eq_zero = cn_smt_eq(e1, zero);

          // Create arith_unop BW_CTZ_NoSMT e1
          cn_term* ctz_term = cn_term_alloc(CN_TERM_UNOP, e1->base_type);
          ctz_term->data.unop.op = CN_UNOP_BW_CTZ_NOSMT;
          ctz_term->data.unop.operand = e1;

          // Create add_(ctz_term, 1)
          cn_term* add_one = cn_smt_add(ctz_term, one);

          // Create ite_(eq_zero, 0, add_one)
          cn_term* ite_term = cn_smt_ite(eq_zero, zero, add_one);

          sexp_t* result = translate_term_aux(s, ite_term);

          return result;
        }

        case CN_UNOP_BW_FLS_NOSMT: {
          // Copying and adjusting BW_FFS_NoSMT rule
          // NOTE: This desugaring duplicates e1

          // Get size from e1's bit type
          assert(e1->base_type.tag == CN_BASE_BITS);
          int sz = e1->base_type.data.bits.size_bits;

          cn_term* zero = cn_smt_num(e1->base_type, 0);
          cn_term* sz_term = cn_smt_num(e1->base_type, sz);

          // Create eq_(e1, 0)
          cn_term* eq_zero = cn_smt_eq(e1, zero);

          // Create arith_unop BW_CLZ_NoSMT e1
          cn_term* clz_term = cn_term_alloc(CN_TERM_UNOP, e1->base_type);
          clz_term->data.unop.op = CN_UNOP_BW_CLZ_NOSMT;
          clz_term->data.unop.operand = e1;

          // Create sub_(sz, clz_term)
          cn_term* sub_term = cn_smt_sub(sz_term, clz_term);

          // Create ite_(eq_zero, 0, sub_term)
          cn_term* ite_term = cn_smt_ite(eq_zero, zero, sub_term);

          sexp_t* result = translate_term_aux(s, ite_term);

          return result;
        }

        case CN_UNOP_NOT: {
          sexp_t* operand_smt = translate_term_aux(s, e1);
          return bool_not(operand_smt);
        }

        case CN_UNOP_NEGATE: {
          sexp_t* operand_smt = translate_term_aux(s, e1);

          switch (iterm->base_type.tag) {
            case CN_BASE_BITS:
              return bv_neg(operand_smt);
            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_neg(operand_smt);
            default:
              assert(false);  // "Unop (Negate, _)"
              return NULL;
          }
        }

        case CN_UNOP_BW_COMPL: {
          sexp_t* operand_smt = translate_term_aux(s, e1);

          if (iterm->base_type.tag == CN_BASE_BITS) {
            return bv_compl(operand_smt);
          } else {
            assert(false);  // "Unop (BW_Compl, _)"
            return NULL;
          }
        }

        case CN_UNOP_BW_CLZ_NOSMT: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            int w = iterm->base_type.data.bits.size_bits;

            // Helper function wrapper for bv_clz
            sexp_t* operand_smt;
            if (sexp_is_atom(translate_term_aux(s, e1))) {
              operand_smt = bv_clz(w, w, translate_term_aux(s, e1));
            } else {
              char* x = fresh_name(named_expr_name());
              sexp_t* x_atom = sexp_atom(x);
              sexp_t* result_expr = bv_clz(w, w, x_atom);
              sexp_t* bindings[] = {
                  sexp_list((sexp_t*[]){x_atom, translate_term_aux(s, e1)}, 2)};
              sexp_t* result = sexp_let(bindings, 1, result_expr);
              cn_test_free(x);
              operand_smt = result;
            }

            return bv_clz(w, w, operand_smt);
          } else {
            assert(false);  // "solver: BW_CLZ_NoSMT: not a bitwise type"
            return NULL;
          }
        }

        case CN_UNOP_BW_CTZ_NOSMT: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            int w = iterm->base_type.data.bits.size_bits;

            // Helper function wrapper for bv_ctz
            sexp_t* operand_smt;
            if (sexp_is_atom(translate_term_aux(s, e1))) {
              operand_smt = bv_ctz(w, w, translate_term_aux(s, e1));
            } else {
              char* x = fresh_name(named_expr_name());
              sexp_t* x_atom = sexp_atom(x);
              sexp_t* result_expr = bv_ctz(w, w, x_atom);
              sexp_t* bindings[] = {
                  sexp_list((sexp_t*[]){x_atom, translate_term_aux(s, e1)}, 2)};
              sexp_t* result = sexp_let(bindings, 1, result_expr);
              cn_test_free(x);
              operand_smt = result;
            }

            return bv_ctz(w, w, operand_smt);
          } else {
            assert(false);  // "solver: BW_CTZ_NoSMT: not a bitwise type"
            return NULL;
          }
        }

        default:
          assert(false);
          return NULL;
      }
    }

    case CN_TERM_BINOP: {
      cn_term* e1 = iterm->data.binop.left;
      cn_term* e2 = iterm->data.binop.right;

      sexp_t* s1 = translate_term_aux(s, e1);
      assert(s1);

      sexp_t* s2 = translate_term_aux(s, e2);
      assert(s2);

      switch (iterm->data.binop.op) {
        case CN_BINOP_AND:
          return bool_and(s1, s2);

        case CN_BINOP_OR:
          return bool_or(s1, s2);

        case CN_BINOP_IMPLIES:
          return bool_implies(s1, s2);

        case CN_BINOP_ADD: {
          switch (iterm->base_type.tag) {
            case CN_BASE_BITS:
            case CN_BASE_LOC:  // Pointers treated as bitvectors for arithmetic
              return bv_add(s1, s2);
            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_add(s1, s2);
            default:
              assert(false);  // "Add"
              return NULL;
          }
        }

        case CN_BINOP_SUB: {
          switch (iterm->base_type.tag) {
            case CN_BASE_BITS:
            case CN_BASE_LOC:  // Pointers treated as bitvectors for arithmetic
              return bv_sub(s1, s2);
            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_sub(s1, s2);
            default:
              assert(false);  // "Sub"
              return NULL;
          }
        }

        case CN_BINOP_MUL:
        case CN_BINOP_MULNOSMT: {
          switch (iterm->base_type.tag) {
            case CN_BASE_BITS:
              return bv_mul(s1, s2);
            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_mul(s1, s2);
            default:
              assert(false);  // "Mul"
              return NULL;
          }
        }

        case CN_BINOP_DIV:
        case CN_BINOP_DIVNOSMT: {
          switch (iterm->base_type.tag) {
            case CN_BASE_BITS: {
              if (iterm->base_type.data.bits.is_signed) {
                return bv_sdiv(s1, s2);
              } else {
                return bv_udiv(s1, s2);
              }
            }
            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_div(s1, s2);
            default:
              assert(false);  // "Div"
              return NULL;
          }
        }

        case CN_BINOP_EXP:
        case CN_BINOP_EXPNOSMT: {
          // Check if both operands are numeric literals
          int64_t z1, z2;
          bennet_optional(sexp_ptr) opt1 = get_num_z(e1, &z1);
          bennet_optional(sexp_ptr) opt2 = get_num_z(e2, &z2);
          if (bennet_optional_is_some(opt1) && bennet_optional_is_some(opt2) &&
              z2 <= INT_MAX && z2 >= 0) {
            // Compute z1^z2
            int64_t result = 1;
            for (int i = 0; i < z2; i++) {
              result *= z1;
            }

            cn_term* result_term = cn_smt_num(e1->base_type, result);
            return translate_term_aux(s, result_term);
          } else {
            assert(false);  // "Exp"
            return NULL;
          }
        }

        case CN_BINOP_REM:
        case CN_BINOP_REMNOSMT: {
          switch (iterm->base_type.tag) {
            case CN_BASE_BITS: {
              if (iterm->base_type.data.bits.is_signed) {
                return bv_srem(s1, s2);
              } else {
                return bv_urem(s1, s2);
              }
            }
            case CN_BASE_INTEGER:
              return num_rem(s1, s2);
            default:
              assert(false);  // "Rem"
              return NULL;
          }
        }

        case CN_BINOP_MOD:
        case CN_BINOP_MODNOSMT: {
          switch (iterm->base_type.tag) {
            case CN_BASE_BITS: {
              if (iterm->base_type.data.bits.is_signed) {
                return bv_smod(s1, s2);
              } else {
                return bv_urem(s1, s2);
              }
            }
            case CN_BASE_INTEGER:
              return num_mod(s1, s2);
            default:
              assert(false);  // "Mod"
              return NULL;
          }
        }

        case CN_BINOP_BW_XOR: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            return bv_xor(s1, s2);
          } else {
            assert(false);  // "BW_Xor"
            return NULL;
          }
        }

        case CN_BINOP_BW_AND: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            return bv_and(s1, s2);
          } else {
            assert(false);  // "BW_And"
            return NULL;
          }
        }

        case CN_BINOP_BW_OR: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            return bv_or(s1, s2);
          } else {
            assert(false);  // "BW_Or"
            return NULL;
          }
        }

        case CN_BINOP_SHIFT_LEFT: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            return bv_shl(s1, s2);
          } else {
            assert(false);  // "ShiftLeft"
            return NULL;
          }
        }

        case CN_BINOP_SHIFT_RIGHT: {
          if (iterm->base_type.tag == CN_BASE_BITS) {
            if (iterm->base_type.data.bits.is_signed) {
              return bv_ashr(s1, s2);
            } else {
              return bv_lshr(s1, s2);
            }
          } else {
            assert(false);  // "ShiftRight"
            return NULL;
          }
        }

        case CN_BINOP_LT: {
          switch (e1->base_type.tag) {
            case CN_BASE_LOC: {
              return bv_ult(s1, s2);
            }

            case CN_BASE_BITS: {
              if (e1->base_type.data.bits.is_signed) {
                return bv_slt(s1, s2);
              } else {
                return bv_ult(s1, s2);
              }
            }
            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_lt(s1, s2);

            default:
              assert(false);  // "LT"
              return NULL;
          }
        }

        case CN_BINOP_LE: {
          switch (e1->base_type.tag) {
            case CN_BASE_LOC: {
              return bv_uleq(s1, s2);
            }

            case CN_BASE_BITS: {
              if (e1->base_type.data.bits.is_signed) {
                return bv_sleq(s1, s2);
              } else {
                return bv_uleq(s1, s2);
              }
            }

            case CN_BASE_INTEGER:
            case CN_BASE_REAL:
              return num_leq(s1, s2);

            default:
              // The OCaml code has error handling here with BT.pp
              assert(false);  // "LE"
              return NULL;
          }
        }

        case CN_BINOP_MIN: {
          // NOTE: duplicates terms
          // translate_term s (ite_ (le_ (e1, e2) loc, e1, e2) loc)
          cn_term* le_term = cn_smt_le(e1, e2);
          cn_term* ite_term = cn_smt_ite(le_term, e1, e2);
          return translate_term_aux(s, ite_term);
        }

        case CN_BINOP_MAX: {
          // NOTE: duplicates terms
          // translate_term s (ite_ (ge_ (e1, e2) loc, e1, e2) loc)
          cn_term* ge_term = cn_smt_ge(e1, e2);
          cn_term* ite_term = cn_smt_ite(ge_term, e1, e2);
          return translate_term_aux(s, ite_term);
        }

        case CN_BINOP_EQ:
          return eq(s1, s2);

        case CN_BINOP_LT_POINTER: {
          // Cast both pointers to uintptr_bt and then use regular LT
          cn_base_type uintptr_bt =
              cn_base_type_bits(false, 64);  // Memory.uintptr_bt equivalent
          cn_term* cast_e1 = cn_smt_cast(uintptr_bt, e1);
          cn_term* cast_e2 = cn_smt_cast(uintptr_bt, e2);
          return translate_term_aux(s, cn_smt_lt(cast_e1, cast_e2));
        }

        case CN_BINOP_LE_POINTER: {
          // Cast both pointers to uintptr_bt and then use regular LE
          cn_base_type uintptr_bt =
              cn_base_type_bits(false, 64);  // Memory.uintptr_bt equivalent
          cn_term* cast_e1 = cn_smt_cast(uintptr_bt, e1);
          cn_term* cast_e2 = cn_smt_cast(uintptr_bt, e2);
          return translate_term_aux(s, cn_smt_le(cast_e1, cast_e2));
        }

        case CN_BINOP_SET_UNION:
          return set_union(s->ext, s1, s2);

        case CN_BINOP_SET_INTERSECTION:
          return set_intersection(s->ext, s1, s2);

        case CN_BINOP_SET_DIFFERENCE:
          return set_difference(s->ext, s1, s2);

        case CN_BINOP_SET_MEMBER:
          return set_member(s->ext, s1, s2);

        case CN_BINOP_SUBSET:
          return set_subset(s->ext, s1, s2);

        default:
          assert(false);
          return NULL;
      }
    }

    case CN_TERM_ITE: {
      sexp_t* cond_smt = translate_term_aux(s, iterm->data.ite.cond);
      sexp_t* then_smt = translate_term_aux(s, iterm->data.ite.then_term);
      sexp_t* else_smt = translate_term_aux(s, iterm->data.ite.else_term);
      return ite(cond_smt, then_smt, else_smt);
    }

    case CN_TERM_MEMBER_SHIFT: {
      sexp_t* ptr_smt = translate_term_aux(s, iterm->data.member_shift.base);

      return bv_add(ptr_smt, loc_k(iterm->data.member_shift.offset));
    }

    case CN_TERM_ARRAY_SHIFT: {
      sexp_t* base_smt = translate_term_aux(s, iterm->data.array_shift.base);
      sexp_t* index_smt = translate_term_aux(s, iterm->data.array_shift.index);

      // Cast index to pointer width if it's a narrower bitvector
      cn_base_type index_type = iterm->data.array_shift.index->base_type;
      bool idx_signed;
      int idx_sz;
      cn_base_type loc_bt = cn_base_type_bits(false, CHAR_BIT * sizeof(uintptr_t));
      if (is_bits_type(index_type, &idx_signed, &idx_sz) &&
          idx_sz != CHAR_BIT * (int)sizeof(uintptr_t)) {
        index_smt = bv_cast(loc_bt, index_type, index_smt);
      }

      sexp_t* offset_smt =
          (iterm->data.array_shift.element_size != 1)
              ? bv_mul(loc_k(iterm->data.array_shift.element_size), index_smt)
              : index_smt;

      return bv_add(base_smt, offset_smt);
    }

    case CN_TERM_CAST: {
      // Cast (cbt, t) -> complex casting logic based on source and target types
      cn_term* t = iterm->data.cast.value;
      cn_base_type target_bt = iterm->base_type;
      cn_base_type source_bt = t->base_type;

      sexp_t* smt_term = translate_term_aux(s, t);

      // Handle different cast combinations - simplified version
      if (source_bt.tag == CN_BASE_BITS && target_bt.tag == CN_BASE_LOC) {
        // Bits -> Loc
        return bv_cast(
            cn_base_type_bits(false, CHAR_BIT * sizeof(uintptr_t)), source_bt, smt_term);
      } else if (source_bt.tag == CN_BASE_LOC && target_bt.tag == CN_BASE_BITS) {
        // Loc -> Bits
        return bv_cast(
            target_bt, cn_base_type_bits(false, CHAR_BIT * sizeof(uintptr_t)), smt_term);
      } else if (source_bt.tag == CN_BASE_BITS && target_bt.tag == CN_BASE_BITS) {
        // Bits -> Bits: bv_cast
        return bv_cast(target_bt, source_bt, smt_term);
      } else if (source_bt.tag == CN_BASE_BITS && target_bt.tag == CN_BASE_INTEGER) {
        // Bits -> Integer: Bitvector to integer conversion
        sexp_t* args[] = {smt_term};
        return sexp_app_str("bv2int", args, 1);
      } else if (source_bt.tag == CN_BASE_LOC && target_bt.tag == CN_BASE_INTEGER) {
        // Loc -> Integer: LOC is represented as a bitvector, convert bitvector to integer
        // In the C implementation, t_loc() returns t_bits(CHAR_BIT * sizeof(uintptr_t))
        // So we can directly convert the bitvector to integer using bv2int
        sexp_t* args[] = {smt_term};
        return sexp_app_str("bv2int", args, 1);
      } else if (source_bt.tag == CN_BASE_INTEGER && target_bt.tag == CN_BASE_LOC) {
        // Integer -> Loc: Convert integer to bitvector
        // LOC is represented as a bitvector of width CHAR_BIT * sizeof(uintptr_t)
        // Use (_ int2bv n) to convert integer to n-bit bitvector
        int ptr_width = CHAR_BIT * sizeof(uintptr_t);
        char buffer[64];
        snprintf(buffer, sizeof(buffer), "(_ int2bv %d)", ptr_width);
        sexp_t* args[] = {smt_term};
        return sexp_app_str(buffer, args, 1);
      } else if (source_bt.tag == CN_BASE_INTEGER && target_bt.tag == CN_BASE_BITS) {
        // Integer -> Bits: Convert integer to bitvector of target width
        int target_width = target_bt.data.bits.size_bits;
        char buffer[64];
        snprintf(buffer, sizeof(buffer), "(_ int2bv %d)", target_width);
        sexp_t* args[] = {smt_term};
        return sexp_app_str(buffer, args, 1);
      } else {
        // Other casts
        assert(false);
        return smt_term;
      }
    }

      // Placeholder for additional cases still to be implemented:
      // - EachI loops
      // - List operations
      // - Map operations
      // - Option types
      // And many more cases from the original OCaml code

    case CN_TERM_EACHI: {
      // Universal quantification - for now, return a default boolean
      // TODO: Implement proper quantification
      assert(false);

      return bool_k(true);
    }

    case CN_TERM_STRUCT: {
      // Struct construction - create constructor function call
      const char* tag = iterm->data.struct_val.tag;

      // Create constructor name using struct_con_name
      const char* con_name = struct_con_name(tag);

      // Get member count from vector
      bennet_vector(cn_member_pair)* members = &iterm->data.struct_val.members;
      size_t arg_count = bennet_vector_size(cn_member_pair)(members);

      // Allocate array for translated member arguments
      sexp_t** args = NULL;
      if (arg_count > 0) {
        args = cn_test_malloc(sizeof(sexp_t*) * arg_count);

        // Translate each member term
        for (size_t i = 0; i < arg_count; i++) {
          cn_member_pair* pair = bennet_vector_get(cn_member_pair)(members, i);
          cn_term* member_term = pair->value;
          args[i] = translate_term_aux(s, member_term);
        }
      }

      // Create function application
      sexp_t* fn_atom = sexp_atom(con_name);
      sexp_t* result = sexp_app(fn_atom, args, arg_count);

      // Cleanup
      // con_name is interned, no need to free
      if (args) {
        cn_test_free(args);
      }

      return result;
    }

    case CN_TERM_STRUCT_MEMBER: {
      // Struct member access
      sexp_t* struct_smt = translate_term_aux(s, iterm->data.struct_member.struct_term);
      const char* member = iterm->data.struct_member.member_name;

      const char* fn_name = struct_field_name(member);

      sexp_t* fn_atom = sexp_atom(fn_name);
      sexp_t* args[] = {struct_smt};
      sexp_t* result = sexp_app(fn_atom, args, 1);

      return result;
    }

    case CN_TERM_STRUCT_UPDATE: {
      // Struct update - create uninterpreted function call
      sexp_t* struct_smt = translate_term_aux(s, iterm->data.struct_update.struct_term);
      sexp_t* value_smt = translate_term_aux(s, iterm->data.struct_update.new_value);
      const char* member = iterm->data.struct_update.member_name;

      char buffer[256];
      snprintf(buffer, sizeof(buffer), "set_%s", member);

      sexp_t* fn_atom = sexp_atom(buffer);
      sexp_t* args[] = {struct_smt, value_smt};
      sexp_t* result = sexp_app(fn_atom, args, 2);

      return result;
    }

    case CN_TERM_RECORD: {
      // Record construction - build tuple in canonical type order
      cn_base_type record_bt = iterm->base_type;
      assert(record_bt.tag == CN_BASE_RECORD);

      size_t member_count = record_bt.data.record.count;
      bennet_vector(cn_member_pair)* members = &iterm->data.record.members;

      // Allocate array for translated member arguments in type order
      sexp_t** args = NULL;
      if (member_count > 0) {
        args = cn_test_malloc(sizeof(sexp_t*) * member_count);
        assert(args);

        // For each member in the base type (in canonical order), find its value
        for (size_t i = 0; i < member_count; i++) {
          const char* type_member_name = record_bt.data.record.names[i];

          // Find this member in the members vector
          bool found = false;
          for (size_t j = 0; j < bennet_vector_size(cn_member_pair)(members); j++) {
            cn_member_pair* pair = bennet_vector_get(cn_member_pair)(members, j);
            if (strcmp(pair->name, type_member_name) == 0) {
              args[i] = translate_term_aux(s, pair->value);
              found = true;
              break;
            }
          }
          assert(found);  // All members should be present
        }
      }

      // Compute element types for type annotation
      sexp_t** element_types = NULL;
      if (member_count > 0) {
        element_types = cn_test_malloc(sizeof(sexp_t*) * member_count);
        assert(element_types);

        for (size_t i = 0; i < member_count; i++) {
          element_types[i] = translate_base_type(record_bt.data.record.types[i]);
          assert(element_types[i]);
        }
      }

      // Create the tuple type for annotation
      sexp_t* tuple_type = cn_tuple_type_name(element_types, member_count);
      assert(tuple_type);

      // Create type-annotated tuple constructor
      const char* tuple_con_name = cn_tuple_constructor_name(member_count);
      sexp_t* constructor_atom = sexp_atom(tuple_con_name);
      sexp_t* typed_constructor = sexp_as_type(constructor_atom, tuple_type);

      // Apply to values
      sexp_t* result = sexp_app(typed_constructor, args, member_count);

      // Cleanup
      if (element_types) {
        for (size_t i = 0; i < member_count; i++) {
        }
        cn_test_free(element_types);
      }
      if (args) {
        cn_test_free(args);
      }

      return result;
    }

    case CN_TERM_RECORD_MEMBER: {
      // Record member access - use tuple selector
      sexp_t* record_smt = translate_term_aux(s, iterm->data.record_member.record_term);
      const char* member = iterm->data.record_member.member_name;

      // Get the record's base type to find member index
      cn_base_type record_bt = iterm->data.record_member.record_term->base_type;
      assert(record_bt.tag == CN_BASE_RECORD);

      // Find the index of the member in the record type
      size_t member_index = 0;
      bool found = false;
      for (size_t i = 0; i < record_bt.data.record.count; i++) {
        if (strcmp(record_bt.data.record.names[i], member) == 0) {
          member_index = i;
          found = true;
          break;
        }
      }
      assert(found);  // Member should exist in the record type

      // Get the tuple selector name (e.g., "cn_get_0_of_2")
      const char* selector_name =
          cn_tuple_get_selector_name(record_bt.data.record.count, member_index);

      sexp_t* fn_atom = sexp_atom(selector_name);
      sexp_t* args[] = {record_smt};
      sexp_t* result = sexp_app(fn_atom, args, 1);

      return result;
    }

    case CN_TERM_CONSTRUCTOR: {
      // Constructor call with arguments
      const char* ctor = iterm->data.constructor.constructor_name;

      // Add _con suffix to constructor name
      char buffer[256];
      snprintf(buffer, sizeof(buffer), "%s_con", ctor);

      // Get the arguments vector
      bennet_vector(cn_member_pair)* args_vec = &iterm->data.constructor.args;
      size_t arg_count = bennet_vector_size(cn_member_pair)(args_vec);

      if (arg_count == 0) {
        // Nullary constructor
        sexp_t* fn_atom = sexp_atom(buffer);
        sexp_t* result = sexp_app(fn_atom, NULL, 0);
        return result;
      }

      // Translate arguments in the order they are provided
      sexp_t** arg_sexps = cn_test_malloc(sizeof(sexp_t*) * arg_count);
      assert(arg_sexps);
      for (size_t i = 0; i < arg_count; i++) {
        cn_member_pair* pair = bennet_vector_get(cn_member_pair)(args_vec, i);
        arg_sexps[i] = translate_term_aux(s, pair->value);
        assert(arg_sexps[i]);
      }

      // Build constructor application
      sexp_t* fn_atom = sexp_atom(buffer);
      sexp_t* result = sexp_app(fn_atom, arg_sexps, arg_count);

      // Cleanup
      for (size_t i = 0; i < arg_count; i++) {
      }
      cn_test_free(arg_sexps);

      return result;
    }

    case CN_TERM_WRAPI: {
      assert(false);
    }

    case CN_TERM_MAP_SET: {
      // Map set operation - use arr_store
      sexp_t* map_smt = translate_term_aux(s, iterm->data.map_set.map);
      sexp_t* key_smt = translate_term_aux(s, iterm->data.map_set.key);
      sexp_t* value_smt = translate_term_aux(s, iterm->data.map_set.value);

      return arr_store(map_smt, key_smt, value_smt);
    }

    case CN_TERM_MAP_GET: {
      // Map get operation - use arr_select
      sexp_t* map_smt = translate_term_aux(s, iterm->data.map_get.map);
      sexp_t* key_smt = translate_term_aux(s, iterm->data.map_get.key);

      return arr_select(map_smt, key_smt);
    }

    case CN_TERM_APPLY: {
      // Function application
      const char* fn_name = iterm->data.apply.function_name;

      // Append _func suffix to get SMT name
      char buffer[256];
      snprintf(buffer, sizeof(buffer), "%s_func", fn_name);

      sexp_t* fn_atom = sexp_atom(buffer);

      // Get argument count from vector
      bennet_vector(cn_term_ptr)* args_vec = &iterm->data.apply.args;
      size_t arg_count = bennet_vector_size(cn_term_ptr)(args_vec);

      // Allocate array for translated arguments
      sexp_t** args = NULL;
      if (arg_count > 0) {
        args = cn_test_malloc(sizeof(sexp_t*) * arg_count);
        assert(args);

        // Translate each argument term
        for (size_t i = 0; i < arg_count; i++) {
          cn_term* arg_term = *bennet_vector_get(cn_term_ptr)(args_vec, i);
          args[i] = translate_term_aux(s, arg_term);
        }
      }

      // Create function application
      sexp_t* result = sexp_app(fn_atom, args, arg_count);

      // Cleanup
      if (args) {
        cn_test_free(args);
      }

      return result;
    }

    case CN_TERM_LET: {
      // Substitute the variable with its value in the body, then translate

      // Create a substitution table
      bennet_hash_table(uint64_t, cn_term_ptr)* subst_table = cn_create_subst_table();
      assert(subst_table);

      // Add the substitution from variable ID to the value term
      cn_add_substitution(subst_table, iterm->data.let.var.id, iterm->data.let.value);

      // Perform substitution on the body
      cn_term* substituted_body = cn_subst_term(iterm->data.let.body, subst_table);
      assert(substituted_body);

      // Translate the substituted body
      sexp_t* result = translate_term_aux(s, substituted_body);

      // Cleanup
      cn_free_subst_table(subst_table);

      return result;
    }

    case CN_TERM_MATCH: {
      // Pattern matching - translate to SMT-LIB match expression

      // Translate scrutinee
      sexp_t* scrutinee_smt = translate_term_aux(s, iterm->data.match_data.scrutinee);
      assert(scrutinee_smt);

      // Get cases vector
      bennet_vector(cn_match_case)* cases_vec = &iterm->data.match_data.cases;
      size_t case_count = bennet_vector_size(cn_match_case)(cases_vec);

      // Handle empty match (shouldn't happen, but be safe)
      if (case_count == 0) {
        return bool_k(true);
      }

      // Allocate alternatives array
      match_alt_t* alternatives = cn_test_malloc(sizeof(match_alt_t) * case_count);
      assert(alternatives);

      // Track allocated strings for cleanup
      const char*** var_names_arrays = cn_test_malloc(sizeof(const char**) * case_count);
      assert(var_names_arrays);

      // Build each alternative
      for (size_t i = 0; i < case_count; i++) {
        cn_match_case* match_case = bennet_vector_get(cn_match_case)(cases_vec, i);

        // Determine pattern type and build pattern
        if (match_case->constructor_tag == NULL) {
          // Variable or wildcard pattern (PAT_VAR)
          alternatives[i].pattern.type = PAT_VAR;

          if (match_case->pattern_var_count == 1 &&
              match_case->pattern_vars[0].name != NULL) {
            // Single variable binding
            const char* var_name = fn_name(match_case->pattern_vars[0]);
            assert(var_name);
            alternatives[i].pattern.data.var_name = var_name;

            // Track for cleanup (1 variable)
            var_names_arrays[i] = cn_test_malloc(sizeof(const char*));
            var_names_arrays[i][0] = var_name;
          } else {
            // Wildcard pattern
            alternatives[i].pattern.data.var_name = "_";
            var_names_arrays[i] = NULL;  // No cleanup needed for constant
          }
        } else {
          // Constructor pattern (PAT_CON)
          alternatives[i].pattern.type = PAT_CON;

          // Add _con suffix to match datatype constructor naming convention
          char con_buffer[256];
          snprintf(con_buffer, sizeof(con_buffer), "%s_con", match_case->constructor_tag);
          alternatives[i].pattern.data.con.con_name = cn_intern_string(con_buffer);

          alternatives[i].pattern.data.con.var_count = match_case->pattern_var_count;

          // Convert pattern variables to name strings
          if (match_case->pattern_var_count > 0) {
            const char** var_names =
                cn_test_malloc(sizeof(const char*) * match_case->pattern_var_count);
            assert(var_names);

            for (size_t j = 0; j < match_case->pattern_var_count; j++) {
              if (match_case->pattern_vars[j].name != NULL) {
                // Named variable binding
                var_names[j] = fn_name(match_case->pattern_vars[j]);
                assert(var_names[j]);
              } else {
                // Wildcard in constructor pattern
                var_names[j] = "_";
              }
            }

            alternatives[i].pattern.data.con.var_names = var_names;
            var_names_arrays[i] = var_names;
          } else {
            // Constructor with no arguments
            alternatives[i].pattern.data.con.var_names = NULL;
            var_names_arrays[i] = NULL;
          }
        }

        // Translate body term
        alternatives[i].expr = translate_term_aux(s, match_case->body_term);
        assert(alternatives[i].expr);
      }

      // Generate SMT match expression
      sexp_t* result = match_datatype(scrutinee_smt, alternatives, case_count);
      assert(result);

      // Clean up allocated memory

      for (size_t i = 0; i < case_count; i++) {
        if (var_names_arrays[i] != NULL) {
          if (alternatives[i].pattern.type == PAT_VAR) {
            // Variable names are interned, only free the array
            cn_test_free((void*)var_names_arrays[i]);
          } else {
            // PAT_CON - variable names are interned, only free the array
            cn_test_free((void*)alternatives[i].pattern.data.con.var_names);

            // Constructor name is interned, no need to free
          }
        }
      }

      cn_test_free(var_names_arrays);
      cn_test_free(alternatives);

      return result;
    }

    default:
      // Return a default/error case
      fprintf(stderr, "ERROR: Unhandled term type %d in translate_term\n", iterm->type);
      assert(false);
      return NULL;
  }
}

/** Public wrapper for translate_term_aux */
sexp_t* translate_term(struct cn_smt_solver* s, cn_term* iterm) {
  cn_arena* arena = cn_arena_create(0);
  cn_arena_push_alloc(arena);

  sexp_t* result = translate_term_aux(s, iterm);

  cn_test_pop_alloc();
  cn_arena_destroy(arena);

  return result;
}

void cn_declare_fun(struct cn_smt_solver* s,
    cn_sym name,
    cn_base_type* args_bts,
    size_t args_count,
    cn_base_type res_bt) {
  const char* sname = fn_name(name);
  if (!sname)
    return;

  cn_bump_frame_id frame = cn_bump_get_frame_id();

  // Translate argument base types
  sexp_t** args_ts = NULL;
  if (args_count > 0) {
    args_ts = cn_test_malloc(sizeof(sexp_t*) * args_count);
    assert(args_ts);
  }

  for (size_t i = 0; i < args_count; i++) {
    args_ts[i] = translate_base_type(args_bts[i]);
    assert(args_ts[i]);
  }

  // Translate result type
  sexp_t* res_t = translate_base_type(res_bt);
  assert(res_t);

  // Create SMT declare_fun command
  sexp_t* decl_cmd = declare_fun(sname, args_ts, args_count, res_t);
  assert(decl_cmd);
  ack_command(s, decl_cmd);

  cn_bump_free_after(frame);

  // Cleanup
  for (size_t i = 0; i < args_count; i++) {
  }
  cn_test_free(args_ts);
  // sname is interned, no need to free
}

void cn_declare_variable(struct cn_smt_solver* solver, cn_sym sym, cn_base_type bt) {
  cn_declare_fun(solver, sym, NULL, 0, bt);
}
