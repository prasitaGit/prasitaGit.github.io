#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include <cn-executable/bump_alloc.h>
#include <cn-executable/utils.h>
#include <cn-executable/wand.h>

cn_wand_addr cn_wand_addr_real(void* p) {
  cn_wand_addr a;
  a.real = p;
  return a;
}

_Bool cn_wand_addr_is_null(cn_wand_addr a) {
  return a.real == NULL;
}

_Bool cn_wand_addr_eq(cn_wand_addr a, cn_wand_addr b) {
  if (cn_wand_addr_is_null(a) || cn_wand_addr_is_null(b)) {
    return 0;
  }
  return a.real == b.real;
}

void cn_wand_heap_init(cn_wand_heap* heap) {
  heap->head = NULL;
  heap->tail = NULL;
}

/* Plain pairwise interval-overlap test, NOT a containment/coalescing check
   (contrast cn_loop_ownership_contains in utils.c, which deliberately
   relies on ranges having already been coalesced into a single covering
   node - safe there only because of its own feeding discipline, but not
   an assumption this function is willing to make: two leaf takes' real
   allocations can land anywhere relative to each other). NULL is never a
   valid anchor (see cn_wand_addr_is_null) and a zero-size node can never
   overlap anything, so both are treated as "no overlap" defensively
   rather than risking a false positive on a sentinel/empty node. */
static _Bool cn_wand_ranges_overlap(
    cn_wand_addr a_addr, size_t a_size, cn_wand_addr b_addr, size_t b_size) {
  if (cn_wand_addr_is_null(a_addr) || cn_wand_addr_is_null(b_addr)) {
    return 0;
  }
  if (a_size == 0 || b_size == 0) {
    return 0;
  }
  uintptr_t a_lo = (uintptr_t)a_addr.real;
  uintptr_t a_hi = a_lo + a_size;
  uintptr_t b_lo = (uintptr_t)b_addr.real;
  uintptr_t b_hi = b_lo + b_size;
  return a_lo < b_hi && b_lo < a_hi;
}

cn_wand_node* cn_wand_heap_add(cn_wand_heap* heap,
    cn_wand_addr addr,
    size_t size,
    _Bool is_leaf,
    char* pred_name,
    void* value) {
  /* Every generated predicate function now receives a cn_wand_heap*
     (nullable) and calls this at each of its own leaf takes - an
     ordinary, non-wand call always passes NULL for it (see
     wand_heap_ctxt's No_wand_heap default in cn_to_ail.ml), so this must
     no-op rather than deref a NULL heap, exactly like the borrow
     preamble's cn_borrow_active check already makes cn_borrow_stop_ptr
     etc. inert for ordinary calls. */
  if (heap == NULL) {
    return NULL;
  }
  /* Overlap check (see this function's own comment in wand.h): walk every
     node already in this heap - scattered at whatever real addresses
     their own mallocs landed on, in no particular order - and hard-fail
     if the new [addr, addr+size) range overlaps any one of them
     individually. This is what catches e.g. `take Lh = Listrep(h); take
     Lc = Listrep(curr);` where curr is already one of h's own cells: h's
     own walk will have already appended a node at that exact real
     address before Lc's walk ever reaches it. */
  for (cn_wand_node* n = heap->head; n != NULL; n = n->next) {
    if (is_leaf && n->is_leaf && cn_wand_ranges_overlap(addr, size, n->addr, n->size)) {
      cn_printf(CN_LOGGING_ERROR,
          "[CN WAND] antecedent claims overlapping real memory - two "
          "takes (`%s` at %p, size %zu and `%s` at %p, size %zu) claim "
          "overlapping or identical addresses within the same wand "
          "occurrence\n",
          pred_name,
          addr.real,
          size,
          n->pred_name,
          n->addr.real,
          n->size);
      print_error_msg_info(get_global_error_msg_info());
      cn_failure(CN_FAILURE_CHECK_OWNERSHIP, WAND_PEEK);
      return NULL;
    }
  }
  cn_wand_node* node = cn_bump_malloc(sizeof(cn_wand_node));
  node->addr = addr;
  node->size = size;
  node->is_leaf = is_leaf;
  node->pred_name = pred_name;
  node->value = value;
  node->next = NULL;
  if (heap->tail == NULL) {
    heap->head = node;
    heap->tail = node;
  } else {
    heap->tail->next = node;
    heap->tail = node;
  }
  return node;
}

_Bool cn_wand_pred_name_eq(char* a, char* b) {
  return strcmp(a, b) == 0;
}

/* Does `addr`/`size` overlap ANY is_leaf node in `heap`? Used below to ask
   "is this real cell already accounted for by the antecedent's own
   postulate" - a plain linear scan, matching this file's existing
   no-coalescing discipline (see cn_wand_heap_add's own comment). */
static _Bool cn_wand_heap_contains_leaf_overlap(
    cn_wand_heap* heap, cn_wand_addr addr, size_t size) {
  for (cn_wand_node* n = heap->head; n != NULL; n = n->next) {
    if (n->is_leaf && cn_wand_ranges_overlap(addr, size, n->addr, n->size)) {
      return 1;
    }
  }
  return 0;
}

/* Checks that the wand's own real footprint - the part of the consequent's
   real construct-side walk (`cons_heap`) that ISN'T already accounted for
   by the antecedent's own postulate (`ante_heap`) - is disjoint from
   `inv_heap`, the real footprint of every ORDINARY (non-wand) resource
   taken elsewhere in the same loop-invariant checkpoint (e.g. a Template
   ghost variable like `Npar` sitting next to the wand, never mentioned by
   either of its sides).

   Why subtract ante_heap first, rather than comparing cons_heap to
   inv_heap directly: the construct side's real walk is ALWAYS expected to
   re-touch memory some ordinary take in this same checkpoint already owns
   - that's inherent to how this proof technique works (e.g. `take T2 =
   Treerep(r)` next to a wand whose antecedent re-peeks the exact same
   `Treerep(r)`, and whose consequent's real walk down to `r` legitimately
   re-touches T2's own cells on the way). Subtracting ante_heap removes
   exactly that expected overlap for free - the antecedent's own postulate
   peeks the SAME predicate at the SAME address as whichever ordinary take
   the wand is actually about, so ante_heap's real footprint and that
   take's real footprint coincide - without needing to know which ordinary
   take that was. What's left in cons_heap after removing ante_heap's
   coverage is memory the construct side touches for reasons that have
   nothing to do with the antecedent's own postulated subtree; if THAT
   collides with inv_heap, some ordinary take's memory got silently
   absorbed by the construct side's loop-tolerant re-touch allowance
   (cn_wand_construct_push/pop) without the wand ever saying anything about
   it - exactly the bstDelete.c `Npar` case this exists to catch. A real
   collision hard-fails via cn_failure, same as cn_wand_heap_add's own
   antecedent-vs-antecedent check. */
void cn_wand_heap_check_disjoint_from_inv(
    cn_wand_heap* cons_heap, cn_wand_heap* ante_heap, cn_wand_heap* inv_heap,
    enum spec_mode spec_mode) {
  if (cons_heap == NULL || ante_heap == NULL || inv_heap == NULL) {
    return;
  }
  for (cn_wand_node* c = cons_heap->head; c != NULL; c = c->next) {
    if (!c->is_leaf) {
      continue;
    }
    if (cn_wand_heap_contains_leaf_overlap(ante_heap, c->addr, c->size)) {
      /* Covered by the antecedent's own postulate - expected overlap. */
      continue;
    }
    for (cn_wand_node* i = inv_heap->head; i != NULL; i = i->next) {
      if (i->is_leaf && cn_wand_ranges_overlap(c->addr, c->size, i->addr, i->size)) {
        cn_printf(CN_LOGGING_ERROR,
            "[CN WAND] consequent's real footprint overlaps a resource "
            "taken outside the wand - `%s` at %p, size %zu (from the "
            "wand's own real walk) collides with `%s` at %p, size %zu "
            "(taken elsewhere in this same invariant, but never "
            "mentioned by either side of the wand)\n",
            c->pred_name,
            c->addr.real,
            c->size,
            i->pred_name,
            i->addr.real,
            i->size);
        print_error_msg_info(get_global_error_msg_info());
        cn_failure(CN_FAILURE_CHECK_OWNERSHIP, spec_mode);
        return;
      }
    }
  }
}

void cn_wand_heap_register_footprint(
    cn_wand_heap* cons_heap, cn_wand_heap* ante_heap, cn_wand_heap* inv_heap,
    cn_wand_heap* wands_footprint_heap, enum spec_mode spec_mode) {
  if (cons_heap == NULL || ante_heap == NULL) {
    return;
  }
  for (cn_wand_node* c = cons_heap->head; c != NULL; c = c->next) {
    if (!c->is_leaf) {
      continue;
    }
    if (cn_wand_heap_contains_leaf_overlap(ante_heap, c->addr, c->size)) {
      /* Covered by the antecedent's own postulate - expected overlap. */
      continue;
    }
    /* inv_heap is optional - NULL means "no disjointness check wanted
       here", not "nothing to register". A wand embedded directly in a
       predicate body (cn_to_ail.ml's cn_to_ail_lat, not a loop
       invariant) has no sibling "ordinary ghost take in this same
       checkpoint" to collide-check against at all - it's called with
       inv_heap = NULL purely to forward its surviving footprint on into
       wands_footprint_heap (there, the predicate's own ambient
       cn_wand_heap_arg), skipping straight to the copy below. */
    if (inv_heap != NULL) {
      _Bool collided = 0;
      for (cn_wand_node* i = inv_heap->head; i != NULL; i = i->next) {
        if (i->is_leaf && cn_wand_ranges_overlap(c->addr, c->size, i->addr, i->size)) {
          cn_printf(CN_LOGGING_ERROR,
              "[CN WAND] consequent's real footprint overlaps a resource "
              "taken outside the wand - `%s` at %p, size %zu (from the "
              "wand's own real walk) collides with `%s` at %p, size %zu "
              "(taken elsewhere in this same invariant, but never "
              "mentioned by either side of the wand)\n",
              c->pred_name,
              c->addr.real,
              c->size,
              i->pred_name,
              i->addr.real,
              i->size);
          print_error_msg_info(get_global_error_msg_info());
          cn_failure(CN_FAILURE_CHECK_OWNERSHIP, spec_mode);
          collided = 1;
          break;
        }
      }
      if (collided) {
        return;
      }
    }
    if (wands_footprint_heap != NULL) {
      cn_wand_heap_add(
          wands_footprint_heap, c->addr, c->size, 1, c->pred_name, c->value);
    }
  }
}

void cn_wand_heap_check_coverage(
    cn_wand_heap* inv_heap, cn_wand_heap* wands_footprint_heap,
    cn_wand_heap* global_heap, enum spec_mode spec_mode) {
  if (global_heap == NULL) {
    return;
  }
  /* Coverage only (see wand.h for why the reverse direction is not
     checked): every global_heap leaf must be covered by inv_heap or
     wands_footprint_heap - nothing from the function's original footprint
     silently dropped. A leaf whose region Fulminate's ownership ghost
     state no longer tracks was freed by the function (cn_free_sized
     removes it) and is skipped. */
  for (cn_wand_node* g = global_heap->head; g != NULL; g = g->next) {
    if (!g->is_leaf) {
      continue;
    }
    if (!cn_ownership_region_tracked(g->addr.real, g->size)) {
      continue; /* freed since entry */
    }
    if (inv_heap != NULL
        && cn_wand_heap_contains_leaf_overlap(inv_heap, g->addr, g->size)) {
      continue;
    }
    if (wands_footprint_heap != NULL
        && cn_wand_heap_contains_leaf_overlap(wands_footprint_heap, g->addr, g->size)) {
      continue;
    }
    cn_printf(CN_LOGGING_ERROR,
        "[CN WAND] a real memory cell from the function's own precondition "
        "footprint - `%s` at %p, size %zu - is not accounted for by any "
        "ordinary take or any wand's reconstructed footprint at this "
        "checkpoint: a weak invariant that silently stopped describing "
        "part of the memory it started with\n",
        g->pred_name,
        g->addr.real,
        g->size);
    print_error_msg_info(get_global_error_msg_info());
    cn_failure(CN_FAILURE_CHECK_OWNERSHIP, spec_mode);
    return;
  }
}

cn_wand_node* cn_wand_heap_mark(cn_wand_heap* heap) {
  return heap->tail;
}

void cn_wand_heap_transform_range(cn_wand_heap* heap,
    cn_wand_node* start_exclusive,
    char* pred_name_filter,
    cn_wand_value_transform_fn transform) {
  cn_wand_node* n = (start_exclusive == NULL) ? heap->head : start_exclusive->next;
  while (n != NULL) {
    if (cn_wand_pred_name_eq(n->pred_name, pred_name_filter)) {
      transform(n->value);
    }
    n = n->next;
  }
}


typedef struct cn_borrow_entry {
  void* stop;
  void* sub;
  cn_bool* consumed;
  struct cn_borrow_entry* next;
} cn_borrow_entry;

void* cn_borrow_list_cons(void* stop, void* sub, cn_bool* consumed, void* tail) {
  cn_borrow_entry* e = cn_bump_malloc(sizeof(cn_borrow_entry));
  if (e == NULL) {
    return tail;
  }
  e->stop = stop;
  e->sub = sub;
  e->consumed = consumed;
  e->next = (cn_borrow_entry*)tail;
  return e;
}

static cn_borrow_entry* cn_borrow_list_find(void* list, void* p, int is_outer) {
  void* addr = ((cn_pointer*)p)->ptr;
  for (cn_borrow_entry* e = (cn_borrow_entry*)list; e != NULL; e = e->next) {
    void* stop_addr = ((cn_pointer*)e->stop)->ptr;
    if (stop_addr == addr && (stop_addr != NULL || is_outer != 0)) {
      return e;
    }
  }
  return NULL;
}

int cn_borrow_list_hit(void* list, void* p, int is_outer) {
  return cn_borrow_list_find(list, p, is_outer) != NULL;
}

void* cn_borrow_list_take(void* list, void* p, int is_outer) {
  cn_borrow_entry* e = cn_borrow_list_find(list, p, is_outer);
  if (e == NULL) {
    return NULL;
  }
  if (e->consumed != NULL) {
    e->consumed->val = true;
  }
  return e->sub;
}

void* cn_wand_first_leaf_stop(cn_wand_heap* heap, cn_wand_node* mark, void* fallback) {
  if (heap == NULL) {
    return fallback;
  }
  cn_wand_node* n = (mark == NULL) ? heap->head : mark->next;
  for (; n != NULL; n = n->next) {
    if (n->is_leaf) {
      cn_pointer* p = cn_bump_malloc(sizeof(cn_pointer));
      if (p == NULL) {
        return fallback;
      }
      p->ptr = n->addr.real;
      return p;
    }
  }
  return fallback;
}


cn_bool* cn_wand_heap_touches(cn_wand_heap* heap, void* stop) {
  if (heap == NULL || stop == NULL) {
    return convert_to_cn_bool(0);
  }
  void* a = ((cn_pointer*)stop)->ptr;
  for (cn_wand_node* n = heap->head; n != NULL; n = n->next) {
    if (n->is_leaf && n->addr.real == a) {
      return convert_to_cn_bool(1);
    }
  }
  return convert_to_cn_bool(0);
}
